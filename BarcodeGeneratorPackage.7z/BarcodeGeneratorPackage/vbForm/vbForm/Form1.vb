﻿Public Class Form1

    'Create Object
    Dim FontEncoder As New IDAutomation.NetAssembly.FontEncoder
  

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs)

    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click

        tBox2.Text = FontEncoder.Code39(tBox1.Text)
        tArea.Font = New System.Drawing.Font("IDAutomationHC39M", 18, FontStyle.Regular)
        tArea.Text = tBox2.Text

        Dim rep As Report = New Report


        rep.Show()


    End Sub


End Class
