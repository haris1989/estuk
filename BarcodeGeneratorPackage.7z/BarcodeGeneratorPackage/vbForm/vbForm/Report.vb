﻿Imports Microsoft.Reporting.WinForms

Public Class Report

    Private Sub Report_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load


        Dim parReportParam1 As New ReportParameter("parReportParam1", Form1.tArea.Text)
        Me.ReportViewer1.LocalReport.SetParameters(New ReportParameter() {parReportParam1})
        Me.ReportViewer1.RefreshReport()

    End Sub
End Class