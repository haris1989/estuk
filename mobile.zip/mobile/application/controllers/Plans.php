<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Plans extends CI_Controller{
	public function __construct(){
        parent::__construct();
        $this->load->model('admin/Provider');
        $this->load->model('admin/Review');
        $this->load->model('admin/Account');
        $this->load->model('admin/Newss');
        $this->load->model('admin/Page');
        $this->load->model('admin/Comment'); 
        $this->load->model('admin/Utility');
        $this->load->library('pagination');
        $this->load->library('session');
        $this->load->library('form_validation');
        // Your own constructor code
        $haveCountry=null;
        $haveSess=$this->session->userdata('country');
        if(!$haveSess) {
            $newdata = array(
                'country' => 0
            );
            $this->session->set_userdata($newdata);
        }
    }
    public function index(){
        if($this->session->userdata('notice')== 1){
            $data['notice']=$this->session->userdata('noticeFlash');
            $this->session->unset_userdata('notice');
            $this->session->unset_userdata('noticeFlash');
        }
        else if($this->session->userdata('alert') == 2){
            $data['alert']=$this->session->userdata('alertFlash');
            $this->session->unset_userdata('alert');
            $this->session->unset_userdata('alertFlash');
        }
        //Extracting User Information from session
        if($this->session->userdata('user_id')) {
            $data['user_id']=$this->session->userdata('user_id');
            $data['name']=$this->session->userdata('name');
            $data['pic']=$this->session->userdata('picture');
            $data['email']=$this->session->userdata('email');
            }
        $data['sectiontype']=0;
        $data['pages']=$this->Page->all();
    	$data['fbrands']=$this->Provider->featuredOnly($this->session->userdata('country'));
        $data['popularProviders']=$this->Provider->getProviderVisits($this->session->userdata('country'));
        if($this->session->userdata('country')==0){
        $data['provinceList']=$this->Provider->allCanadaProvince();
        }
        else{
        $data['provinceList']=$this->Provider->allUsaProvince(); 
        }
        $data['latestProvider']=$this->Provider->getLatestProvider($this->session->userdata('country'));
        $data['latestNews']=$this->Newss->getLatestNews();
        $data['latestReviews']=$this->Review->getLatestReviews();
        
            $data['country']=$this->session->userdata('country');
        $this->load->view('client/providerHeader.php',$data);
        $this->load->view('client/planHome.php',$data);
        $this->load->view('client/footer.php');

    }
      public function searchByPrice($min=0,$max=0){
         if($this->session->userdata('notice')== 1){
            $data['notice']=$this->session->userdata('noticeFlash');
            $this->session->unset_userdata('notice');
            $this->session->unset_userdata('noticeFlash');
        }
        else if($this->session->userdata('alert') == 2){
            $data['alert']=$this->session->userdata('alertFlash');
            $this->session->unset_userdata('alert');
            $this->session->unset_userdata('alertFlash');
        }
        //Extracting User Information from session
        if($this->session->userdata('user_id')) {
            $data['user_id']=$this->session->userdata('user_id');
            $data['name']=$this->session->userdata('name');
            $data['pic']=$this->session->userdata('picture');
            $data['email']=$this->session->userdata('email');
            }
            if($this->session->userdata('country')==0){
        $data['provinceList']=$this->Provider->allCanadaProvince();
        }
        else{
        $data['provinceList']=$this->Provider->allUsaProvince(); 
        }
        $data['sectiontype']=0;
        $data['pages']=$this->Page->all();
         $data['country']=$this->session->userdata('country');
        $data['fbrands']=$this->Provider->featuredOnly($this->session->userdata('country'));
        $data['popularProviders']=$this->Provider->getProviderVisits($this->session->userdata('country'));
        $data['latestProvider']=$this->Provider->getLatestProvider($this->session->userdata('country'));
        $data['latestNews']=$this->Newss->getLatestNews();
        $data['latestReviews']=$this->Review->getLatestReviews();
        $result=null;
        $result=$this->Provider->getAllPlansByPrice($min,$max,$this->session->userdata('country'));
        $data['result']=$result;

         $this->load->view('client/providerHeader.php',$data);
       $this->load->view('client/plans_by_price.php',$data);
       $this->load->view('client/footer.php');
        
        
    } 
    public function providerSpecification(){
         if($this->session->userdata('notice')== 1){
            $data['notice']=$this->session->userdata('noticeFlash');
            $this->session->unset_userdata('notice');
            $this->session->unset_userdata('noticeFlash');
        }
        else if($this->session->userdata('alert') == 2){
            $data['alert']=$this->session->userdata('alertFlash');
            $this->session->unset_userdata('alert');
            $this->session->unset_userdata('alertFlash');
        }
        //Extracting User Information from session
        if($this->session->userdata('user_id')) {
            $data['user_id']=$this->session->userdata('user_id');
            $data['name']=$this->session->userdata('name');
            $data['pic']=$this->session->userdata('picture');
            $data['email']=$this->session->userdata('email');
            }
        $data['sectiontype']=0;
        $data['pages']=$this->Page->all();
        $data['fbrands']=$this->Provider->featuredOnly($this->session->userdata('country'));
        $data['popularProviders']=$this->Provider->getProviderVisits($this->session->userdata('country'));
        if($this->session->userdata('country')==0){
        $data['provinceList']=$this->Provider->allCanadaProvince();
        }
        else{
        $data['provinceList']=$this->Provider->allUsaProvince(); 
        }
        $data['latestProvider']=$this->Provider->getLatestProvider($this->session->userdata('country'));
        $data['latestNews']=$this->Newss->getLatestNews();
        $data['latestReviews']=$this->Review->getLatestReviews();
        
            $data['country']=$this->session->userdata('country');
            $id=0; 
            if(!is_numeric($this->uri->segment(3))){
            $name=str_replace("%20"," ",$this->uri->segment(3));
            $data['provider']=$this->Provider->find_by_name($name,$this->session->userdata('country'));
            foreach($data['provider'] as $row){
                $id=$row->id;
            }
        }
        else{
            $id=$this->uri->segment(3);
            $data['provider']=$this->Provider->find_by($id,$this->session->userdata('country'));
        }
            
            $data['providerPlans']=$this->Provider->allPlans($id);
            
          $data['comments']=$this->Comment->find_by_type($id,"provider_id");

       
        $this->load->view('client/providerHeader.php',$data);
        $this->load->view('client/provider.php',$data);
        $this->load->view('client/footer.php');

    }
    public function plansByProvince($provinceId=0){
        if($this->session->userdata('notice')== 1){
            $data['notice']=$this->session->userdata('noticeFlash');
            $this->session->unset_userdata('notice');
            $this->session->unset_userdata('noticeFlash');
        }
        else if($this->session->userdata('alert') == 2){
            $data['alert']=$this->session->userdata('alertFlash');
            $this->session->unset_userdata('alert');
            $this->session->unset_userdata('alertFlash');
        }
        //Extracting User Information from session
        if($this->session->userdata('user_id')) {
            $data['user_id']=$this->session->userdata('user_id');
            $data['name']=$this->session->userdata('name');
            $data['pic']=$this->session->userdata('picture');
            $data['email']=$this->session->userdata('email');
            }
            if($this->session->userdata('country')==0){
        $data['provinceList']=$this->Provider->allCanadaProvince();
        }
        else{
        $data['provinceList']=$this->Provider->allUsaProvince(); 
        }
        $data['sectiontype']=0;
        $data['pages']=$this->Page->all();
         $data['country']=$this->session->userdata('country');
        $data['fbrands']=$this->Provider->featuredOnly($this->session->userdata('country'));
        $data['popularProviders']=$this->Provider->getProviderVisits($this->session->userdata('country'));
        $data['latestProvider']=$this->Provider->getLatestProvider($this->session->userdata('country'));
        $data['latestNews']=$this->Newss->getLatestNews();
        $data['latestReviews']=$this->Review->getLatestReviews();
        $result=null;
        $result=$this->Provider->getAllPlansByProvince($this->uri->segment(3),$this->session->userdata('country'));
        $data['result']=$result;

         $this->load->view('client/providerHeader.php',$data);
       $this->load->view('client/plans_by_province.php',$data);
       $this->load->view('client/footer.php');
        
    }
    
     public function allNews(){
        if($this->session->userdata('notice')== 1){
            $data['notice']=$this->session->userdata('noticeFlash');
            $this->session->unset_userdata('notice');
            $this->session->unset_userdata('noticeFlash');
        }
        else if($this->session->userdata('alert') == 2){
            $data['alert']=$this->session->userdata('alertFlash');
            $this->session->unset_userdata('alert');
            $this->session->unset_userdata('alertFlash');
        }
        //Extracting User Information from session
        if($this->session->userdata('user_id')) {
            $data['user_id']=$this->session->userdata('user_id');
            $data['name']=$this->session->userdata('name');
            $data['pic']=$this->session->userdata('picture');
            $data['email']=$this->session->userdata('email');
            }
            if($this->session->userdata('country')==0){
        $data['provinceList']=$this->Provider->allCanadaProvince();
        }
        else{
        $data['provinceList']=$this->Provider->allUsaProvince(); 
        }
        $data['sectiontype']=0;
        $data['pages']=$this->Page->all();
         $data['country']=$this->session->userdata('country');
        $data['fbrands']=$this->Provider->featuredOnly($this->session->userdata('country'));
        $data['popularProviders']=$this->Provider->getProviderVisits($this->session->userdata('country'));
        $data['list']=$this->Newss->all();
        $path=null;
        $path=base_url()."index.php/Plans/allNews/";
        $config['base_url']         = $path;
        $config['total_rows']       = sizeof($data['list']);
        $config['first_link']       = false;
        $config['last_link']        = false;
        $config['per_page']         = 12;
        $config['next_link']        = 'Next >>';
        $config['next_tag_open']    = '<span class="btn btn-primary">';
        $config['next_tag_close']   = '</span>';
        $config['prev_link']        = '<< Previous';
        $config['prev_tag_open']    = '<span class="btn btn-primary">';
        $config['prev_tag_close']   = '</span>';
        $config['num_tag_open']     = '<span class="btn btn-primary">';
        $config['num_tag_close']    = '</span>';
        $config['cur_tag_open']     = '<span class="btn btn-primary" style="background-color:#19d423;border-color:#19d423;">';
        $config['cur_tag_close']    = '</span>';
        $this->pagination->initialize($config);
        $data['listPaginate']=$this->Newss->all_paginate($config['per_page'], $this->uri->segment(3));
        $this->load->view('client/providerHeader.php',$data);
        $this->load->view('client/allPlanNews.php',$data);
        $this->load->view('client/footer.php');
        
    }
    function news($id=0){
         if($this->session->userdata('notice')== 1){
            $data['notice']=$this->session->userdata('noticeFlash');
            $this->session->unset_userdata('notice');
            $this->session->unset_userdata('noticeFlash');
        }

        else if($this->session->userdata('alert') == 2){
            $data['alert']=$this->session->userdata('alertFlash');
            $this->session->unset_userdata('alert');
            $this->session->unset_userdata('alertFlash');
        }
        //Extracting User Information from session
        if($this->session->userdata('user_id')) {
            $data['user_id']=$this->session->userdata('user_id');
            $data['name']=$this->session->userdata('name');
            $data['pic']=$this->session->userdata('picture');
            $data['email']=$this->session->userdata('email');
            }
        if($this->session->userdata('country')==0){
            $data['countryCurrency']="CAD $";
        }
        else{
            $data['countryCurrency']="US $";
        }
        $data['sectiontype']=0;
        $data['pages']=$this->Page->all();
        $data['comments']=$this->Comment->find_by_type($id,"news_id");   
        $data['news']=$this->Newss->find_by($id); 
        if($this->session->userdata('country')==0){
            $data['countryCurrency']="CAD $";
        }
        else{
            $data['countryCurrency']="US $";
        }
        $this->load->view('client/providerHeader.php',$data);
        $this->load->view('client/news.php',$data);
        $this->load->view('client/footer.php');
    }
    public function allReviews($opt=0){
        if($this->session->userdata('notice')== 1){
            $data['notice']=$this->session->userdata('noticeFlash');
            $this->session->unset_userdata('notice');
            $this->session->unset_userdata('noticeFlash');
        }
        else if($this->session->userdata('alert') == 2){
            $data['alert']=$this->session->userdata('alertFlash');
            $this->session->unset_userdata('alert');
            $this->session->unset_userdata('alertFlash');
        }
        //Extracting User Information from session
        if($this->session->userdata('user_id')) {
            $data['user_id']=$this->session->userdata('user_id');
            $data['name']=$this->session->userdata('name');
            $data['pic']=$this->session->userdata('picture');
            $data['email']=$this->session->userdata('email');
            }
            if($this->session->userdata('country')==0){
        $data['provinceList']=$this->Provider->allCanadaProvince();
        }
        else{
        $data['provinceList']=$this->Provider->allUsaProvince(); 
        }
        $data['sectiontype']=0;
        $data['pages']=$this->Page->all();
         $data['country']=$this->session->userdata('country');
        $data['fbrands']=$this->Provider->featuredOnly($this->session->userdata('country'));
        $data['popularProviders']=$this->Provider->getProviderVisits($this->session->userdata('country'));
        $data['list']=$this->Review->allWrtType($opt);   
        $path=null;
        $path=base_url()."index.php/Plans/allReviews/";
        $config['base_url']         = $path;
        $config['total_rows']       = sizeof($data['list']);
        $config['first_link']       = false;
        $config['last_link']        = false;
        $config['per_page']         = 12;
        $config['next_link']        = 'Next >>';
        $config['next_tag_open']    = '<span class="btn btn-primary">';
        $config['next_tag_close']   = '</span>';
        $config['prev_link']        = '<< Previous';
        $config['prev_tag_open']    = '<span class="btn btn-primary">';
        $config['prev_tag_close']   = '</span>';
        $config['num_tag_open']     = '<span class="btn btn-primary">';
        $config['num_tag_close']    = '</span>';
        $config['cur_tag_open']     = '<span class="btn btn-primary" style="background-color:#19d423;border-color:#19d423;">';
        $config['cur_tag_close']    = '</span>';
        $this->pagination->initialize($config);
        $data['listPaginate']=$this->Review->all_paginate($opt,$config['per_page'], $this->uri->segment(3));
        $this->load->view('client/providerHeader.php',$data);
        $this->load->view('client/allPlanReviews.php',$data);
        $this->load->view('client/footer.php');
        
    }
    function review($id=0,$page=1){
         if($this->session->userdata('notice')== 1){
            $data['notice']=$this->session->userdata('noticeFlash');
            $this->session->unset_userdata('notice');
            $this->session->unset_userdata('noticeFlash');
        }
        else if($this->session->userdata('alert') == 2){
            $data['alert']=$this->session->userdata('alertFlash');
            $this->session->unset_userdata('alert');
            $this->session->unset_userdata('alertFlash');
        }
        //Extracting User Information from session
        if($this->session->userdata('user_id')) {
            $data['user_id']=$this->session->userdata('user_id');
            $data['name']=$this->session->userdata('name');
            $data['pic']=$this->session->userdata('picture');
            $data['email']=$this->session->userdata('email');
            }
        if($this->session->userdata('country')==0){
            $data['countryCurrency']="CAD $";
        }
        else{
            $data['countryCurrency']="US $";
        }
        $data['sectiontype']=0;
        $data['pages']=$this->Page->all();
        $data['currentPageNumber']=$page;
        $data['comments']=$this->Comment->find_by_type($id,"review_id");
        $data['reviews']=$this->Review->find_by($id);
        $data['allPages']=$this->Review->allPages($id);
        $data['pageData']=$this->Review->find_page_by_number($page,$id);
        $data['latestReviews']=$this->Review->getLatestReviews();
        if($this->session->userdata('country')==0){
            $data['countryCurrency']="CAD $";
        }
        else{
            $data['countryCurrency']="US $";
        }
        $this->load->view('client/providerHeader.php',$data);
        $this->load->view('client/review.php',$data);
        $this->load->view('client/footer.php');
    }
 
    public function showPage($id=0){
        //Extracting User Information from session
        if($this->session->userdata('user_id')) {
            $data['user_id']=$this->session->userdata('user_id');
            $data['name']=$this->session->userdata('name');
            $data['pic']=$this->session->userdata('picture');
            $data['email']=$this->session->userdata('email');
        }
        if($this->session->userdata('country')==0){
            $data['countryCurrency']="CAD $";
        }
        else{
            $data['countryCurrency']="US $";
        }
            $data['popularPhones']=$this->Cellphone->getPhoneVisits();
            $data['fbrands']=$this->Brand->featuredOnlyByPos();
            $data['popularPhones']=$this->Cellphone->getPhoneVisits();
            $data['pages']=$this->Page->all();
            $data['currentPage']=$this->Page->find_by($id);
            $this->load->view('client/header.php',$data);
            $this->load->view('client/showpage.php',$data);
            $this->load->view('client/footer.php');
        }
    public function doLogin(){
        $data=array();
        $sdata=null;
        if($this->input->post()){
            $this->form_validation->set_rules('email', 'Email', 'required');
            $this->form_validation->set_rules('password', 'Password', 'required');
            if ($this->form_validation->run() === True){
                $data=$this->input->post();
                $data=$this->Account->find_by($data['email'],$data['password'],"user");
                if($data){
                    $sdata['user_id']=$data->id;
                    $sdata['name']=$data->name;
                    $sdata['picture']=$data->picture;
                    $sdata['email']=$data->email;
                    $sdata['password']=$data->password;
                    $this->session->set_userdata($sdata);
                    redirect(base_url()."index.php/Home");
                }
                else{
                    $alertFlash = array(
                        'alert' => 2,
                        'alertFlash' => "<strong>Please!</strong> enter correct email / password"
                    );
                    $this->session->set_userdata($alertFlash);
                    redirect(base_url()."index.php/Home");
                }
            }
            else{
                $alertFlash = array(
                    'alert' => 2,
                    'alertFlash' => "<strong>Please!</strong> enter email and password"
                );
                $this->session->set_userdata($alertFlash);
                redirect(base_url()."index.php/Home");
            }
        }

    }

    function signOut(){
        $this->session->unset_userdata('user_id');
        $this->session->unset_userdata('name');
        $this->session->unset_userdata('picture');
        $this->session->unset_userdata('email');
        $this->session->sess_destroy();
        redirect(base_url()."index.php/Home");
    }

    function signUp(){
        if (!$this->session->userdata('user_id')) {
            $data['pages'] = $this->Page->all();
            $country = $this->session->userdata('country');
            $this->load->view('client/header.php', $data);
            $this->load->view('client/signup.php');
            $this->load->view('client/footer.php');
    }
        else{
            $alertFlash = array(
                'alert' => 2,
                'alertFlash' => "<strong>Sorry!</strong> you are already logged in"
            );
            $this->session->set_userdata($alertFlash);
            redirect(base_url()."index.php/Home");
        }
    }

    function edit(){
        if ($this->session->userdata('user_id')) {

                $result=null;
                $result=$this->Account->find_by_id($this->session->userdata('user_id'),"user");
                foreach($result as $row) {
                    $data['user_id'] = $this->session->userdata('user_id');
                    $data['name'] = $row->name;
                    $data['pic'] =  $row->picture;
                    $data['email'] =  $row->email;
                    $data['password'] = $row->password;
                    $data['website'] = $row->website;
                }

            $data['pages'] = $this->Page->all();
            $country = $this->session->userdata('country');
            $this->load->view('client/header.php', $data);
            $this->load->view('client/editprofile.php',$data);
            $this->load->view('client/footer.php');
        }
        else{
            $alertFlash = array(
                'alert' => 2,
                'alertFlash' => "<strong>Sorry!</strong> you are not logged in"
            );
            $this->session->set_userdata($alertFlash);
            redirect(base_url()."index.php/Home");
        }
    }
    public function searchList(){
        $this->session->unset_userdata('cart');
        $prod=null;
        $provider=$this->Provider->allForSearch($this->session->userdata('country'));
        if($provider) {
            foreach ($provider as $row) {
                echo "<option value='" . $row->name. "'>";
            }
        }
    }
    
    function compareProviders(){//Extracting User Information from session
        if($this->session->userdata('user_id')) {
            $data['user_id']=$this->session->userdata('user_id');
            $data['name']=$this->session->userdata('name');
            $data['pic']=$this->session->userdata('picture');
            $data['email']=$this->session->userdata('email');
        }
        if($this->session->userdata('country')==0){
            $data['countryCurrency']="CAD $";
        }
        else{
            $data['countryCurrency']="US $";
        }
            $data['pages']=$this->Page->all();

        $data["show"]=false;
         $data['country']=$this->session->userdata('country');
        if($this->uri->segment(3)!=null && $this->uri->segment(4)!=null){
            $data["show"]=true;
            $name1=null;
            $name1=str_replace("%20"," ",$this->uri->segment(3));
            $name2=null;
            $name2=str_replace("%20"," ",$this->uri->segment(4));
            $data['provider1']=$this->Provider->find_by_name($name1,$this->session->userdata('country'));
            $data['provider2']=$this->Provider->find_by_name($name2,$this->session->userdata('country'));
        }
        $this->load->view('client/providerHeader.php',$data);
        $this->load->view('client/compareProvider.php',$data);
        $this->load->view('client/footer.php');
    }
}