<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reviews extends CI_Controller
{

    
     function __construct() {
            parent::__construct();
            $this->load->library('session');
            $this->load->model('admin/Review');
            $this->load->model('admin/Cellphone');
            $this->load->model('admin/Provider');
            $this->load->model('admin/Fileupload');
            $this->load->library('pagination');
            $haveSess=null;
              $haveSess=$this->session->userdata('userId');
        if(!$haveSess) {
            redirect(base_url()."index.php/admin/Accounts/login");
        }
        }
    public function index(){
           $data['reviews']=$this->Review->all();

            if($this->session->userdata('notice')== 1){

                $data['notice']=$this->session->userdata('noticeFlash');
                $this->session->unset_userdata('notice');
                $this->session->unset_userdata('noticeFlash');
            }
            else if($this->session->userdata('alert') == 2){
                $data['alert']=$this->session->userdata('alertFlash');
                $this->session->unset_userdata('alert');
                $this->session->unset_userdata('alertFlash');
            }
        

        $this->load->view('admin/header.php',$data);
        $this->load->view('admin/reviews.php',$data);
    }
    
    public function add(){
           $data['reviews']=$this->Review->all();
            $data['phones']=$this->Cellphone->all();
            $data['providers']=$this->Provider->all();
            if($this->session->userdata('notice')== 1){

                $data['notice']=$this->session->userdata('noticeFlash');
                $this->session->unset_userdata('notice');
                $this->session->unset_userdata('noticeFlash');
            }
            else if($this->session->userdata('alert') == 2){
                $data['alert']=$this->session->userdata('alertFlash');
                $this->session->unset_userdata('alert');
                $this->session->unset_userdata('alertFlash');
            }
        

        $this->load->view('admin/header.php',$data);
        $this->load->view('admin/new_review.php',$data);
    }
    public function create(){
            print_r($this->input->post());
            if($this->input->post('type')==1){
                $_POST['provider_id']=null;
            }
            else{
               $_POST['phone_id']=null; 
            }
            unset($_POST['type']);
            $path='./img/reviews/';
            $imageData=$this->Fileupload->do_upload($path);
            $new = $this->input->post();
            if ($_FILES['userfile']['name']!=null) {
                if (!isset($imageData['error'])) {
                    $new['image'] =$imageData['upload_data']['file_name'];
                    $new['created_at'] = date('Y-m-d h:i:s');
                    $new['updated_at'] = date('Y-m-d h:i:s');
                    if ($this->Review->insert($new)) {
                        $noticeFlash = array(
                            'notice' => 1,
                            'noticeFlash' => '<strong>Successfully!</strong> added the review'
                        );
                        $this->session->set_userdata($noticeFlash);
                       redirect(base_url()."index.php/admin/Reviews");
                    }
                    else {
                        $alertFlash = array(
                            'alert' => 2,
                            'alertFlash' => "<strong>OOps!</strong> something went wrong during review insertion."
                        );
                        $this->session->set_userdata($alertFlash);
                       redirect(base_url() . "index.php/admin/Reviews/add");
                    }
                } else {
                    $alertFlash = array(
                        'alert' => 2,
                        'alertFlash' => "<strong>OOps! </strong>" . $imageData['error']
                    );
                    $this->session->set_userdata($alertFlash);
                  redirect(base_url() . "index.php/admin/Reviews/add");
                }
            }
            else{

                $alertFlash = array(
                    'alert' => 2,
                    'alertFlash' => "<strong>Sorry! </strong> select a review banner image in order to proceed. "
                );
                $this->session->set_userdata($alertFlash);
                redirect(base_url() . "index.php/admin/Reviews/add");
            }
        }

            public function edit($id=0){
            $data['reviews']=$this->Review->find_by($id);
            $data['phones']=$this->Cellphone->all();
            $data['plans']=$this->Provider->all();
            if($data['reviews']){

            if($this->session->userdata('notice')== 1){

                $data['notice']=$this->session->userdata('noticeFlash');
                $this->session->unset_userdata('notice');
                $this->session->unset_userdata('noticeFlash');
            }
            else if($this->session->userdata('alert') == 2){
                $data['alert']=$this->session->userdata('alertFlash');
                $this->session->unset_userdata('alert');
                $this->session->unset_userdata('alertFlash');
            }
        

        $this->load->view('admin/header.php',$data);
        $this->load->view('admin/edit_reviews.php',$data);
    }
    else{
        $data['alert']="Sorry! No record found.";

        $this->load->view('admin/header.php',$data);
    }
    }
     function update(){

         //unset($_POST['type']);

        $action="edit";
            $new=$this->input->post();
            
            if($new['type']==0){
            $new['phone_id']=null;
            }
            else{
                $new['provider_id']=null;
            }
            unset($new['type']);
            if ($_FILES['userfile']['name']!=null) {
                $path='./img/reviews/';
                $imageData=$this->Fileupload->do_upload($path);
                $new['image'] =$imageData['upload_data']['file_name'];
                if (isset($imageData['error'])) {
                    $alertFlash = array(
                        'alert' => 2,
                        'alertFlash' => "<strong>OOps! </strong>" .$imageData['error']
                    );
                    $this->session->set_userdata($alertFlash);
                    redirect(base_url() . "index.php/admin/Reviews/".$action."/".$this->input->post('id'));
                }
            }
            $new['updated_at'] = date('Y-m-d h:i:s');
            unset($new['old_name']);
                if ($this->Review->update($new)) {
                    $noticeFlash = array(
                        'notice' => 1,
                        'noticeFlash' => '<strong>Successfully!</strong> updated review info.'
                    );
                    $this->session->set_userdata($noticeFlash);
                    redirect(base_url() . "index.php/admin/Reviews/".$action."/" . $this->input->post('id'));
                }
            else {
                $alertFlash = array(
                    'alert' => 2,
                    'alertFlash' => "<strong>OOps!</strong> something went wrong during review update."
                );
                $this->session->set_userdata($alertFlash);
                redirect(base_url() . "index.php/admin/Reviews/".$action."/".$this->input->post('id'));
            }


        }

        public function destroy($id=0){

           $result= $this->Review->find_by($id);
            foreach($result as $r){
                
                         unlink('./img/reviews/'. $r->image);
                         unlink('./img/reviews/thumb/'. $r->image);
                $this->Review->delete($id);
            }
            $noticeFlash = array(
                'notice' => 1,
                'noticeFlash' => '<strong>Successfully!</strong> deleted '.$r->title.' from records'
            );
            $this->session->set_userdata($noticeFlash);
           redirect(base_url()."index.php/admin/Reviews");
        }


        public function pages($id=0){

            $d=null;
            $d=$this->Review->find_by($id);

           
            if($d){

                 $data['pages']=$this->Review->allPages($id);
                 $data['id']=$id;
                 $data['d']=$d;
                 if($this->session->userdata('notice')== 1){
               $data['notice']=$this->session->userdata('noticeFlash');
               $this->session->unset_userdata('notice');
               $this->session->unset_userdata('noticeFlash');
            }
            else if($this->session->userdata('alert') == 2){
             $data['alert']=$this->session->userdata('alertFlash');
                $this->session->unset_userdata('alert');
                $this->session->unset_userdata('alertFlash');
            }
            $this->load->view('admin/header.php',$data);
            $this->load->view('admin/review_pages.php',$data);

        }
        else{

            $data['alert']="Sorry! No record found";
             $this->load->view('admin/header.php',$data);
        }
            }
             public function editPage($id=0){
         
        $data['pages']=$this->Review->find_page_by($id);
        if($data['pages']) {
            if($this->session->userdata('notice')== 1){
                $data['notice']=$this->session->userdata('noticeFlash');
                $this->session->unset_userdata('notice');
                $this->session->unset_userdata('noticeFlash');
            }
            else if($this->session->userdata('alert') == 2){
                $data['alert']=$this->session->userdata('alertFlash');
                $this->session->unset_userdata('alert');
                $this->session->unset_userdata('alertFlash');
            }

            $this->load->view('admin/header.php',$data);
            $this->load->view('admin/edit_review_pages.php', $data);
        }
        else{
            $data['alert']= "<strong>Sorry!</strong> this page does not exist ";
            $this->load->view('admin/header.php',$data);
        }
    }

             public function createPage(){
            $new=$this->input->post();
            $new['created_at']=date('Y-m-d h:i:s');
            $new['updated_at']=date('Y-m-d h:i:s');
            if ($this->Review->insertPage($new)){
                $noticeFlash = array(
                    'notice' => 1,
                    'noticeFlash' => '<strong>Well done!</strong> You successfully posted a page'
                );
                $this->session->set_userdata($noticeFlash);
                redirect(base_url()."index.php/admin/Reviews/pages/".$this->input->post('review_id'));
           }
                  else{
                      $alertFlash = array(
                          'alert' => 2,
                          'alertFlash' => "<strong>OOps!</strong> something went wrong during page posting."
                      );
                      $this->session->set_userdata($alertFlash);
                      redirect(base_url()."index.php/admin/Reviews/pages".$this->input->post('review_id'));
            }
        }

          public function updatePage(){

          $new=$this->input->post();
        $new['updated_at']=date('Y-m-d h:i:s');
        if ($this->Review->updatePage($new)){
            $noticeFlash = array(
                'notice' => 1,
                'noticeFlash' => '<strong>Successfully!</strong> updated the page'
            );
            $this->session->set_userdata($noticeFlash);
            redirect(base_url()."index.php/admin/Reviews/editPage/".$this->input->post('id'));
        }
        else{
            $alertFlash = array(
                'alert' => 2,
                'alertFlash' => "<strong>OOps!</strong> something went wrong during page update."
            );
            $this->session->set_userdata($alertFlash);
            redirect(base_url()."index.php/admin/Reviews/editPage/".$this->input->post('id'));
        }
    }

     public function destroyPage($id=0,$review_id=0){

        if ($this->Review->deletePage($id)){
            $noticeFlash = array(
                'notice' => 1,
                'noticeFlash' => '<strong>Successfully!</strong> deleted the page'
            );
            $this->session->set_userdata($noticeFlash);
             redirect(base_url()."index.php/admin/Reviews/Pages/".$review_id);
        }
        else{
            $alertFlash = array(
                'alert' => 2,
                'alertFlash' => "<strong>OOps!</strong> something went wrong during page delete."
            );
            $this->session->set_userdata($alertFlash);
           redirect(base_url()."index.php/admin/Reviews/Pages/".$review_id);
        }
    }

    }