    <?php
    defined('BASEPATH') OR exit('No direct script access allowed');

    class Brands extends CI_Controller {

        /**
         * Index Page for this controller.
         *
         * Maps to the following URL
         * 		http://example.com/index.php/welcome
         *	- or -
         * 		http://example.com/index.php/welcome/index
         *	- or -
         * Since this controller is set as the default controller in
         * config/routes.php, it's displayed at http://example.com/
         *
         * So any other public methods not prefixed with an underscore will
         * map to /index.php/welcome/<method_name>
         * @see https://codeigniter.com/user_guide/general/urls.html
         */

        function __construct() {
            parent::__construct();
            $this->load->model('admin/Brand');
            $this->load->library('session');
            $haveSess=null;
            $haveSess=$this->session->userdata('userId');
            if(!$haveSess) {
                redirect(base_url()."index.php/admin/Accounts/login");
            }
        }
        public function index() {

            $data['brands']=$this->Brand->all();
            if($this->session->userdata('notice')== 1){
                $data['notice']=$this->session->userdata('noticeFlash');
                $this->session->unset_userdata('notice');
                $this->session->unset_userdata('noticeFlash');
            }
            else if($this->session->userdata('alert') == 2){
                $data['alert']=$this->session->userdata('alertFlash');
                $this->session->unset_userdata('alert');
                $this->session->unset_userdata('alertFlash');
            }
            $this->load->view('admin/header.php',$data);
            $this->load->view('admin/brands.php',$data);


        }
        public function add(){
            $this->load->view('admin/header.php');
            $this->load->view('admin/add_brands.php');
        }
        public function edit($id=0){
            $data['brands']=$this->Brand->find_by($id);
            if($data['brands']) {
                if($this->session->userdata('notice')== 1){
                    $data['notice']=$this->session->userdata('noticeFlash');
                    $this->session->unset_userdata('notice');
                    $this->session->unset_userdata('noticeFlash');
                }
                else if($this->session->userdata('alert') == 2){
                    $data['alert']=$this->session->userdata('alertFlash');
                    $this->session->unset_userdata('alert');
                    $this->session->unset_userdata('alertFlash');
                }

                $this->load->view('admin/header.php',$data);
                $this->load->view('admin/edit_brands.php');
            }
            else{
                $data['alert']= "<strong>Sorry!</strong> this brand does not esit <a href='".base_url()."index.php/admin/Brands' class='alert-link'>Click here</a> to go back to the Brands. ";
                $this->load->view('admin/header.php',$data);
            }


        }
        public function featuredBrands(){

            $data['brands']=$this->Brand->featuredOnlyByPos();
            $this->load->view('admin/header.php');
            $this->load->view('admin/featured_brands.php',$data);
         }
        public function create(){
            if ($d=$this->Brand->insert($this->input->post())){
                    if($this->input->post('is_featured') == 1) {
                    $feature_arr = array();
                    $feature_arr[0] = $d;
                    $this->Brand->insertFeaturedPos($feature_arr);
                }
                $noticeFlash = array(
                    'notice' => 1,
                    'noticeFlash' => '<strong>Successfully!</strong> added the brand'
                );
                $this->session->set_userdata($noticeFlash);
                redirect(base_url()."index.php/admin/Brands");
            }
            else{
                $alertFlash = array(
                    'alert' => 2,
                    'alertFlash' => "<strong>OOps!</strong> something went wrong during brand insertion."
                );
                $this->session->set_userdata($alertFlash);
                redirect(base_url()."index.php/admin/Brands");
            }

        }
        public function update(){
             if ($this->Brand->update($this->input->post())){

                 if($this->input->post('is_featured') == 1) {
                     $feature_arr = array();
                     $feature_arr[0] = $this->input->post('id');
                     $this->Brand->insertFeaturedPos($feature_arr);
                 }
                 else{
                     $feature_arr=array();
                     $feature_arr[0]=$this->input->post('id');
                     $this->Brand->deleteFeatureOnly($feature_arr);

                 }
                $noticeFlash = array(
                    'notice' => 1,
                    'noticeFlash' => '<strong>Successfully!</strong> updated the brand'
                );
                $this->session->set_userdata($noticeFlash);
                redirect(base_url()."index.php/admin/Brands/edit/".$this->input->post('id'));
            }
            else{
                $alertFlash = array(
                    'alert' => 2,
                    'alertFlash' => "<strong>OOps!</strong> something went wrong during brand update."
                );
                $this->session->set_userdata($alertFlash);
                redirect(base_url()."index.php/admin/Brands/edit/".$this->input->post('id'));
            }

        }
        public function show($id){

        }

        function changeFeaturedBrandsPos(){
           $this->Brand->deleteFeatureOnly($this->input->get('positions'));
            $this->Brand->insertFeaturedPos($this->input->get('positions'));
        }
        public function destroy($id=0){
            if ($this->Brand->delete($id)){
                $feature_arr=array();
                $feature_arr[0]=$id;
                $this->Brand->deleteFeatureOnly($feature_arr);
                $noticeFlash = array(
                    'notice' => 1,
                    'noticeFlash' => '<strong>Successfully!</strong> deleted the brand'
                );
                $this->session->set_userdata($noticeFlash);
               redirect(base_url()."index.php/admin/Brands");
            }
            else{
                $alertFlash = array(
                    'alert' => 2,
                    'alertFlash' => "<strong>OOps!</strong> something went wrong during brand delete."
                );
                $this->session->set_userdata($alertFlash);
                redirect(base_url()."index.php/admin/Brands");
            }
        }




    }
