<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Websettings extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     *	- or -
     * 		http://example.com/index.php/welcome/index
     *	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    function __construct() {
        parent::__construct();
        $this->load->model('admin/Websetting');
        $this->load->library('session');
        $haveSess=null;
        $haveSess=$this->session->userdata('userId');
        if(!$haveSess) {
            redirect(base_url()."index.php/admin/Accounts/login");
        }
    }
    public function index(){
        if($data['settings']=$this->Websetting->all()) {
            if ($this->session->userdata('notice') == 1) {
                $data['notice'] = $this->session->userdata('noticeFlash');
                $this->session->unset_userdata('notice');
                $this->session->unset_userdata('noticeFlash');
            } else if ($this->session->userdata('alert') == 2) {
                $data['alert'] = $this->session->userdata('alertFlash');
                $this->session->unset_userdata('alert');
                $this->session->unset_userdata('alertFlash');
            }
            $this->load->view('admin/header.php', $data);
            $this->load->view('admin/websettings.php', $data);
        }
        else{

            $data['alert']="<strong>OOps!</strong> something went wrong during settings update.";
            $this->load->view('admin/header.php', $data);
        }
    }

    public function update(){
    if($this->Websetting->update($this->input->post())){
        $noticeFlash = array(
            'notice' => 1,
            'noticeFlash' => '<strong>Successfully!</strong> updated the settings'
        );
        $this->session->set_userdata($noticeFlash);
        redirect(base_url()."index.php/admin/Websettings");

    }
        else{
            $alertFlash = array(
                'alert' => 2,
                'alertFlash' => "<strong>OOps!</strong> something went wrong during settings update."
            );
            $this->session->set_userdata($alertFlash);
            redirect(base_url()."index.php/admin/Websettings");

        }
    }
}
