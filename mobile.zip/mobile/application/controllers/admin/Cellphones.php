    <?php
    defined('BASEPATH') OR exit('No direct script access allowed');

    class Cellphones extends CI_Controller {

        /**
         * Index Page for this controller.
         *
         * Maps to the following URL
         * 		http://example.com/index.php/welcome
         *	- or -
         * 		http://example.com/index.php/welcome/index
         *	- or -
         * Since this controller is set as the default controller in
         * config/routes.php, it's displayed at http://example.com/
         *
         * So any other public methods not prefixed with an underscore will
         * map to /index.php/welcome/<method_name>
         * @see https://codeigniter.com/user_guide/general/urls.html
         */
        function __construct() {
            parent::__construct();
            $this->load->library('session');
            $this->load->model('admin/Cellphone');
            $this->load->model('admin/Fileupload');
            $this->load->model('admin/Createfolder');
            $this->load->model('admin/Deletefolder');
            $this->load->model('admin/Brand');

            $haveSess=null;
              $haveSess=$this->session->userdata('userId');
        if(!$haveSess) {
            redirect(base_url()."index.php/admin/Accounts/login");
        }
        }
        public function index() {
            $data['cellphones']=$this->Cellphone->all();
            if($this->session->userdata('notice')== 1){

                $data['notice']=$this->session->userdata('noticeFlash');
                $this->session->unset_userdata('notice');
                $this->session->unset_userdata('noticeFlash');
            }
            else if($this->session->userdata('alert') == 2){
                $data['alert']=$this->session->userdata('alertFlash');
                $this->session->unset_userdata('alert');
                $this->session->unset_userdata('alertFlash');
            }

            $this->load->view('admin/header.php',$data);
            $this->load->view('admin/cellphones.php',$data);
        }
        public function add(){
            if($this->session->userdata('notice')== 1){
                $data['notice']=$this->session->userdata('noticeFlash');
                $this->session->unset_userdata('notice');
                $this->session->unset_userdata('noticeFlash');
            }
             if($this->session->userdata('alert') == 2){
                $data['alert']=$this->session->userdata('alertFlash');
                $this->session->unset_userdata('alert');
                $this->session->unset_userdata('alertFlash');
            }
            $data['brands']=$this->Brand->all();
            $this->load->view('admin/header.php',$data);
            $this->load->view('admin/add_cellphones.php',$data);
        }
        public function edit($id=0){
            if($this->session->userdata('notice')== 1){
                $data['notice']=$this->session->userdata('noticeFlash');
                $this->session->unset_userdata('notice');
                $this->session->unset_userdata('noticeFlash');
            }
            if($this->session->userdata('alert') == 2){
                $data['alert']=$this->session->userdata('alertFlash');
                $this->session->unset_userdata('alert');
                $this->session->unset_userdata('alertFlash');
            }
            $data['brands']=$this->Brand->all();
            $data['phonedetail']=$this->Cellphone->find_by($id);
            $this->load->view('admin/header.php',$data);
            $this->load->view('admin/edit_cellphones.php',$data);
        }
        public function create(){
            $this->Createfolder->create($this->input->post('name'),"phones");
            $path='./img/phones/' . $this->input->post('name') . '/';
            $imageData=$this->Fileupload->do_upload($path);
            $new = $this->input->post();
            if ($_FILES['userfile']['name']!=null) {
                if (!isset($imageData['error'])) {
                    $new['image'] =$imageData['upload_data']['file_name'];
                    $new['created_at'] = date('Y-m-d h:i:s');
                    $new['updated_at'] = date('Y-m-d h:i:s');
                    if ($this->Cellphone->insert($new)) {
                        $noticeFlash = array(
                            'notice' => 1,
                            'noticeFlash' => '<strong>Successfully!</strong> added the phone'
                        );
                        $this->session->set_userdata($noticeFlash);
                        redirect(base_url()."index.php/admin/Cellphones");
                    }
                    else {
                        $alertFlash = array(
                            'alert' => 2,
                            'alertFlash' => "<strong>OOps!</strong> something went wrong during phone insertion."
                        );
                        $this->session->set_userdata($alertFlash);
                        redirect(base_url() . "index.php/admin/Cellphones/add");
                    }
                } else {
                    $alertFlash = array(
                        'alert' => 2,
                        'alertFlash' => "<strong>OOps! </strong>" . $imageData['error']
                    );
                    $this->session->set_userdata($alertFlash);
                    redirect(base_url() . "index.php/admin/Cellphones/add");
                }
            }
            else{

                $alertFlash = array(
                    'alert' => 2,
                    'alertFlash' => "<strong>Sorry! </strong> select a phone image in order to proceed. "
                );
                $this->session->set_userdata($alertFlash);
                redirect(base_url() . "index.php/admin/Cellphones/add");
            }
        }
        //////////////////////////////////////////////////////////////
        /////////////Update Function for manage_price and phone edit
        ////////////////////////////////////////////////////////////
        function update(){
            print_r($this->input->post());
            $new=$this->input->post();
            $action="edit";
            if($this->input->post('price') || $this->input->post('price2')){

                if(strcmp($this->input->post('price'),"NaN")==0) {
                    $alertFlash = array(
                        'alert' => 2,
                        'alertFlash' => "<strong>OOps!</strong> something went wrong during price update."
                    );
                    $this->session->set_userdata($alertFlash);
                   redirect(base_url() . "index.php/admin/Cellphones/managecellphonePrice/".$this->input->post('id'));
                }
                $action="managecellphonePrice";
            }

            if($this->input->post('old_name')){
                if(strcmp($this->input->post('old_name'),$this->input->post('name'))!=0) {
                    $path='./img/phones/' . $this->input->post('old_name');
                    chmod($path, 0777);
                    rename($path, './img/phones/' . $this->input->post('name'));
                    unset($new['old_name']);
                }
                }
                if(isset($_FILES['userfile']['name'])){
            if ($_FILES['userfile']['name']!=null) {
                if($this->input->post('old_image')){
                unlink('./img/phones/' . $this->input->post('name') . '/'.$this->input->post('old_image'));
                unlink('./img/phones/' . $this->input->post('name') . '/thumb/'.$this->input->post('old_image'));
             
            }
                $path='./img/phones/' . $this->input->post('name') . '/';
                $imageData=$this->Fileupload->do_upload($path);
                $new['image'] =$imageData['upload_data']['file_name'];
                if (isset($imageData['error'])) {
                    $alertFlash = array(
                        'alert' => 2,
                        'alertFlash' => "<strong>OOps! </strong>" .$imageData['error']
                    );
                    $this->session->set_userdata($alertFlash);
                   redirect(base_url() . "index.php/admin/Cellphones/".$action."/".$this->input->post('id'));
                }
            }
        }
            $new['updated_at'] = date('Y-m-d h:i:s');
            unset($new['old_name']);
               unset($new['old_image']);
                if ($this->Cellphone->update($new)) {
                    $noticeFlash = array(
                        'notice' => 1,
                        'noticeFlash' => '<strong>Successfully!</strong> updated phone info.'
                    );
                    $this->session->set_userdata($noticeFlash);
                    redirect(base_url() . "index.php/admin/Cellphones/".$action."/" . $this->input->post('id'));
                }
            else {
                $alertFlash = array(
                    'alert' => 2,
                    'alertFlash' => "<strong>OOps!</strong> something went wrong during phone update."
                );
                $this->session->set_userdata($alertFlash);
               //redirect(base_url() . "index.php/admin/Cellphones/".$action."/".$this->input->post('id'));
            }


        }

        public function updateDetail(){

            if ($this->Cellphone->updateDetail($this->input->post())) {
                $noticeFlash = array(
                    'notice' => 1,
                    'noticeFlash' => '<strong>Successfully!</strong> updated phone detail.'
                );
                $this->session->set_userdata($noticeFlash);
                redirect(base_url() . "index.php/admin/Cellphones/".edit."/" .$this->input->post('phone_id'));
            }
            else {
                $alertFlash = array(
                    'alert' => 2,
                    'alertFlash' => "<strong>OOps!</strong> something went wrong during phone detail update."
                );
                $this->session->set_userdata($alertFlash);
                redirect(base_url() . "index.php/admin/Cellphones/edit/".$this->input->post('phone_id'));
            }


        }
      public function managecellphonePrice($id=0){

          if($this->session->userdata('notice')== 1){

              $data['notice']=$this->session->userdata('noticeFlash');
              $this->session->unset_userdata('notice');
              $this->session->unset_userdata('noticeFlash');
          }
          if($this->session->userdata('alert') == 2){
              $data['alert']=$this->session->userdata('alertFlash');
              $this->session->unset_userdata('alert');
              $this->session->unset_userdata('alertFlash');
          }
          $data['phonedetail']=$this->Cellphone->find_by($id);
          $data['id']=$id;
          $this->load->view('admin/header.php',$data);
          $this->load->view('admin/manage_cellphone_price.php',$data);
        }

        public function destroy($id=0){
           $result= $this->Cellphone->find_by($id);
            foreach($result as $r){
                $this->Deletefolder->deleteGallery($r->name,null);
                $this->Deletefolder->deleteRoot($r->name,$r->image);
                $this->Cellphone->delete($id);
            }
            $noticeFlash = array(
                'notice' => 1,
                'noticeFlash' => '<strong>Successfully!</strong> deleted '.$r->name.' from records'
            );
            $this->session->set_userdata($noticeFlash);
            redirect(base_url()."index.php/admin/Cellphones");
        }
        public function moreImages($id=0){
            $this->load->view('admin/header.php');
            $this->load->view('admin/image_more_cellphones');
        }

        public function destroySelected(){
            $n=" ";
            $new=$this->input->get('multiselect');
            for($i=0;$i<sizeof($new);$i++) {
                $result = $this->Cellphone->find_by($new[$i]);
                foreach ($result as $r) {
                    $this->Deletefolder->deleteGallery($r->name,null);
                    $this->Deletefolder->deleteRoot($r->name,$r->image);
                        $this->Cellphone->delete($new[$i]);
                }
                $n=$n.$r->name." ";
            }
            $noticeFlash = array(
                'notice' => 1,
                'noticeFlash' => '<strong>Successfully!</strong> deleted all selected phones' . $n . ' from records'
            );
            $this->session->set_userdata($noticeFlash);
          redirect(base_url() . "index.php/admin/Cellphones");
        }

    }
