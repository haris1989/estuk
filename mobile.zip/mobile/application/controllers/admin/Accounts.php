<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Accounts extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     *	- or -
     * 		http://example.com/index.php/welcome/index
     *	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    function __construct() {
            parent::__construct();
            $this->load->model('admin/Brand');
            $this->load->model('admin/Cellphone');
            $this->load->model('admin/Newss');
            $this->load->model('admin/Account');
            $this->load->model('admin/Fileupload');
            $this->load->model('admin/Review');
            $this->load->model('admin/Provider');
            $this->load->library('session');
        }
    public function index(){
          $haveSess=$this->session->userdata('userId');
        if(!$haveSess) {
            redirect(base_url()."index.php/admin/Accounts/login");
        }
        $data['phones']=sizeof($this->Cellphone->all());
        $data['brands']=sizeof($this->Brand->all());
        $data['news']=sizeof($this->Newss->all());
        $data['providers']=sizeof($this->Provider->all());
        $data['reviews']=sizeof($this->Review->all());
        $this->load->view('admin/header.php');
        $this->load->view('admin/accounts.php',$data);
    }
    public function login(){
        
            if($this->session->userdata('userId')) {
                redirect(base_url()."index.php/admin/Accounts");
            }
            else{
                $this->load->view('admin/login.php');
            }
    }
     public function loginCheck(){
     
        if($this->input->post('email') && $this->input->post('password')){
            if($this->Account->find_by($this->input->post('email'),$this->input->post('password'),"admin")){
            
                $newdata = array(
                    'userId' => session_id()
                );

                $this->session->set_userdata($newdata);
            
                redirect(base_url().'index.php/admin/Accounts');

           }
           else{

            redirect(base_url().'index.php/admin/Accounts/login');
           }
        }
        else{

            redirect(base_url().'index.php/admin/Accounts/login');
           }
        
    }
    public function logout(){
        $this->session->unset_userdata('userId');
          redirect(base_url().'index.php/admin/Accounts/login');
        
    }

    public function newForm(){

    }
    public function edit(){

    }
    public function create(){
        $path='./img/user/';
        $imageData=$this->Fileupload->do_upload($path);
        $new = $this->input->post();
        if ($_FILES['userfile']['name']!=null) {
            if (!isset($imageData['error'])) {
                $new['picture'] = $imageData['upload_data']['file_name'];

            } else {
                $alertFlash = array(
                    'alert' => 2,
                    'alertFlash' => "<strong>OOps! </strong>" . $imageData['error']
                );
                $this->session->set_userdata($alertFlash);
                redirect(base_url() . "index.php/Home");
            }
        }

        if ($u_id=$this->Account->insert($new)) {
            $sdata['user_id'] = $u_id;
            $sdata['name'] = $new['name'];
            $sdata['picture'] = $new['picture'];
            $sdata['email'] = $new['email'];
            $this->session->set_userdata($sdata);
            $noticeFlash = array(
                'notice' => 1,
                'noticeFlash' => '<strong>Successfully!</strong> created your account'
            );
            $this->session->set_userdata($noticeFlash);
            redirect(base_url() . "index.php/Home");
        } else {
            $alertFlash = array(
                'alert' => 2,
                'alertFlash' => "<strong>OOps!</strong> something went wrong during phone insertion."
            );
            $this->session->set_userdata($alertFlash);
            redirect(base_url() . "index.php/Home");
        }

    }
    //////////////////////////////////////////////////////////////
    /////////////Update Function for manage_price and phone edit
    ////////////////////////////////////////////////////////////
    function update(){
        $new=$this->input->post();
        $action="edit";

        if ($_FILES['userfile']['name']!=null) {
            if($this->input->post('old_image')){
                unlink('./img/user/'.$this->input->post('old_image'));
                unlink('./img/user/'.'/thumb/'.$this->input->post('old_image'));

            }
            $path='./img/user/';
            $imageData=$this->Fileupload->do_upload($path);
            $new['picture'] =$imageData['upload_data']['file_name'];
            if (isset($imageData['error'])) {
                $alertFlash = array(
                    'alert' => 2,
                    'alertFlash' => "<strong>OOps! </strong>" .$imageData['error']
                );
                $this->session->set_userdata($alertFlash);
                redirect(base_url() . "index.php/Home/edit");
            }
        }
        unset($new['old_image']);
        if ($this->Account->update($new)) {
            $noticeFlash = array(
                'notice' => 1,
                'noticeFlash' => '<strong>Successfully!</strong> updated your info.'
            );
            $this->session->set_userdata($noticeFlash);
            redirect(base_url() . "index.php/Home/edit");
        }
        else {
            $alertFlash = array(
                'alert' => 2,
                'alertFlash' => "<strong>OOps!</strong> something went wrong during profile update."
            );
            $this->session->set_userdata($alertFlash);
            redirect(base_url() . "index.php/Home/edit");
        }


    }

   

    public function show($id){

    }
    public function destroy($id){

    }

}
