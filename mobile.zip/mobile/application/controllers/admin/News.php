<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class News extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model('admin/Newss');
        $this->load->library('session');
        $this->load->model('admin/Fileupload');

    $this->load->library('pagination');
        $haveSess=null;
       $haveSess=$this->session->userdata('userId');
        if(!$haveSess) {
            redirect(base_url()."index.php/admin/Accounts/login");
        }
   }
    public function index() {
        $data['allnews']=$this->Newss->all();
       if($this->session->userdata('notice')== 1){
           $data['notice']=$this->session->userdata('noticeFlash');
           $this->session->unset_userdata('notice');
           $this->session->unset_userdata('noticeFlash');
        }
        else if($this->session->userdata('alert') == 2){
         $data['alert']=$this->session->userdata('alertFlash');
            $this->session->unset_userdata('alert');
            $this->session->unset_userdata('alertFlash');
        }
        $data['news']=$this->Newss->all();
        $this->load->view('admin/header.php',$data);
        $this->load->view('admin/news.php',$data);
    }
    public function newForm(){

        $this->load->view('admin/header.php');
        $this->load->view('admin/add_news.php');


    }
    public function edit($id=0){
         
        $data['news']=$this->Newss->find_by($id);
        if($data['news']) {
            if($this->session->userdata('notice')== 1){
                $data['notice']=$this->session->userdata('noticeFlash');
                $this->session->unset_userdata('notice');
                $this->session->unset_userdata('noticeFlash');
            }
            else if($this->session->userdata('alert') == 2){
                $data['alert']=$this->session->userdata('alertFlash');
                $this->session->unset_userdata('alert');
                $this->session->unset_userdata('alertFlash');
            }

            $this->load->view('admin/header.php',$data);
            $this->load->view('admin/edit_news.php', $data);
        }
        else{
            $data['alert']= "<strong>Sorry!</strong> this news does not esit <a href='".base_url()."index.php/admin/news' class='alert-link'>Click here</a> to go back to the news management. ";
            $this->load->view('admin/header.php',$data);
        }
    }
    public function create(){
            $path='./img/news/';
            $imageData=$this->Fileupload->do_upload($path);
            $new = $this->input->post();
            if ($_FILES['userfile']['name']!=null) {
                if (!isset($imageData['error'])) {
                    $new['banner'] =$imageData['upload_data']['file_name'];
                    $new['created_at'] = date('Y-m-d h:i:s');
                    $new['updated_at'] = date('Y-m-d h:i:s');
                    if ($this->Newss->insert($new)) {
                        $noticeFlash = array(
                            'notice' => 1,
                            'noticeFlash' => '<strong>Successfully!</strong> added the news'
                        );
                        $this->session->set_userdata($noticeFlash);
                        redirect(base_url()."index.php/admin/News");
                    }
                    else {
                        $alertFlash = array(
                            'alert' => 2,
                            'alertFlash' => "<strong>OOps!</strong> something went wrong during news post."
                        );
                        $this->session->set_userdata($alertFlash);
                        redirect(base_url() . "index.php/admin/News");
                    }
                } else {
                    $alertFlash = array(
                        'alert' => 2,
                        'alertFlash' => "<strong>OOps! </strong>" . $imageData['error']
                    );
                    $this->session->set_userdata($alertFlash);
                    redirect(base_url() . "index.php/admin/News");
                }
            }
            else{

                $alertFlash = array(
                    'alert' => 2,
                    'alertFlash' => "<strong>Sorry! </strong> select a phone image in order to proceed. "
                );
                $this->session->set_userdata($alertFlash);
                redirect(base_url() . "index.php/admin/News");
            }
    }
    public function update(){
        $action="edit";
        $new=null;
        $new = $this->input->post();
        if ($_FILES['userfile']['name']!=null) {
                if($this->input->post('old_image')){
                unlink('./img/news/'.$this->input->post('old_image'));
                unlink('./img/news/thumb/'.$this->input->post('old_image'));
             
            }
                $path='./img/news/';
                $imageData=$this->Fileupload->do_upload($path);
                $new['banner'] =$imageData['upload_data']['file_name'];
                if (isset($imageData['error'])) {
                    $alertFlash = array(
                        'alert' => 2,
                        'alertFlash' => "<strong>OOps! </strong>" .$imageData['error']
                    );
                    $this->session->set_userdata($alertFlash);
                    redirect(base_url() . "index.php/admin/News/".$action."/".$this->input->post('id'));
                }
            }
            $new['updated_at'] = date('Y-m-d h:i:s');
               unset($new['old_image']);
                if ($this->Newss->update($new)) {
                    $noticeFlash = array(
                        'notice' => 1,
                        'noticeFlash' => '<strong>Successfully!</strong> updated news info.'
                    );
                    $this->session->set_userdata($noticeFlash);
                    redirect(base_url() . "index.php/admin/News/".$action."/" . $this->input->post('id'));
                }
            else {
                $alertFlash = array(
                    'alert' => 2,
                    'alertFlash' => "<strong>OOps!</strong> something went wrong during news update."
                );
                $this->session->set_userdata($alertFlash);
                redirect(base_url() . "index.php/admin/News/".$action."/".$this->input->post('id'));
            }
    }
    public function show($id){

    }
    public function destroy($id){

        $result=null;
        $result=$this->Newss->find_by($id);
        foreach ($result as $row) {
            unlink('./img/news/'.$row->banner);
                unlink('./img/news/thumb/'.$row->banner);
            
        }
        if ($this->Newss->delete($id)){
            $noticeFlash = array(
                'notice' => 1,
                'noticeFlash' => '<strong>Successfully!</strong> deleted the news'
            );
            $this->session->set_userdata($noticeFlash);
            redirect(base_url()."index.php/admin/news");
        }
        else{
            $alertFlash = array(
                'alert' => 2,
                'alertFlash' => "<strong>OOps!</strong> something went wrong during news delete."
            );
            $this->session->set_userdata($alertFlash);
            redirect(base_url()."index.php/admin/news");
        }
    }

}
