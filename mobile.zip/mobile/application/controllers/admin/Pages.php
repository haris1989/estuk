<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pages extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model('admin/Page');
        $this->load->library('session');

    $this->load->library('pagination');
        $haveSess=null;
          $haveSess=$this->session->userdata('userId');
        if(!$haveSess) {
            redirect(base_url()."index.php/admin/Accounts/login");
        }
   }
    public function index() {
        $data['allpages']=$this->Page->all();
       if($this->session->userdata('notice')== 1){
           $data['notice']=$this->session->userdata('noticeFlash');
           $this->session->unset_userdata('notice');
           $this->session->unset_userdata('noticeFlash');
        }
        else if($this->session->userdata('alert') == 2){
         $data['alert']=$this->session->userdata('alertFlash');
            $this->session->unset_userdata('alert');
            $this->session->unset_userdata('alertFlash');
        }
        $config['base_url'] = base_url()."index.php/admin/Pages/index/";
        $config['total_rows'] = sizeof($data['allpages']);
        $config['per_page'] = 2;
        $config['next_link'] = 'Continue >>';
        $config['next_tag_open'] = '<span class="btn btn-primary">';
        $config['next_tag_close'] = '</span>';
        $config['prev_link'] = '<< Previous';
        $config['prev_tag_open'] = '<span class="btn btn-primary">';
        $config['prev_tag_close'] = '</span>';

        $config['num_tag_open'] = '<span class="btn btn-primary">';
        $config['num_tag_close'] = '</span>';
        $config['cur_tag_open'] = '<span class="btn btn-primary" style="background-color:#19d423;border-color:#19d423;">';
        $config['cur_tag_close'] = '</span>';


        $this->pagination->initialize($config);
        $data['pageNum']= $this->uri->segment(4);
        $data['pages']=$this->Page->all_paginate($config['per_page'], $this->uri->segment(4));
        $this->load->view('admin/header.php',$data);
        $this->load->view('admin/pages.php',$data);
    }
    public function newForm(){

    }
    public function edit($id=0){
         
        $data['pages']=$this->Page->find_by($id);
        if($data['pages']) {
            if($this->session->userdata('notice')== 1){
                $data['notice']=$this->session->userdata('noticeFlash');
                $this->session->unset_userdata('notice');
                $this->session->unset_userdata('noticeFlash');
            }
            else if($this->session->userdata('alert') == 2){
                $data['alert']=$this->session->userdata('alertFlash');
                $this->session->unset_userdata('alert');
                $this->session->unset_userdata('alertFlash');
            }

            $this->load->view('admin/header.php',$data);
            $this->load->view('admin/edit_pages.php', $data);
        }
        else{
            $data['alert']= "<strong>Sorry!</strong> this page does not esit <a href='".base_url()."index.php/admin/Pages' class='alert-link'>Click here</a> to go back to the pages management. ";
            $this->load->view('admin/header.php',$data);
        }
    }
    public function create(){
        $new=$this->input->post();
        $new['created_at']=date('Y-m-d h:i:s');
        $new['updated_at']=date('Y-m-d h:i:s');
        if ($this->Page->insert($new)){
            $noticeFlash = array(
                'notice' => 1,
                'noticeFlash' => '<strong>Well done!</strong> You successfully posted a page'
            );
            $this->session->set_userdata($noticeFlash);
            redirect(base_url()."index.php/admin/Pages");
       }
              else{
                  $alertFlash = array(
                      'alert' => 2,
                      'alertFlash' => "<strong>OOps!</strong> something went wrong during page posting."
                  );
                  $this->session->set_userdata($alertFlash);
                  redirect(base_url()."index.php/admin/Pages");
        }
    }
    public function update(){
          $new=$this->input->post();
        $new['updated_at']=date('Y-m-d h:i:s');
        if ($this->Page->update($new)){
            $noticeFlash = array(
                'notice' => 1,
                'noticeFlash' => '<strong>Successfully!</strong> updated the page'
            );
            $this->session->set_userdata($noticeFlash);
            redirect(base_url()."index.php/admin/Pages/edit/".$this->input->post('id'));
        }
        else{
            $alertFlash = array(
                'alert' => 2,
                'alertFlash' => "<strong>OOps!</strong> something went wrong during page update."
            );
            $this->session->set_userdata($alertFlash);
            redirect(base_url()."index.php/admin/edit/".$this->input->post('id'));
        }
    }
    public function show($id){

    }
    public function destroy($id){
        if ($this->Page->delete($id)){
            $noticeFlash = array(
                'notice' => 1,
                'noticeFlash' => '<strong>Successfully!</strong> deleted the page'
            );
            $this->session->set_userdata($noticeFlash);
            redirect(base_url()."index.php/admin/Pages");
        }
        else{
            $alertFlash = array(
                'alert' => 2,
                'alertFlash' => "<strong>OOps!</strong> something went wrong during page delete."
            );
            $this->session->set_userdata($alertFlash);
            redirect(base_url()."index.php/admin/Pages");
        }
    }

}
