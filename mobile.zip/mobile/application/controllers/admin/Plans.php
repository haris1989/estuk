    <?php
    defined('BASEPATH') OR exit('No direct script access allowed');

    class Plans extends CI_Controller {

        /**
         * Index Page for this controller.
         *
         * Maps to the following URL
         * 		http://example.com/index.php/welcome
         *	- or -
         * 		http://example.com/index.php/welcome/index
         *	- or -
         * Since this controller is set as the default controller in
         * config/routes.php, it's displayed at http://example.com/
         *
         * So any other public methods not prefixed with an underscore will
         * map to /index.php/welcome/<method_name>
         * @see https://codeigniter.com/user_guide/general/urls.html
         */

        function __construct() {
            parent::__construct();
            $this->load->model('admin/Provider');
            $this->load->library('session');
            $haveSess=null;
            $haveSess=$this->session->userdata('userId');
            if(!$haveSess) {
                redirect(base_url()."index.php/admin/Accounts/login");
            }
        }
        public function index() {

            $data['plans']=$this->Provider->all();
            if($this->session->userdata('notice')== 1){
                $data['notice']=$this->session->userdata('noticeFlash');
                $this->session->unset_userdata('notice');
                $this->session->unset_userdata('noticeFlash');
            }
            else if($this->session->userdata('alert') == 2){
                $data['alert']=$this->session->userdata('alertFlash');
                $this->session->unset_userdata('alert');
                $this->session->unset_userdata('alertFlash');
            }
            $this->load->view('admin/header.php',$data);
            $this->load->view('admin/providers.php',$data);


        }
        public function addProvider(){
            $this->load->view('admin/header.php');
            $this->load->view('admin/add_providers.php');
        }
        public function providerPlans($id=0){
             $d=null;
            $d=$this->Provider->find_by($id);

            if($d){

                 $data['plans']=$this->Provider->allPlans($id);
                 $data['id']=$id;
                 $data['d']=$d;
                 if($this->session->userdata('notice')== 1){
               $data['notice']=$this->session->userdata('noticeFlash');
               $this->session->unset_userdata('notice');
               $this->session->unset_userdata('noticeFlash');
            }
            else if($this->session->userdata('alert') == 2){
             $data['alert']=$this->session->userdata('alertFlash');
                $this->session->unset_userdata('alert');
                $this->session->unset_userdata('alertFlash');
            }
            $this->load->view('admin/header.php',$data);
            $this->load->view('admin/plans.php',$data);

        }
        else{

            $data['alert']="Sorry! No record found";
             $this->load->view('admin/header.php',$data);
        }
        }
        public function planFeatures($id=0,$proId=0){
             $d=null;
            $d=$this->Provider->find_plan_by($id);
            $provider=null;
            $provider=$this->Provider->find_by($proId);
            if(isset($d)){

                foreach($provider as $proRow){
                  if($proRow->country == 0){
                  
                  $data['provinceList']=$this->Provider->allCanadaProvince();
                
                }
                else{

                  $data['provinceList']=$this->Provider->allUsaProvince();

                }

                }

                 $data['features']=$this->Provider->allFeatures($id);
                 $data['id']=$id;
                 $data['d']=$d;
                 $data['provider_id']=$proId;
                 $data['provider']=$provider;
                 if($this->session->userdata('notice')== 1){
               $data['notice']=$this->session->userdata('noticeFlash');
               $this->session->unset_userdata('notice');
               $this->session->unset_userdata('noticeFlash');
            }
            else if($this->session->userdata('alert') == 2){
             $data['alert']=$this->session->userdata('alertFlash');
                $this->session->unset_userdata('alert');
                $this->session->unset_userdata('alertFlash');
            }
            $this->load->view('admin/header.php',$data);
            $this->load->view('admin/features.php',$data);

        }
        else{

            $data['alert']="Sorry! No record found";
             $this->load->view('admin/header.php',$data);
        }
        }
        public function edit($id=0){
            $data['providers']=$this->Provider->find_by($id);
            if($data['providers']) {
                if($this->session->userdata('notice')== 1){
                    $data['notice']=$this->session->userdata('noticeFlash');
                    $this->session->unset_userdata('notice');
                    $this->session->unset_userdata('noticeFlash');
                }
                else if($this->session->userdata('alert') == 2){
                    $data['alert']=$this->session->userdata('alertFlash');
                    $this->session->unset_userdata('alert');
                    $this->session->unset_userdata('alertFlash');
                }

                $this->load->view('admin/header.php',$data);
                $this->load->view('admin/edit_providers.php');
            }
            else{
                $data['alert']= "<strong>Sorry!</strong> this brand does not esit <a href='".base_url()."index.php/admin/Plans' class='alert-link'>Click here</a> to go back to the plan providers. ";
                $this->load->view('admin/header.php',$data);
            }


        }
      
        public function create(){
            if ($d=$this->Provider->insert($this->input->post())){
                  
                $noticeFlash = array(
                    'notice' => 1,
                    'noticeFlash' => '<strong>Successfully!</strong> added the plan provider'
                );
                $this->session->set_userdata($noticeFlash);
                redirect(base_url()."index.php/admin/Plans");
            }
            else{
                $alertFlash = array(
                    'alert' => 2,
                    'alertFlash' => "<strong>OOps!</strong> something went wrong during plan provider insertion."
                );
                $this->session->set_userdata($alertFlash);
                redirect(base_url()."index.php/admin/Plans");
            }

        }

        public function createPlan(){
            $new=$this->input->post();
            if ($this->Provider->insertPlan($new)){
                $noticeFlash = array(
                    'notice' => 1,
                    'noticeFlash' => '<strong>Well done!</strong> You successfully posted a plan'
                );
                $this->session->set_userdata($noticeFlash);
                redirect(base_url()."index.php/admin/Plans/providerPlans/".$this->input->post('provider_id'));
           }
                  else{
                      $alertFlash = array(
                          'alert' => 2,
                          'alertFlash' => "<strong>OOps!</strong> something went wrong during plan posting."
                      );
                      $this->session->set_userdata($alertFlash);
                      redirect(base_url()."index.php/admin/Plans/providerPlans".$this->input->post('provider_id'));
            }
        }
        public function createPlanFeature(){
            $new=$this->input->post();
            $prov_id=null;
            $prov_id=$new['prov_id'];
            if ($this->Provider->insertFeature($new)){
                $noticeFlash = array(
                    'notice' => 1,
                    'noticeFlash' => '<strong>Well done!</strong> You successfully posted a feature'
                );
                $this->session->set_userdata($noticeFlash);
                redirect(base_url()."index.php/admin/Plans/planFeatures/".$this->input->post('plan_id')."/".$prov_id);
           }
                  else{
                      $alertFlash = array(
                          'alert' => 2,
                          'alertFlash' => "<strong>OOps!</strong> something went wrong during feature posting."
                      );
                      $this->session->set_userdata($alertFlash);
                      redirect(base_url()."index.php/admin/Plans/planFeatures/".$this->input->post('plan_id')."/".$prov_id);
            }
        }

        public function update(){ 
             if ($this->Provider->update($this->input->post())){
                $noticeFlash = array(
                    'notice' => 1,
                    'noticeFlash' => '<strong>Successfully!</strong> updated the plan provider'
                );
                $this->session->set_userdata($noticeFlash);
                redirect(base_url()."index.php/admin/Plans/edit/".$this->input->post('id'));
            }
            else{
                $alertFlash = array(
                    'alert' => 2,
                    'alertFlash' => "<strong>OOps!</strong> something went wrong during plan provider update."
                );
                $this->session->set_userdata($alertFlash);
                redirect(base_url()."index.php/admin/Plans/edit/".$this->input->post('id'));
            }

        }
        public function destroy($id=0){
            if ($this->Provider->delete($id)){
                $feature_arr=array();
                $feature_arr[0]=$id;
                $noticeFlash = array(
                    'notice' => 1,
                    'noticeFlash' => '<strong>Successfully!</strong> deleted the plan provider'
                );
                $this->session->set_userdata($noticeFlash);
               redirect(base_url()."index.php/admin/Plans");
            }
            else{
                $alertFlash = array(
                    'alert' => 2,
                    'alertFlash' => "<strong>OOps!</strong> something went wrong during plan provider delete."
                );
                $this->session->set_userdata($alertFlash);
                redirect(base_url()."index.php/admin/Plans");
            }
        }

        public function destroyPlan($id=0,$provider_id=0){

        if ($this->Provider->deletePlan($id)){
            $noticeFlash = array(
                'notice' => 1,
                'noticeFlash' => '<strong>Successfully!</strong> deleted the plan'
            );
            $this->session->set_userdata($noticeFlash);
             redirect(base_url()."index.php/admin/Plans/providerPlans/".$provider_id);
        }
        else{
            $alertFlash = array(
                'alert' => 2,
                'alertFlash' => "<strong>OOps!</strong> something went wrong during plan delete."
            );
            $this->session->set_userdata($alertFlash);
            redirect(base_url()."index.php/admin/Plans/providerPlans/".$provider_id);
        }
    }

        public function destroyFeature($id=0,$plan_id=0,$prov_id=0){

        if ($this->Provider->deleteFeature($id)){
            $noticeFlash = array(
                'notice' => 1,
                'noticeFlash' => '<strong>Successfully!</strong> deleted the feature'
            );
            $this->session->set_userdata($noticeFlash);
             redirect(base_url()."index.php/admin/Plans/planFeatures/".$plan_id."/".$prov_id);
        }
        else{
            $alertFlash = array(
                'alert' => 2,
                'alertFlash' => "<strong>OOps!</strong> something went wrong during feature delete."
            );
            $this->session->set_userdata($alertFlash);
            redirect(base_url()."index.php/admin/Plans/planFeatures/".$plan_id."/".$prov_id);
        }
    }

    public function updatePlan(){
        if ($this->Provider->updatePlan($this->input->post())){
                $noticeFlash = array(
                    'notice' => 1,
                    'noticeFlash' => '<strong>Successfully!</strong> updated the plan title'
                );
                $this->session->set_userdata($noticeFlash);
                redirect(base_url()."index.php/admin/Plans/providerPlans/".$this->input->post('provider_id'));
            }
            else{
                $alertFlash = array(
                    'alert' => 2,
                    'alertFlash' => "<strong>OOps!</strong> something went wrong during plan title update."
                );
                $this->session->set_userdata($alertFlash);
                redirect(base_url()."index.php/admin/Plans/providerPlans/".$this->input->post('provider_id'));
            }
    }




    }
