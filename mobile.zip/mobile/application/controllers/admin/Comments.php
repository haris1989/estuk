<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Comments extends CI_Controller
{

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     *        http://example.com/index.php/welcome
     *    - or -
     *        http://example.com/index.php/welcome/index
     *    - or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
     function __construct() {
            parent::__construct();
            $this->load->model('admin/Comment');
            $this->load->library('session');
        }
    public function index(){
       $data['comments']=$this->Comment->all();
            if($this->session->userdata('notice')== 1){
                $data['notice']=$this->session->userdata('noticeFlash');
                $this->session->unset_userdata('notice');
                $this->session->unset_userdata('noticeFlash');
            }
            else if($this->session->userdata('alert') == 2){
                $data['alert']=$this->session->userdata('alertFlash');
                $this->session->unset_userdata('alert');
                $this->session->unset_userdata('alertFlash');
            }

         $this->load->view('admin/header.php',$data);
         $this->load->view('admin/comments.php',$data);
    }
      public function destroy($id=0){
            if ($this->Comment->delete($id)){
                $feature_arr=array();
                $feature_arr[0]=$id;
                
                $noticeFlash = array(
                    'notice' => 1,
                    'noticeFlash' => '<strong>Successfully!</strong> deleted the comment'
                );
                $this->session->set_userdata($noticeFlash);
               redirect(base_url()."index.php/admin/comments");
            }
            else{
                $alertFlash = array(
                    'alert' => 2,
                    'alertFlash' => "<strong>OOps!</strong> something went wrong during comment delete."
                );
                $this->session->set_userdata($alertFlash);
                redirect(base_url()."index.php/admin/comments");
            }
        }
         function create(){
            $new=null;
            $new=$this->input->post();
            $new['created_at'] = date('Y-m-d h:i:s');
            $new['updated_at'] = date('Y-m-d h:i:s');
             unset($new['page']);
        if($this->Comment->insert($new)){
            $noticeFlash = array(
                'notice' => 1,
                'noticeFlash' => '<strong>Successfully!</strong> commented.'
            );
            $this->session->set_userdata($noticeFlash);
             if($this->input->post('news_id')){
          redirect(base_url() . "index.php/Home/News/".$this->input->post('news_id'));
       }
       else if($this->input->post('review_id')){
   redirect(base_url() . "index.php/Home/review/".$this->input->post('review_id')."/".$this->input->post('page'));

       }
       else if($this->input->post('phone_id')){
   redirect(base_url() . "index.php/Home/phoneSpecification/".$this->input->post('phone_id'));

       }
        }
        else{
            $alertFlash = array(
                'alert' => 2,
                'alertFlash' => "<strong>OOps!</strong> something went wrong during comment post."
            );
            $this->session->set_userdata($alertFlash);
            if($this->input->post('news_id')){
           redirect(base_url() . "index.php/Home/News/".$this->input->post('news_id'));
       }
       else if($this->input->post('review_id')){
   redirect(base_url() . "index.php/Home/review/".$this->input->post('review_id')."/".$this->input->post('page'));

       }
       else if($this->input->post('phone_id')){
   redirect(base_url() . "index.php/Home/phoneSpecification/".$this->input->post('phone_id'));

       }
        }
        
    }
    function update(){
            $new=null;
            $new=$this->input->post(); 
            $new['updated_at'] = date('Y-m-d h:i:s');
            unset($new['page']);
        if($this->Comment->update($new)){
            $noticeFlash = array(
                'notice' => 1,
                'noticeFlash' => '<strong>Successfully!</strong> updated your commented.'
            );
            $this->session->set_userdata($noticeFlash);
             if($this->input->post('news_id')){
          redirect(base_url() . "index.php/Home/News/".$this->input->post('news_id'));
       }
       else if($this->input->post('review_id')){
   redirect(base_url() . "index.php/Home/review/".$this->input->post('review_id')."/".$this->input->post('page'));

       }
        else if($this->input->post('phone_id')){
   redirect(base_url() . "index.php/Home/phoneSpecification/".$this->input->post('phone_id'));

       }
        }
        else{
            $alertFlash = array(
                'alert' => 2,
                'alertFlash' => "<strong>OOps!</strong> something went wrong during comment post."
            );
            $this->session->set_userdata($alertFlash);
           if($this->input->post('news_id')){
          redirect(base_url() . "index.php/Home/News/".$this->input->post('news_id'));
       }
       else if($this->input->post('review_id')){
   redirect(base_url() . "index.php/Home/review/".$this->input->post('review_id')."/".$this->input->post('page'));

       }
       else if($this->input->post('phone_id')){
   redirect(base_url() . "index.php/Home/phoneSpecification/".$this->input->post('phone_id'));

       }
        }
        
    }


}