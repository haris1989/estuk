<?php 
class CommonModel extends CI_Model {
	
	public function __construct(){ 
		parent::__construct();
		$this->load->database();
	}

	public function insert($table, $datarray){
		
		$this->db->insert($table, $datarray);
		$status = $this->db->affected_rows() > 0 ? TRUE : FALSE;
		return $status;
	}	//returns void or true/false

	public function select($table, $field, $data){
		$query= $this->db->where($field,$data)->get($table);
		return $query->result();
	}

	public function selectArray($table, $field, $data){
		$query = $this->db->where($field,$data)->get($table);
		return $query->result_array();
	}

	public function groupbyArray($table,$attr,$attrgroupby, $where, $order){ 
		 $query = $this->db->select("$attr, COUNT($attrgroupby) AS total")
						->where($where)
						->group_by($attrgroupby)
						->order_by("total", $order)
						->get($table);
		 return $query->result_array();	 
	}

	public function simpleQuery ($q){
		$query = $this->db->query($q);
		return  $query->result_array();
	}

	public function simpleQueryMysql ($q){
		return $this->db->query($q);
		//return  $query();
	}

	public function simpleQueryObj ($q){
		$query = $this->db->query($q);
		return $query->result();
	}

	public function delete ($table, $field, $data){
		$this->db->where($field, $data);
		$this->db->delete($table); 	// return rows ?
	}

	public function deleteAll ($table){
		$this->db->delete($table); 	
	}

	public function update ($table, $field, $olddata, $newdata){
		$this->db->where($field, $olddata);
		$this->db->update($table, $newdata); 
	}
		
	public function generateid($table, $field){
		$row = $this->db->query("SELECT MAX($field) AS maxid FROM $table")->row();
		 return $row;
	}

	public function generatetextid($table,$field){
		$row = $this->db->query("SELECT max(CAST($field AS UNSIGNED)) AS maxid FROM $table")->row();
		return $row;
	}

	public function likefunc($table, $attribute, $value){
		$this->db->like($attribute, $value,"both");
		$res = $this->db->get($table);
		return $res->result();
	}
}
?>