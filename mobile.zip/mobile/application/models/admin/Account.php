<?php
if ( ! defined('BASEPATH'))
    exit('No direct script access allowed');

class Account extends CI_Model{

    public function __construct()
    {
        parent::__construct();

        $this->load->database();
    }

    function find_by($email=null,$password=null,$user){
        $this->db->from($user);
        $this->db->where('email',$email);
        $this->db->where('password',$password);
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->row();
            return $row;
        }
        else{
            return false;
        }
    }
    function find_by_id($id=0,$user){
        $this->db->from($user);
        $this->db->where('id',$id);
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $done = $query->result();
            return $done;
        }
        else{
            return false;
        }
    }
    function insert($newData){
        $id=null;
        $done = $this->db->insert('user',$newData);
        $id=$this->db->insert_id();
        return $id;
    }
    function update($newData){
        $this->db->where('id', $newData['id']);
        $done=$this->db->update('user',$newData);
        return $done;
    }
 
  
  


}


?>