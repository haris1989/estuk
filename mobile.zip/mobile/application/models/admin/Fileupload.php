<?php
if ( ! defined('BASEPATH'))
    exit('No direct script access allowed');

class Fileupload extends CI_Model{
    //initialize the path where you want to save your images
    function __construct(){
        parent::__construct();
        $this->load->library('image_lib');
    }

    function do_upload($path=null){
        echo $path;

        if ($path) {
            $config = array(
                'upload_path'   => $path,
                'allowed_types' => 'jpg|png',
                'min_width'     => '600'

            );

            $this->load->library('upload', $config);

            if ( ! $this->upload->do_upload()){
                $error = array('error' => $this->upload->display_errors());

                return $error;
            }
            else {
                $data = array('upload_data' => $this->upload->data());
        if ($data) {
                    $config = array(
                        'thumb_marker'   => '_thumb',
                        $config['create_thumb'] = TRUE,
                        'source_image' => $data['upload_data']['full_path'],
                        'new_image' => $path."/thumb",
                        'maintain_ratio' => true,
                        'width' => 139,
                        'height' => 184
                    );
                     //here is the second thumbnail, notice the call for the initialize() function again
                    $this->image_lib->initialize($config);
                    $this->image_lib->resize();
                }
                return $data;

            }
        }
    }

}
?>