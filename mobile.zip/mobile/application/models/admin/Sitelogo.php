<?php
if ( ! defined('BASEPATH'))
    exit('No direct script access allowed');

class Sitelogo extends CI_Model{

    public function __construct(){
        parent::__construct();
        $this->load->database();
    }
    function update($name){
        $this->db->where('id', 1);
        $this->db->set('name',$name);
        $done=$this->db->update('sitelogo');
        return $done;
    }
    function all(){
        $this->db->from('sitelogo');
        $this->db->order_by('id','asc');
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }
    }
}


?>