<?php
if ( ! defined('BASEPATH'))
    exit('No direct script access allowed');

class Review extends CI_Model{
    public function __construct() {
        parent::__construct();
        $this->load->database();
    }
    function insert($newData){
        $done = $this->db->insert('review',$newData);
        $id=$this->db->insert_id();
        return $done;
    }
    function update($newData){
        $this->db->where('id', $newData['id']);
        $done=$this->db->update('review',$newData);
        return $done;
    }
    function find_by($id=0){
        $this->db->select('review.*');
        $this->db->from('review');
        $this->db->where('review.id',$id);
        $this->db->order_by('review.id','asc');
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
                 foreach($row as $r){

                if($r->id==null){
                    $row=null;
                    break;
                }
            }
            return $row;
        }
        else{
            return;
        }
    }
    function all(){
        $this->db->select('review.*,COUNT(review_page.review_id) as "pages"');
        $this->db->from('review');
        $this->db->join('review_page', 'review.id = review_page.review_id', 'left');
        $this->db->group_by('review.id');
        $this->db->order_by('id','desc');
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            foreach($row as $r){

                if($r->id==null){
                    $row=null;
                    break;
                }
            }
            return $row;
        }
        else{
            return;
        }
    }
     function allWrtType($type=0){
        if($type==1){
            $field="provider_id";
        }
        else{
         $field="phone_id";   
        }
        $this->db->select('review.*,COUNT(review_page.review_id) as "pages"');
        $this->db->from('review');
        $this->db->join('review_page', 'review.id = review_page.review_id', 'left');
        $this->db->group_by('review.id');
        $this->db->where($field."!=",0);
        $this->db->order_by('id','desc');
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            foreach($row as $r){

                if($r->id==null){
                    $row=null;
                    break;
                }
            }
            return $row;
        }
        else{
            return;
        }
    }
    function getLatestReviews($type=0){
        if($type==1){
            $field="provider_id";
        }
        else{
         $field="phone_id";   
        }
        $this->db->select('review.*,COUNT(review_page.review_id) as "pages"');
        $this->db->from('review');
        $this->db->join('review_page', 'review.id = review_page.review_id', 'left');
        $this->db->group_by('review.id');
        $this->db->order_by('created_at','desc');
        $this->db->where($field."!=",0);
        $this->db->limit(0,5);
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }
    }

    function all_paginate($type=0,$pernew=0, $uri=0){
        if($type==1){
            $field="provider_id";
        }
        else{
         $field="phone_id";   
        }
        $this->db->select('review.*,COUNT(review_page.review_id) as "pages"');
        $this->db->from('review');
        $this->db->join('review_page', 'review.id = review_page.review_id', 'left');
        $this->db->group_by('review.id');
        $this->db->limit($pernew,$uri);
        $this->db->order_by('created_at','desc');
        $this->db->where($field."!=",0);
        $this->db->limit(0,5);
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }

    }

      function insertPage($data){
        $done=$this->db->insert('review_page',$data);
        return $done;
    }

      function allPages($id=0){
      
        $this->db->from('review_page');
           $this->db->order_by('page_order','asc');
        $this->db->where('review_id',$id);
     
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
          
            return $row;
        }
        else{
            return;
        }
    }

    function updatePage($data){
        $this->db->where('id', $data['id']);
        $done=$this->db->update('review_page',$data);
        return $done;
    }

 function find_page_by($id=0){
        $this->db->from('review_page');
        $this->db->where('id',$id);
        $this->db->order_by('id','asc');
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }

    }
     function find_page_by_number($num=0,$id=0){
        $this->db->from('review_page');
        $this->db->where('page_order',$num);
        $this->db->where('id',$id);
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }

    }

     function delete($id=0){
        $this->db->where('id', $id);
        $done= $this->db->delete('review');
        return $done;
    }
    function deletePage($id=0){
        $this->db->where('id', $id);
        $done= $this->db->delete('review_page');

        return $done;
    }
}
?>