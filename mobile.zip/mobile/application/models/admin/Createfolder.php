<?php

/**
 * Created by PhpStorm.
 * User: Hp
 * Date: 4/24/2016
 * Time: 12:39 AM
 */
if ( ! defined('BASEPATH'))
    exit('No direct script access allowed');
class Createfolder  extends CI_Model{

    function create($name=null,$controller_name=null){
        if ($name && $controller_name) {
            if (!is_dir("./img/".$controller_name."/" .$name)) {
                mkdir("./img/".$controller_name."/" .$name, 0777, true);
            }
            if (!is_dir("./img/".$controller_name."/" .$name . "/thumb")) {
                mkdir("./img/".$controller_name."/" .$name . "/thumb", 0777, true);
            }
            if (!is_dir("./img/".$controller_name."/" .$name . "/gallery")) {
                mkdir("./img/".$controller_name."/" .$name . "/gallery", 0777, true);
            }
            if (!is_dir("./img/".$controller_name."/" .$name . "/gallery/thumb")) {
                mkdir("./img/".$controller_name."/" .$name . "/gallery/thumb", 0777, true);
            }
        }
    }

}