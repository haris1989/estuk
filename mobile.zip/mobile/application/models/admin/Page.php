<?php
if ( ! defined('BASEPATH'))
    exit('No direct script access allowed');

class Page extends CI_Model{

    public function __construct()
    {
        parent::__construct();

        $this->load->database();
    }

    function insert($data){
        $done=$this->db->insert('page',$data);
        return $done;
    }

    function update($data){
        $this->db->where('id', $data['id']);
        $done=$this->db->update('page',$data);
        return $done;
    }

    function find_by($id){
        $this->db->from('page');
        $this->db->where('id',$id);
        $this->db->order_by('id','asc');
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }

    }
    function all_paginate($perPage, $uri){
        $this->db->from('page');
        $this->db->limit($perPage,$uri);
        $this->db->order_by('page_order','asc');
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }
    }
    function all(){
        $this->db->from('page');
        $this->db->order_by('page_order','asc');
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }
    }

    function delete($id=0){
        $this->db->where('id', $id);
        $done= $this->db->delete('page');

        return $done;
    }


}


?>