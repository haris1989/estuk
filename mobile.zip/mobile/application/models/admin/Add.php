<?php
if ( ! defined('BASEPATH'))
    exit('No direct script access allowed');

class Add extends CI_Model{

    public function __construct()
    {
        parent::__construct();

        $this->load->database();
    }

    function insert($data){
        $done=$this->db->insert('add',$data);
        return $done;
    }

    function update($data){
        $this->db->where('id', $data['id']);
        $done=$this->db->update('add',$data);
        return $done;
    }

    function find_by($id){
        $this->db->from('add');
        $this->db->where('id',$id);
        $this->db->order_by('id','asc');
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return fasle;
        }

    }
    function all_paginate($perPage, $uri){
        $this->db->from('add');
        $this->db->limit($perPage,$uri);
        $this->db->order_by('id','asc');
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }
    }
    function all(){
        $this->db->from('add');
        $this->db->order_by('id','asc');
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }
    }

    function delete($id=0){
        $this->db->where('id', $id);
        $done= $this->db->delete('add');

        return $done;
    }


}


?>