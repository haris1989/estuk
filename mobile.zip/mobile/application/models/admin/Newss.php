<?php
if ( ! defined('BASEPATH'))
    exit('No direct script access allowed');

class Newss extends CI_Model{

    public function __construct()
    {
        parent::__construct();

        $this->load->database();
    }

    function insert($data){
        $done=$this->db->insert('news',$data);
        return $done;
    }

    function update($data,$id=0){
        $this->db->where('id', $data['id']);
        echo $data['banner'];
        $done=$this->db->update('news',$data);
        return $done;
    }

    function find_by($id){
        $this->db->from('news');
        $this->db->where('id',$id);
        $this->db->order_by('id','asc');
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }

    }
    function all_paginate($pernew, $uri){
        $this->db->from('news');
        $this->db->limit($pernew,$uri);
        $this->db->order_by('id','asc');
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }
    }
    function all(){
        $this->db->from('news');
        $this->db->order_by('id','asc');
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }
    }

    function delete($id=0){
        $this->db->where('id', $id);
        $done= $this->db->delete('news');

        return $done;
    }

     function getLatestNews(){
        $this->db->from('news');
        $this->db->order_by('created_at','desc');
        $this->db->limit(0,5);
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }
    }


}


?>