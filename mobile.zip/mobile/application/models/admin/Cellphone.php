<?php
if ( ! defined('BASEPATH'))
    exit('No direct script access allowed');

class Cellphone extends CI_Model{
    public function __construct() {
        parent::__construct();
        $this->load->database();
    }
    function insert($newData){
        $done = $this->db->insert('cellphone',$newData);
         $id=$this->db->insert_id();

        $data=array(
            'phone_id' => $id
        );
        $done=$this->db->insert('phone_detail',$data);
        return $done;
    }
    function update($newData){
        $this->db->where('id', $newData['id']);
        $done=$this->db->update('cellphone',$newData);
        return $done;
    }
    function updateDetail($newData){
        $this->db->where('phone_id', $newData['phone_id']);
        $done=$this->db->update('phone_detail',$newData);
        return $done;
    }
    function find_by_name($name=0,$country=0){
        if($country==1){
            $field="price";
        }
        else{
            $field="price2";
        }
        $this->db->where($field."!=",0);
        $this->db->select('cellphone.* , phone_detail.* , brand.id as "b_id" ,brand.name as "brand_name",TRUNCATE(AVG(rating.perfomance),1) as "rate_perfomance",TRUNCATE(AVG(rating.design),1) as "rate_design",TRUNCATE(AVG(rating.feature),1) as "rate_feature",COUNT(cellphone.id) as total_phone ');
        $this->db->from('cellphone');
        $this->db->join('brand', 'cellphone.brand_id = brand.id', 'inner');
        $this->db->join('phone_detail', 'cellphone.id = phone_detail.phone_id', 'inner');
        $this->db->join('rating', 'cellphone.id = rating.phone_id', 'left');
        $this->db->where('cellphone.name',$name);
        $this->db->order_by('cellphone.id','asc');
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }
    }
    function find_by($id=0,$country=0){
        if($country==1){
            $field="price";
        }
        else{
            $field="price2";
        }
        $this->db->where($field."!=",0);
        $this->db->select('cellphone.* , phone_detail.* , brand.id as "b_id" ,brand.name as "brand_name",TRUNCATE(AVG(rating.perfomance),1) as "rate_perfomance",TRUNCATE(AVG(rating.design),1) as "rate_design",TRUNCATE(AVG(rating.feature),1) as "rate_feature",COUNT(cellphone.id) as total_phone ');
        $this->db->from('cellphone');
        $this->db->join('brand', 'cellphone.brand_id = brand.id', 'inner');
        $this->db->join('phone_detail', 'cellphone.id = phone_detail.phone_id', 'inner');
        $this->db->join('rating', 'cellphone.id = rating.phone_id', 'left');
        $this->db->where('cellphone.id',$id);
        $this->db->order_by('cellphone.id','asc');
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }
    }
    function allForSearch($country=0){
        if($country==1){
            $field="price";
        }
        else{
            $field="price2";
        }
        $this->db->where($field."!=",0);
        $this->db->select('cellphone.*,brand.name as "brand",TRUNCATE(AVG(rating.perfomance),1) as "rate_perfomance",TRUNCATE(AVG(rating.design),1) as "rate_design",TRUNCATE(AVG(rating.feature),1) as "rate_feature",COUNT(cellphone.id) as total_phone');
        $this->db->from('cellphone');
        $this->db->join('rating', 'cellphone.id = rating.phone_id', 'left');
        $this->db->join('brand', 'brand.id = cellphone.brand_id', 'inner');
        $this->db->group_by('cellphone.id');
        $this->db->order_by('name','asc');
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }
    }
    function all(){
        $this->db->select('cellphone.*,brand.name as "brand",TRUNCATE(AVG(rating.perfomance),1) as "rate_perfomance",TRUNCATE(AVG(rating.design),1) as "rate_design",TRUNCATE(AVG(rating.feature),1) as "rate_feature",COUNT(cellphone.id) as total_phone');
        $this->db->from('cellphone');
        $this->db->join('rating', 'cellphone.id = rating.phone_id', 'left');
        $this->db->join('brand', 'brand.id = cellphone.brand_id', 'inner');
         $this->db->group_by('cellphone.id');
        $this->db->order_by('name','asc');
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }
    }
      function allByCountry($country=0){
        if($country==1){
            $field="price";
        }
        else{
         $field="price2";
        }

        $this->db->select('cellphone.*,brand.name as "brand",TRUNCATE(AVG(rating.perfomance),1) as "rate_perfomance",TRUNCATE(AVG(rating.design),1) as "rate_design",TRUNCATE(AVG(rating.feature),1) as "rate_feature",COUNT(cellphone.id) as total_phone');
        $this->db->from('cellphone');
        $this->db->join('rating', 'cellphone.id = rating.phone_id', 'left');
        $this->db->join('brand', 'brand.id = cellphone.brand_id', 'inner');
        $this->db->group_by('cellphone.id');
        $this->db->where($field."!=",0);
        $this->db->order_by('name','asc');
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }
    }
    function getIndividualPhoneAvgPerfomanceRating($id=0){
          $this->db->select('AVG(rating.perfomance) as "perfomance"');
          $this->db->from('rating');
          $this->db->from('phone_id',$id);
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }
    }
    function getIndividualPhoneAvgFeatureRating($id=0){
          $this->db->select('AVG(rating.feature) as "feature"');
          $this->db->from('rating');
          $this->db->from('phone_id',$id);
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }
    }
       function getIndividualPhoneAvgDesignRating($id=0){
          $this->db->select('AVG(rating.design) AS "design"');
          $this->db->from('rating');
          $this->db->from('phone_id',$id);
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }
    }
    function getIndividualPhoneTotalRating($id=0){
         $this->db->select('(AVG(rating.design)+AVG(rating.perfomance)+AVG(rating.feature))/3 AS "individual_rating"');
          $this->db->from('rating');
          $this->db->where('phone_id',$id);
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }
    }
    function getAllPhoneTotalRating($id=0){
         $this->db->select('(AVG(rating.design)+AVG(rating.perfomance)+AVG(rating.feature))/3 AS "total_rating"');
          $this->db->from('rating');
          $this->db->group_by('phone_id');
          $this->db->order_by('"total_rating', 'desc');
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }
    }
    function getPhoneVisits($country=0){
    if($country==1){
            $field="price";
        }
        else{
         $field="price2";
        }

        $this->db->select('cellphone.*,TRUNCATE(AVG(rating.perfomance),1) as "rate_perfomance",TRUNCATE(AVG(rating.design),1) as "rate_design",TRUNCATE(AVG(rating.feature),1) as "rate_feature",COUNT(cellphone.id) as total_phone');
        $this->db->from('cellphone');
        $this->db->join('rating', 'cellphone.id = rating.phone_id', 'left');
         $this->db->group_by('cellphone.id');
        $this->db->order_by('visits','desc');
        $this->db->where($field."!=",0);
        $this->db->limit(0,4);
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }
    }
    function getLatestPhones($country=0){
           if($country==1){
            $field="price";
        }
        else{
         $field="price2";
        }

        $this->db->select('cellphone.*,brand.name as "brand",TRUNCATE(AVG(rating.perfomance),1) as "rate_perfomance",TRUNCATE(AVG(rating.design),1) as "rate_design",TRUNCATE(AVG(rating.feature),1) as "rate_feature",COUNT(cellphone.id) as total_phone');
        $this->db->from('cellphone');
        $this->db->join('rating', 'cellphone.id = rating.phone_id', 'left');
        $this->db->join('brand', 'brand.id = cellphone.brand_id', 'inner');
        $this->db->group_by('cellphone.id');
        $this->db->order_by('created_at','desc');
        $this->db->where($field."!=",0);
        $this->db->limit(0,5);
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }
    }
        function getPhonesByBrands($country=0,$brand_id=0){
           if($country==1){
            $field="price";
        }
        else{
         $field="price2";
        }

        $this->db->select('cellphone.*,brand.name as "brand",TRUNCATE(AVG(rating.perfomance),1) as "rate_perfomance",TRUNCATE(AVG(rating.design),1) as "rate_design",TRUNCATE(AVG(rating.feature),1) as "rate_feature",COUNT(cellphone.id) as total_phone');
        $this->db->from('cellphone');
        $this->db->join('rating', 'cellphone.id = rating.phone_id', 'left');
        $this->db->join('brand', 'brand.id = cellphone.brand_id', 'inner');
        $this->db->group_by('cellphone.id');
        $this->db->order_by('created_at','desc');
        $this->db->where("cellphone.brand_id",$brand_id);
        $this->db->where($field."!=",0);
        $this->db->limit(0,5);
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }
    }
    function delete($id=0){
        $this->db->where('id', $id);
        $done= $this->db->delete('cellphone');
        return $done;
    }
    function searchByPrice($min=0,$max=0,$country=0){
        if($country==1){
            $field="price";
        }
        else{
         $field="price2";
        }


        $this->db->select('cellphone.* , phone_detail.* , brand.id as "b_id" ,brand.name as "brand_name" ');
        $this->db->from('cellphone');
        $this->db->join('brand', 'cellphone.brand_id = brand.id', 'inner');
        $this->db->join('phone_detail', 'cellphone.id = phone_detail.phone_id', 'inner');
        if($max==0){
        $this->db->where("$field >=",$min);
        }
        else if($min==0){
        $this->db->where("$field <=",$max);
        }
        else{
        $this->db->where("$field BETWEEN $min AND $max");
        }
        $this->db->order_by('cellphone.id','asc');
        $this->db->where($field."!=",0);
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }

      }
         function all_paginate($min=0,$max=0,$country=0,$perPage,$uri){
        if($country==1){
            $field="price";
        }
        else{
         $field="price2";
        }


        $this->db->select('cellphone.* , phone_detail.* , brand.id as "b_id" ,brand.name as "brand_name" ');
        $this->db->from('cellphone');
        $this->db->join('brand', 'cellphone.brand_id = brand.id', 'inner');
        $this->db->join('phone_detail', 'cellphone.id = phone_detail.phone_id', 'inner');
        if($max==0){
        $this->db->where("$field >=",$min);
        }
        else if($min==0){
        $this->db->where("$field <=",$max);
        }
        else{
        $this->db->where("$field BETWEEN $min AND $max");
        }
        $this->db->order_by('cellphone.id','asc');
        $this->db->where($field."!=",0);
        $this->db->limit($perPage,$uri);
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }
    }
     function all_paginate_by_brands($perPage=0,$uri=0,$country=0,$brand=0){
        if($country==1){
            $field="price";
        }
        else{
         $field="price2";
        }
        $this->db->select('cellphone.* , phone_detail.* , brand.id as "b_id" ,brand.name as "brand_name" ');
        $this->db->from('cellphone');
        $this->db->join('brand', 'cellphone.brand_id = brand.id', 'inner');
        $this->db->join('phone_detail', 'cellphone.id = phone_detail.phone_id', 'inner');
        $this->db->order_by('cellphone.id','asc');
        $this->db->where("cellphone.brand_id",$brand);
        $this->db->where($field."!=",0);
        $this->db->limit($perPage,$uri);
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }
    }

     function all_paginatePhones($perPage,$uri,$country=0){
          if($country==1){
            $field="price";
        }
        else{
         $field="price2";
        }
        $this->db->select('cellphone.* , phone_detail.* , brand.id as "b_id" ,brand.name as "brand_name" ');
        $this->db->from('cellphone');
        $this->db->join('brand', 'cellphone.brand_id = brand.id', 'inner');
        $this->db->join('phone_detail', 'cellphone.id = phone_detail.phone_id', 'inner');
        $this->db->order_by('cellphone.id','desc');
        $this->db->where($field."!=",0);
        $this->db->limit($perPage,$uri);
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }
    }
}
?>