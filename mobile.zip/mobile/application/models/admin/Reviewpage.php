<?php
if ( ! defined('BASEPATH'))
    exit('No direct script access allowed');

class Reviewpage extends CI_Model{
    public function __construct() {
        parent::__construct();
        $this->load->database();
    }
    function insert($newData){
        $done = $this->db->insert('review_page',$newData);
        $id=$this->db->insert_id();
        return $done;
    }
    function update($newData){
        $this->db->where('id', $newData['id']);
        $done=$this->db->update('review_page',$newData);
        return $done;
    }
    function find_by($id=0){
       
        $this->db->from('review_page');
        $this->db->order_by('review.id','asc');
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }
    }
    function all(){

        $this->db->from('review_page');
        $this->db->order_by('id','asc');
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }
    }


     function delete($id=0){
        $this->db->where('id', $id);
        $done= $this->db->delete('review_page');
        return $done;
    }
}
?>