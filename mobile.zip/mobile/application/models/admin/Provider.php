    <?php
    if ( ! defined('BASEPATH'))
        exit('No direct script access allowed');

    class Provider extends CI_Model{

        public function __construct()
        {
            parent::__construct();

            $this->load->database();
        }

        function allCanadaProvince(){
            $this->db->from('canada_province');
            $this->db->order_by('id','asc');
              $query = $this->db->get();
            if ( $query->num_rows() > 0 ){
                $row = $query->result();
                return $row;
            }
            else{
                return;
            }

        }

           function allUsaProvince(){
            $this->db->from('usa_state');
            $this->db->order_by('id','asc');
              $query = $this->db->get();
            if ( $query->num_rows() > 0 ){
                $row = $query->result();
                return $row;
            }
            else{
                return;
            }

        }
         function allForSearch($country=0){
        $this->db->from('provider');
        $this->db->where('country',$country);
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }
    }

        function getAllPlansByPrice($min=0,$max=0,$type=0){
            if($type==0){
                $province="canada_province";
            }
            else{
                $province="usa_state";
            }
        $this->db->select('plan_feature.*,'.$province.'.name AS province_name,provider.name AS provider_name,provider.logo AS logo,provider_plan.name AS plan_name');
        $this->db->from('plan_feature');
        if($type==0){
        $this->db->join('canada_province', 'plan_feature.cad_province_id = canada_province.id', 'left');
    }
    else{
         $this->db->join('usa_state', 'plan_feature.usa_province_id = usa_state.id', 'left');
     }
        $this->db->join('provider', 'plan_feature.prov_id = provider.id', 'left');
        $this->db->join('provider_plan', 'plan_feature.plan_id = provider_plan.id', 'left');
        $this->db->group_by('plan_feature.id');
        $this->db->order_by('plan_feature.id','asc');
        $this->db->where("provider.country",$type);
      if($max==0){
        $this->db->where("plan_feature.price >=",$min);
        }
        else if($min==0){
        $this->db->where("plan_feature.price <=",$max);
        }
        else{
        $this->db->where("plan_feature.price BETWEEN $min AND $max");
        }
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
          
            return $row;
        }
        else{
            return;
        }


        }

        function getAllPlansByProvince($provinceId=0,$type=0){
            if($type==0){
                $province="canada_province";
            }
            else{
                $province="usa_state";
            }
        $this->db->select('plan_feature.*,'.$province.'.name AS province_name,provider.name AS provider_name,provider.logo AS logo,provider_plan.name AS plan_name');
        $this->db->from('plan_feature');
        if($type==0){
        $this->db->join('canada_province', 'plan_feature.cad_province_id = canada_province.id', 'left');
    }
    else{
         $this->db->join('usa_state', 'plan_feature.usa_province_id = usa_state.id', 'left');
     }
        $this->db->join('provider', 'plan_feature.prov_id = provider.id', 'left');
        $this->db->join('provider_plan', 'plan_feature.plan_id = provider_plan.id', 'left');
        $this->db->group_by('plan_feature.id');
        $this->db->order_by('plan_feature.id','asc');
        if($type==0){
        $this->db->where('cad_province_id',$provinceId);
        }
        else{

         $this->db->where('usa_province_id',$provinceId);   
        }

     
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
          
            return $row;
        }
        else{
            return;
        }


        }



        function insert($data){
            $this->db->insert('provider',$data);
            $done = $this->db->insert_id();
            return $done;
        }

        function featuredOnly($type=0){
            $this->db->select('provider.*,COUNT(provider_plan.provider_id) AS number_of_plans');
            $this->db->from('provider');
            $this->db->join('provider_plan', 'provider_plan.provider_id = provider.id', 'left');
            $this->db->group_by('provider.id');
            $this->db->where('is_featured',1);
            $this->db->where('country',$type);
            $this->db->order_by('name','asc');
           
            $query = $this->db->get();
            if ( $query->num_rows() > 0 ){
                $row = $query->result();
                return $row;
            }
            else{
                return;
            }

        }

        function update($data){
            $this->db->where('id', $data['id']);
            $done=$this->db->update('provider',$data);
            return $done;
        }

        function updatePlan($data){
            $this->db->where('id', $data['id']);
            $done=$this->db->update('provider_plan',$data);
            return $done;
        }

        function find_by($id=0,$country=0){
            if($country > 0){
                $this->db->where('country',$country);
            }
            $this->db->from('provider');
            $this->db->where('id',$id);
            $this->db->order_by('id','asc');
            $query = $this->db->get();
            if ( $query->num_rows() > 0 ){
                $row = $query->result();
                return $row;
            }
            else{
                return;
            }

        }
        function find_by_name($name=null,$country=0){
            if($country > 0){
                $this->db->where('country',$country);
            }
            $this->db->from('provider');
            $this->db->where('name',$name);
            $query = $this->db->get();
            if ( $query->num_rows() > 0 ){
                $row = $query->result();
                return $row;
            }
            else{
                return;
            }

        }

        function find_plan_by($id){
            $this->db->from('provider_plan');
            $this->db->where('id',$id);
            $this->db->order_by('id','asc');
            $query = $this->db->get();
            if ( $query->num_rows() > 0 ){
                $row = $query->result();
                return $row;
            }
            else{
                return;
            }

        }

        function allFeatures($id=0,$type=0){
            if($type==0){
                $province="canada_province";
            }
            else{
                $province="usa_state";
            }
             $this->db->select('plan_feature.*,'.$province.'.name AS province_name');
        $this->db->from('plan_feature');
        if($type==0){
        $this->db->join('canada_province', 'plan_feature.cad_province_id = canada_province.id', 'left');
    }
    else{
         $this->db->join('usa_state', 'plan_feature.usa_province_id = usa_state.id', 'left');
     }
        $this->db->group_by('plan_feature.id');
        $this->db->order_by('plan_feature.id','asc');
        $this->db->where('plan_id',$id);
     
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
          
            return $row;
        }
        else{
            return;
        }

    }


        function allPlans($id=0){
        
         $this->db->select('provider_plan.*,COUNT(plan_feature.plan_id) AS number_of_features');
            $this->db->from('provider_plan');
            $this->db->join('plan_feature', 'plan_feature.plan_id = provider_plan.id', 'left');
            $this->db->group_by('provider_plan.id');
            $this->db->order_by('provider_plan.id','asc');
            $this->db->where('provider_plan.provider_id',$id);
     
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
          
            return $row;
        }
        else{
            return;
        }

    }
  function getLatestProvider($country=0){
        
         $this->db->select('provider.*,COUNT(provider_plan.provider_id) AS number_of_plans');
            $this->db->from('provider');
            $this->db->join('provider_plan', 'provider_plan.provider_id = provider.id', 'left');
            $this->db->group_by('provider.id');
            $this->db->order_by('id','desc');
            $this->db->where("country",$country);
     
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
          
            return $row;
        }
        else{
            return;
        }

    }
    function insertPlan($data){
        $done=$this->db->insert('provider_plan',$data);
        return $done;
    }

    function insertFeature($data){
        $done=$this->db->insert('plan_feature',$data);
        return $done;
    }
      function getProviderVisits($country=0){
      $this->db->select('provider.*,COUNT(provider_plan.provider_id) AS number_of_plans');
            $this->db->from('provider');
            $this->db->join('provider_plan', 'provider_plan.provider_id = provider.id', 'left');
            $this->db->group_by('provider.id');
            $this->db->where("country",$country);
        $this->db->order_by('visits','desc');
        $this->db->limit(0,4);
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }
    }

        function all(){
             $this->db->select('provider.*,COUNT(provider_plan.provider_id) AS number_of_plans');
            $this->db->from('provider');
            $this->db->join('provider_plan', 'provider_plan.provider_id = provider.id', 'left');
            $this->db->group_by('provider.id');
            $this->db->order_by('name','asc');

            $query = $this->db->get();
            
            if ( $query->num_rows() > 0 ){
                $row = $query->result();
                return $row;
            }
            else{
                return null;
            }
        }


        function delete($id=0){
            $this->db->where('id', $id);
            $done= $this->db->delete('provider');

            return $done;
        }

        function deletePlan($id=0){
        $this->db->where('id', $id);
        $done= $this->db->delete('provider_plan');

        return $done;
    }

    function deleteFeature($id=0){
        $this->db->where('id', $id);
        $done= $this->db->delete('plan_feature');

        return $done;
    }
    }




    ?>