    <?php
    if ( ! defined('BASEPATH'))
        exit('No direct script access allowed');

    class Comment extends CI_Model{

        public function __construct()
        {
            parent::__construct();

            $this->load->database();
        }

        function insert($data){
            $this->db->insert('comment',$data);
            $done = $this->db->insert_id();
            return $done;
        }

        function update($data){
            $this->db->where('id', $data['id']);
            $done=$this->db->update('comment',$data);
            return $done;
        }

        function find_by($id){
            $this->db->from('comment');
            $this->db->where('id',$id);
            $this->db->order_by('id','asc');
            $query = $this->db->get();
            if ( $query->num_rows() > 0 ){
                $row = $query->result();
                return $row;
            }
            else{
                return;
            }

        }

        function all(){
            $this->db->select('user.picture AS picture,user.name AS name,user.website AS website, comment.*');
            $this->db->from('comment');
            $this->db->join('user', 'user.id = comment.user_id', 'inner');
            $this->db->order_by('updated_at','desc');
            $query = $this->db->get();
            if ( $query->num_rows() > 0 ){
                $row = $query->result();
                return $row;
            }
            else{
                return;
            }
        }

        function find_by_type($id=0,$type=''){
            $this->db->select('user.picture AS picture,user.name AS name,user.website AS website, comment.*');
            $this->db->from('comment');
            $this->db->join('user', 'user.id = comment.user_id', 'inner');
            $this->db->where($type,$id);
            $this->db->order_by('created_at','desc');
            $query = $this->db->get();
            if ( $query->num_rows() > 0 ){
                $row = $query->result();
                return $row;
            }
            else{
                return;
            }
        }


        function delete($id=0){
            $this->db->where('id', $id);
            $done= $this->db->delete('comment');

            return $done;
        }

       



    }


    ?>