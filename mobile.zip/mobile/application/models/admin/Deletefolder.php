<?php

/**
 * Created by PhpStorm.
 * User: Hp
 * Date: 4/24/2016
 * Time: 12:39 AM
 */
if ( ! defined('BASEPATH'))
    exit('No direct script access allowed');
class Deletefolder  extends CI_Model{

    function deleteRoot($name=null,$image=null){
        unlink('./img/phones/'.$name.'/'.$image);
        unlink('./img/phones/'.$name.'/thumb/'.$image);

        rmdir('./img/phones/'.$name.'/thumb/');
        rmdir('./img/phones/'.$name);
    }
    function deleteGallery($name=null,$image=null){
        if($image!=null){
            for($i=0;$i<sizeof($image);$i++) {
                unlink('./img/phones/' . $name . '/gallery/' . $image);
                unlink('./img/phones/' . $name . '/gallery/thumb/' . $image);
            }

        }

        rmdir('./img/phones/' . $name . '/gallery/thumb');
        rmdir('./img/phones/' . $name . '/gallery');
    }

}