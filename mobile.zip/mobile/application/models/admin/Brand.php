    <?php
    if ( ! defined('BASEPATH'))
        exit('No direct script access allowed');

    class Brand extends CI_Model{

        public function __construct()
        {
            parent::__construct();

            $this->load->database();
        }

        function insert($data){
            $this->db->insert('brand',$data);
            $done = $this->db->insert_id();
            return $done;
        }

        function insertFeaturedPos($param){
         for($i=0;$i<sizeof($param);$i++){
            $data = array(
                    'positions' => $param[$i]
                );
                $this->db->insert('featured_position', $data);
            }
        }

        function featuredOnly(){
            $this->db->select('brand.*,COUNT(cellphone.id) AS number_of_phones');
            $this->db->from('brand');
            $this->db->join('cellphone', 'cellphone.brand_id = brand.id', 'left');
            $this->db->group_by('brand.id');
            $this->db->where('is_featured',1);
            //$this->db->order_by('name','asc');
           
            $query = $this->db->get();
            if ( $query->num_rows() > 0 ){
                $row = $query->result();
                return $row;
            }
            else{
                return;
            }

        }

         function all_paginate($perPage, $uri){
        $this->db->from('brand');
        $this->db->limit($perPage,$uri);
        $this->db->order_by('id','asc');
        $query = $this->db->get();
        if ( $query->num_rows() > 0 ){
            $row = $query->result();
            return $row;
        }
        else{
            return;
        }
    }
       function featuredOnlyByPos($country=0){
           if($country==1){
               $field="price";
           }
           else{
               $field="price2";
           }
            $this->db->select('brand.*,COUNT(cellphone.id) AS number_of_phones,cellphone.price AS price,cellphone.price2 AS price2');
            $this->db->from('featured_position');
            $this->db->join('cellphone', 'cellphone.brand_id = featured_position.positions', 'left');
            $this->db->join('brand', 'featured_position.positions = brand.id', 'inner');
            $this->db->where('brand.is_featured',1);
            $this->db->group_by('featured_position.positions');
            $this->db->order_by('featured_position.f_id','asc');
            $query = $this->db->get();
           
            if ( $query->num_rows() > 0 ){
                $row = $query->result();
                return $row;
            }
            else{
                return;
            }
        }

        function update($data){
            $this->db->where('id', $data['id']);
            $done=$this->db->update('brand',$data);
            return $done;
        }

        function find_by($id){
            $this->db->from('brand');
            $this->db->where('id',$id);
            $this->db->order_by('id','asc');
            $query = $this->db->get();
            if ( $query->num_rows() > 0 ){
                $row = $query->result();
                return $row;
            }
            else{
                return;
            }

        }

        function all(){
             $this->db->select('brand.*,COUNT(cellphone.id) AS number_of_phones');
            $this->db->from('brand');
            $this->db->join('cellphone', 'cellphone.brand_id = brand.id', 'left');
            $this->db->group_by('brand.id');
            
            $this->db->order_by('name','asc');

            $query = $this->db->get();
            
            if ( $query->num_rows() > 0 ){
                $row = $query->result();
                return $row;
            }
            else{
                return null;
            }
        }


        function delete($id=0){
            $this->db->where('id', $id);
            $done= $this->db->delete('brand');

            return $done;
        }

        function deleteFeatureOnly($data=0){
            for($i=0;$i<sizeof($data);$i++) {
                $this->db->where('positions', $data[$i]);
                $this->db->delete('featured_position');
            }

        }



    }


    ?>