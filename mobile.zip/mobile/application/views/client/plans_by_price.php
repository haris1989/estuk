<script type="text/javascript" charset="utf-8">
    $(document).ready(function()
    {
        var dontSort = [];
        $('#filterTable thead th').each( function () {
            if ( $(this).hasClass( 'no_sort' )) {
                dontSort.push( { "bSortable": false } );
            } else {
                dontSort.push( null );
            }
        } );

        $('#filterTable').dataTable({"aoColumns": dontSort, "order": [[ 1, "asc" ]]});

    });
</script>
   <div class="row">
   <!--Sidebar nav port start-->
  <div class="col-md-3 col-lg-3" style="border:1px solid #e7e7e7;margin-left:1%;">
  <div class="row" style="padding-top:0px;padding-left:1.5%;padding-right:1%;padding-bottom:1%;">
  <h3 style="margin-top:2px;font-size:18px;padding:3%;background-color:#e7e7e7;color:#777;">Search </h3>
 <div class="input-group">
     <input type="text" class="form-control" placeholder="Search for phone....." autocomplete="off" onkeyup="generateList(this)" list="searchItems" type="text" name="search" id="search" tabindex="1">
     <datalist id="searchItems">

     </datalist>
      <span class="input-group-btn">
        <button class="btn btn-default" type="button" onclick="search();">Go!</button>
      </span>
    </div><!-- /input-group -->

    <br>
  </div>
   <div class="row" style="padding-left:1.5%;padding-right:1%;padding-bottom:1%;">
  <h3 style="font-size:18px;padding:3%;background-color:#e7e7e7;color:#777;">Featured Providers </h3>
  <ul class="list-group">
  <?php if(isset($fbrands)){
    foreach($fbrands as $brand){
    ?>
    <a href="<?php echo base_url();?>index.php/Plans/providerSpecification/<?php echo $brand->id;?>" class="list-group-item "><?php echo $brand->name; ?><span class="badge"><?php 
    if($country == $brand->country) {
                echo $brand->number_of_plans;
            }
            else{
                echo "0";
            }?></span></a>
    <?php }}?>
  </ul>
  </div>
  
    <div class="row" style="padding-left:1.5%;padding-right:1%;padding-bottom:1%;">
  <h3 style="font-size:18px;padding:3%;background-color:#e7e7e7;color:#777;">Popular Providers </h3>
  <ul class="list-group">
    <?php if(isset($popularProviders)){
    foreach($popularProviders as $popular){
    ?>
    <a href="<?php echo base_url();?>index.php/Plans/providerSpecification/<?php echo $popular->id; ?>" class="list-group-item "><?php echo $popular->name; ?><span style="background-color:white;color:black;"class="badge">Views: <?php 
    if($popular->visits > 10000){

    echo "10k + views";
    }
      else{
    echo $popular->visits;
        }
    ?></span></a>
      <?php }?>
  </ul>
  <p style="text-align: center;"><a href="<?php echo base_url();?>index.php/Home/allProviders"></a></p>
    <?php }?>
  </div>



  <div class="row" style="padding-left:1.5%;padding-right:1%;padding-bottom:1%;">
  <h3 style="font-size:18px;padding:3%;background-color:#e7e7e7;color:#777;">Search By Price </h3>
    <ul class="list-group">
  <a href="<?php echo base_url();?>index.php/Plans/searchByPrice/100/0" class="list-group-item " >Prices > $100 </a>
    <a href="<?php echo base_url();?>index.php/Plans/searchByPrice/70/90" class="list-group-item">$70 - $90</a>
    <a href="<?php echo base_url();?>index.php/Plans/searchByPrice/40/60" class="list-group-item">$40 - $60</a>
  <a href="<?php echo base_url();?>index.php/Plans/searchByPrice/30/50" class="list-group-item"> $30 - $50</a>
  <a href="<?php echo base_url();?>index.php/Plans/searchByPrice/0/20" class="list-group-item">Prices < $20</a>
  </ul>
  </div>


  <div class="row" style="padding-left:1.5%;padding-right:1%;padding-bottom:1%;">
  <h3 style="font-size:18px;padding:3%;background-color:#e7e7e7;color:#777;">Find Plans By province </h3>
  <ul class="list-group">
    <?php if(isset($provinceList)){
    foreach($provinceList as $pl){
    ?>
    <a href="<?php echo base_url();?>index.php/Plans/plansByProvince/<?php echo $pl->id; ?>" class="list-group-item "><?php echo $pl->name; ?></a>
      <?php }?>
  </ul>
  <p style="text-align: center;"><a href="<?php echo base_url();?>index.php/Home/allProviders"></a></p>
    <?php }?>
  </div>
  
  </div><!--Sidebar nav port end-->
  <!--Content port start-->
  <div id="cont" style="border:1px solid #e7e7e7;display:inline-block;">
    
        <h3 id="latest" style="margin-top:2px;font-size:18px;background-color:#e7e7e7;color:#777;">  Plans shown by price</h3>
       <!--Latest Items Starts-->
       <div class="row" style="padding-left:1.5%;padding-right:1%;padding-bottom:1%;">
     

            <div class="panel-body nopadding">




                <table id="filterTable" class="table table-bordered">
                    <thead>
                    <tr>
                        <th class="no_sort" align="left">Provider</th>
                        <th align="left">Plan</th>
                        <th align="left">Talk</th>
                        <th align="left">Text</th>
                        <th align="left">Data</th>
                        <th align="left">Price</th>
                    </tr>
                    </thead>

                    <tbody>

   <?php
   if(isset($result)){
   foreach($result as $res){?>
                    <tr>
                        <td align="center" valign="top" style="text-align:center;">
                            <img height="50"  src="<?php echo $res->logo;?>" />
                            <div class="clear"></div>
                             <strong> <?php echo $res->provider_name; ?> </strong>
                        </td>

                        <td align="left" valign="top">
                            <strong> <?php echo $res->plan_name; ?> </strong>
                            <div class="clear"></div>

                        </td>
                        <td>
                          <strong> <?php echo $res->talk; ?> </strong>
                        </td>
                            <td>
                          <strong> <?php echo $res->text; ?> </strong>
                        </td>
                            <td>
                          <strong> <?php echo $res->data; ?> </strong>
                        </td>
                         <td>
                          <strong> <?php echo $res->price; ?> $</strong>
                        </td>
                        
 

                         
                    </tr>
        <?php

   }
   }
   ?>


                    </tbody>
                </table>



                <div class="clear"></div>


            </div><!-- /.panel-body -->
         
        </div>
        </div>
    </div><!-- /.row -->