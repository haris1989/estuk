<div class="row" style="text-align: center;color: rgb(119, 119, 119);">
    <h3 style="font-size: 40px;">Edit Profile</h3><br>
    <?php if($pic==null){ ?>
    <img style="border:solid #efefef 10px;" src="<?php echo base_url();?>img/default.png" class="img-circle"  height="250">
        <?php }else{?>
        <img style="border:solid #efefef 10px;" src="<?php echo base_url();?>img/user/<?php echo $pic; ?>" class="img-circle" height="250">
        <?php } ?>
    <form action="<?php echo base_url();?>index.php/admin/Accounts/update" method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <input type="hidden" value="<?php echo $pic; ?>" name="old_image">
            <input type="hidden" value="<?php echo $user_id; ?>" name="id">
            <label><strong>Enter your name</strong></label>
            <br>
            <input type="text" name="name" style="width:18%;" value="<?php echo $name; ?>" required>
            <br><br>
        </div>
        <div class="form-group">
            <label><strong>Enter your email</strong></label>
            <br>
            <input type="email" name="email" style="width:18%;" value="<?php echo $email; ?>" required>
            <br><br>
        </div>

        <div class="form-group">
            <label><strong>Enter your password</strong></label>
            <br>
            <input type="password" name="password" style="width:18%;" value="<?php echo $password; ?>" required>
            <br><br>
        </div>

        <div class="form-group">
            <label><strong>Enter your website</strong></label>
            <br>
            <input type="url" name="website" value="<?php if(isset($website)){echo $website;} ?>"style="width:18%;">
        </div>
        <br>
        <style>
            input[type=file] {
                display: inline-block;
                margin-left: 9%;
            }
        </style>
        <div class="form-group" >
            <label><strong>Choose your picture</strong></label>
            <br>
            <br>
            <input name="userfile" type="file">
        </div>
        <br>
        <button type="submit" class="btn btn-default">Click To Proceed</button>
    </form>
</div>