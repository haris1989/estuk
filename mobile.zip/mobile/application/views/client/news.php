
 <?php 
  if(isset($news)){
  foreach($news as $new){
    if($new->is_active){
      ?>
 <script>
  function editComment(){
    var a=<?php 
    if(isset($user_id)){
      echo "1";
    } else{
      echo "0";
    }
    ?>;
    if(a == 0){
      document.getElementById("edit_error").style.display="block";
    }
    else if(document.getElementById("edit_comment").value.length <= 0){
        document.getElementById("edit_error2").style.display="block";
    }
    else{
    my_form=document.createElement('FORM');
    my_form.name='myForm';
    my_form.method='POST';
    my_form.action='<?php echo base_url()?>index.php/admin/Comments/update';

    my_tb=document.createElement('INPUT');
    my_tb.type='TEXT';
    my_tb.name='comment';
    my_tb.value=document.getElementById("edit_comment").value;
    my_form.appendChild(my_tb);

    my_tb=document.createElement('INPUT');
    my_tb.type='HIDDEN';
    my_tb.name='news_id';
    my_tb.value='<?php echo $new->id; ?>';
    my_form.appendChild(my_tb);

    my_tb=document.createElement('INPUT');
    my_tb.type='HIDDEN';
    my_tb.name='id';
    my_tb.value=document.getElementById("comment_id").value;
    my_form.appendChild(my_tb);



    document.body.appendChild(my_form);
    my_form.submit();
    }

  }
   function postComment(){
    var a=<?php 
    if(isset($user_id)){
      echo "1";
    } else{
      echo "0";
    }
    ?>;
    if(a == 0){
      document.getElementById("error").style.display="block";
    }
    else if(document.getElementById("comment").value.length <= 0){
        document.getElementById("error2").style.display="block";
    }
    else{
    my_form=document.createElement('FORM');
    my_form.name='myForm';
    my_form.method='POST';
    my_form.action='<?php echo base_url()?>index.php/admin/Comments/create';

    my_tb=document.createElement('INPUT');
    my_tb.type='TEXT';
    my_tb.name='comment';
    my_tb.value=document.getElementById("comment").value;
    my_form.appendChild(my_tb);

    my_tb=document.createElement('INPUT');
    my_tb.type='HIDDEN';
    my_tb.name='news_id';
    my_tb.value='<?php echo $new->id; ?>';
    my_form.appendChild(my_tb);

    my_tb=document.createElement('INPUT');
    my_tb.type='HIDDEN';
    my_tb.name='user_id';
    my_tb.value='<?php 
    if(isset($user_id)){
      echo $user_id;
    }else{
      echo "0";
    } ?>';
    my_form.appendChild(my_tb);



    document.body.appendChild(my_form);
    my_form.submit();
    }
   }

 </script>
 <style>

.panel {
	position:relative;
}
.panel>.panel-heading:after,.panel>.panel-heading:before{
	position:absolute;
	top:11px;left:-16px;
	right:100%;
	width:0;
	height:0;
	display:block;
	content:" ";
	border-color:transparent;
	border-style:solid solid outset;
	pointer-events:none;
}
.panel>.panel-heading:after{
	border-width:7px;
	border-right-color:#f7f7f7;
	margin-top:1px;
	margin-left:2px;
}
.panel>.panel-heading:before{
	border-right-color:#ddd;
	border-width:8px;
}
 </style>
<div class="container-fluid" >
  <div class="row">

  
  <!--Content port start-->
 <div style="border:1px solid #e7e7e7;min-height: 800px;">
	<!--Latest News Start-->
	 <div class="row" style="padding-left:1.5%;padding-right:1%;padding-bottom:1%;">
  <h3 id="latest" style="margin-top:2px;font-size:18px;background-color:#e7e7e7;color:#777;">News</h3>
  <div class="row" style="padding:3%;">
  <div class="jumbotron" 
  <?php
  if($new->banner!=null){?>
  style="background-image:url(<?php echo base_url();?>img/news/<?php echo $new->banner;?>);
    background-repeat: no-repeat;
    background-size: cover;
    "
  <?php }?>
  >
  <div >
  <p style="background: rgba(255,0,0,0.4) !important;font-weight: bold;
    color: white;padding-bottom: 20px;padding-left: 20px;padding-top: 20px;"><?php echo $new->title; ?></p>
  </div>
</div>
<p>
<?php echo $new->content; ?>
</p>
  
  
  </div>
  </div><!--Latest News End-->
  <div class="row">
<div class="col-sm-12">
<h3 style="margin-left:1%;">User Comments (<?php echo sizeof($comments)?>)</h3>
</div><!-- /col-sm-12 -->
</div><!-- /row -->
<div class="row">
<?php 
if(isset($comments)){

foreach($comments as $row){
  ?>
<div class="col-sm-1">
<div class="thumbnail">
<?php if($row->picture != null){?>
<img class="img-responsive user-photo" src="<?php echo base_url();?>/img/user/<?php echo $row->picture;?>">
<?php }else{?>
<img class="img-responsive user-photo" src="https://ssl.gstatic.com/accounts/ui/avatar_2x.png">
<?php }?>
</div><!-- /thumbnail -->
</div><!-- /col-sm-1 -->

<div class="col-sm-11">
<div class="panel panel-default">
<div class="panel-heading">
<strong><?php echo $row->name;?></strong> <span class="text-muted"><?php
echo $this->Utility->time_elapsed_string($row->updated_at,true);
?></span>
</div>
<div class="panel-body">
<?php echo $row->comment;?>
</div><!-- /panel-body -->
<?php if(isset($user_id)){if($user_id == $row->user_id){?>
<div style="text-align: right;padding-right: 20px;padding-bottom: 10px;"><!--Edit link-->
<a href="javascript::void(0)" onclick="document.getElementById('edit_comment').value='<?php
 $remove[] = "'";
$remove[] = '"';
$remove[] = "-"; // just as another example

$string = str_replace( $remove, "", $row->comment );
echo $string

 ?>',document.getElementById('comment_id').value='<?php echo $row->id;?>'" data-toggle="modal" data-target="#editComment_dialog">Edit</a>
</div>
<?php }} ?>
</div><!-- /panel panel-default -->
</div><!-- /col-sm-5 -->
<?php 
}}
?>

</div><!-- /row -->
<br>
 <div class="row" ><a style="margin-left: 10%;" href="#" data-toggle="modal" data-target="#myComment"><strong>Post a comment</strong></a></div>
<br>
  </div><!--Content port end-->
<?php }}}else{echo "<h2 style='margin-left:12%;'>No News Found</h2>";}?>
  <!--Content port end-->
</div>
  
</div><!--Container End-->

