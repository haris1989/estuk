<html>
<head>
<link rel="stylesheet" href="<?php echo base_url(); ?>bootstrap/css/bootstrap.min.css">

<script src="<?php echo base_url(); ?>jquery.js"></script>
<script src="<?php echo base_url(); ?>bootstrap/js/bootstrap.min.js"></script>
<script>
    function changeCountry(country){
        document.getElementById("p1").innerHTML="Country "+country;

        if(country == "Canada"){
            document.getElementById("c").value=0;
        }
        else{
            document.getElementById("c").value=1;
        }
    }
    function changeMode(val){

        document.getElementById("mode").value=val;
    }
</script>

<style media="screen">

    body{
        background-image: url(<?php echo base_url()?>img/back.jpg);

        background-repeat: no-repeat;
    }
    .container {
        width: 100%;
        height: 200px;
        position: relative;
        margin: 0 auto 40px;
        border: none;
        -webkit-perspective: 1200px;
        -moz-perspective: 1200px;
        -o-perspective: 1200px;
        perspective: 1200px;
    }

    #box {
        width: 100%;
        height: 100%;
        padding-left:9%;

        text-align:center;
        position: absolute;
        -webkit-transform-style: preserve-3d;
        -moz-transform-style: preserve-3d;
        -o-transform-style: preserve-3d;
        transform-style: preserve-3d;
        -webkit-transition: -webkit-transform 1s;
        -moz-transition: -moz-transform 1s;
        -o-transition: -o-transform 1s;
        transition: transform 1s;
    }

    #box figure {
        display: block;
        position: absolute;
        border: none;
        line-height: 196px;
        font-size: 90px;
        text-align: center;
        font-weight: bold;
        color: white;
    }

    #box.panels-backface-invisible figure {
        -webkit-backface-visibility: hidden;
        -moz-backface-visibility: hidden;
        -o-backface-visibility: hidden;
        backface-visibility: hidden;
    }

    #box .front,
    #box .back {
        width: 80%;
        height: 226px;
    }

    #box .right,
    #box .left {
        width: 96px;
        height: 194px;
        left: 100px;
    }

    #box .top,
    #box .bottom {
        width: 80%;
        height: 96px;

        top: 50px;
        line-height: 96px;
    }


    #box .front  { top:-30px;background-image: url(<?php echo base_url()?>img/Canada-Flag-icon.png);background-position:left top; background-repeat: no-repeat;-webkit-background-size: 100% 110%;}
    #box .back   { background-image: url(<?php echo base_url()?>img/United-States-Flag-icon.png);background-position:left top; background-repeat: no-repeat;background-size: 100% 110%; }
    #box .right  { background: hsla( 120, 100%, 50%, 0.7 ); }
    #box .left   { background: hsla( 180, 100%, 50%, 0.7 ); }
    #box .top    { background-image: url(<?php echo base_url()?>img/Canada-Flag-icon.png);background-position:left top; background-repeat: no-repeat;-webkit-background-size: 100% 110%;}
    #box .bottom { background-image: url(<?php echo base_url()?>img/United-States-Flag-icon.png);background-position:left top; background-repeat: no-repeat;background-size: 100% 110%; }

    #box .front  {
        -webkit-transform: translateZ( 50px );
        -moz-transform: translateZ( 50px );
        -o-transform: translateZ( 50px );
        transform: translateZ( 50px );
    }
    #box .back   {
        -webkit-transform: rotateX( -180deg ) translateZ(  50px );
        -moz-transform: rotateX( -180deg ) translateZ(  50px );
        -o-transform: rotateX( -180deg ) translateZ(  50px );
        transform: rotateX( -180deg ) translateZ(  50px );
    }
    #box .right {
        -webkit-transform: rotateY(   90deg ) translateZ( 150px );
        -moz-transform: rotateY(   90deg ) translateZ( 150px );
        -o-transform: rotateY(   90deg ) translateZ( 150px );
        transform: rotateY(   90deg ) translateZ( 150px );
    }
    #box .left {
        -webkit-transform: rotateY(  -90deg ) translateZ( 150px );
        -moz-transform: rotateY(  -90deg ) translateZ( 150px );
        -o-transform: rotateY(  -90deg ) translateZ( 150px );
        transform: rotateY(  -90deg ) translateZ( 150px );
    }
    #box .top {
        -webkit-transform: rotateX(   90deg ) translateZ( 100px );
        -moz-transform: rotateX(   90deg ) translateZ( 100px );
        -o-transform: rotateX(   90deg ) translateZ( 100px );
        transform: rotateX(   90deg ) translateZ( 100px );
    }
    #box .bottom {
        -webkit-transform: rotateX(  -90deg ) translateZ( 100px );
        -moz-transform: rotateX(  -90deg ) translateZ( 100px );
        -o-transform: rotateX(  -90deg ) translateZ( 100px );
        transform: rotateX(  -90deg ) translateZ( 100px );
    }


    #box.show-front {
        -webkit-transform: translateZ(  -50px );
        -moz-transform: translateZ(  -50px );
        -o-transform: translateZ(  -50px );
        transform: translateZ(  -50px );

    }
    #box.show-back {
        -webkit-transform: translateZ( -50px ) rotateX( -180deg );
        -moz-transform: translateZ( -50px ) rotateX( -180deg );
        -o-transform: translateZ( -50px ) rotateX( -180deg );
        transform: translateZ( -50px ) rotateX( -180deg );
    }
    #box.show-right {
        -webkit-transform: translateZ( -150px ) rotateY(  -90deg );
        -moz-transform: translateZ( -150px ) rotateY(  -90deg );
        -o-transform: translateZ( -150px ) rotateY(  -90deg );
        transform: translateZ( -150px ) rotateY(  -90deg );
    }
    #box.show-left {
        -webkit-transform: translateZ( -150px ) rotateY(   90deg );
        -moz-transform: translateZ( -150px ) rotateY(   90deg );
        -o-transform: translateZ( -150px ) rotateY(   90deg );
        transform: translateZ( -150px ) rotateY(   90deg );
    }
    #box.show-top {
        -webkit-transform: translateZ( -100px ) rotateX(  -90deg );
        -moz-transform: translateZ( -100px ) rotateX(  -90deg );
        -o-transform: translateZ( -100px ) rotateX(  -90deg );
        transform: translateZ( -100px ) rotateX(  -90deg );
    }
    #box.show-bottom {
        -webkit-transform: translateZ( -100px ) rotateX(   90deg );
        -moz-transform: translateZ( -100px ) rotateX(   90deg );
        -o-transform: translateZ( -100px ) rotateX(   90deg );
        transform: translateZ( -100px ) rotateX(   90deg );
    }


    #opt1{
        background-color: #F33731;
        border: none;
        color: white;
        width:35%;
        padding: 10px 1px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        cursor: pointer;
        text-decoration:none;
    }
    #opt1:hover{
        background-color: black;
        text-decoration:none;

    }

    #opt2{
        background-color: #337AB7;
        border: none;
        color: white;
        width:35%;
        padding: 10px 1px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        cursor: pointer;
        text-decoration:none;
    }
    #opt2:hover{
        background-color: black;
        text-decoration:none;

    }
    .button:hover{
        background-color: black;
        text-decoration:none;

    }
    .button {
        background-color: #FDEC2E;
        border:#e9ac1a;
        border-radius:5px 5px 5px 5px;
        color: white;
        width:100%;
        padding: 6px 1px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 20px;
        cursor: pointer;
        background-image: -webkit-linear-gradient(top, #FDEC2E 0%,#f9c80d 100%);
        color:black;
        text-decoration:none;
    }

    .button:hover{
        background-image: -webkit-linear-gradient(top, #F5E105 0%,#F9A10D 100%);
        text-decoration:none;
        color:black;
    }

</style>

</head>
<body>
<!--Menu nav start-->
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="<?php echo base_url();?>index.php/Home"><img src="<?php echo base_url();?>img/logo/logo.png" height="30"></a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        
        
        <!--<li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Plans <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="#">All Providers</a></li>
            <li><a href="#">All Plans</a></li>
            <li><a href="#">Featured Provides</a></li>
            <li><a href="#">Popular Provides</a></li>
          </ul>
        </li>-->
        <li style="background-color:pink;"><a href="#" onclick="changeMode(1)" style="color:white;"><strong>Phones</strong></a></li>
        <li><a href="javascript:void(0);"></a></li>
         <li style="background-color:#BCE2EA;"><a href="#" onclick="changeMode(2)"  style="color:white;"><strong>Plans</strong></a></li>
         
       
      </ul>
        <ul class="nav navbar-nav navbar-right">
          <?php if(isset($user_id)){ ?>
              <li class="dropdown">
                  <a class="dropdown-toggle" data-toggle="dropdown" href="#"><strong>Welcome <?php echo $name;?></strong> <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                      <li style="text-align: center;">
                          <a href="#">

                          <?php
                       $img="default.png";
                          $path="img/";
                          if($pic !=null){
                              $img=$pic;
                              $path="img/user/";
                          }
                          ?>
                              <p><img style="border:solid #efefef 10px;" src="<?php echo base_url();?><?php echo $path.$img;?>" class="img-circle" height="80" width="90"></p>
                          </a>

                      </li>
                      <li><a href="#"><?php echo $email;?><br><br></a></li>
                      <li><a href="<?php echo base_url();?>index.php/Home/edit/<?php echo $user_id;?>">Edit Profile<br><br></a></li>
                      <li><a href="<?php echo base_url();?>index.php/Home/signOut">Sign Out<br><br></a></li>
                  </ul>
              </li>

          <?php } else{?>
              <li><a href="#" data-toggle="modal" data-target="#myModal"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
        <?php } ?>
      </ul>
    </div>
  </div>
</nav><!--Menu nav end-->

<div class="row">
    <div class="col-lg-12">

    </div>
</div>


<div class="col-lg-6 col-md-6">

    <div  class="col-lg-7 col-sm-7 col-sm-offset-2   col-lg-offset-9 " style="padding-bottom:10px;background-color:#EEE;" >
<br>
     <div id="p1" style="text-align:center;font-size:30px;padding-bottom:20px;">Country Canada</div>


    <br>
    <section class="container">

        <div id="box" class="show-front panels-backface-invisible">
            <figure class="front"></figure>
            <figure class="back"></figure>
            <figure class="top"></figure>
            <figure class="bottom"></figure>
        </div>
    </section>
    <section id="options" style="text-align: center;">

        <p style="font-size: 16px;">Please select a country from below:</p>
        <p id="show-buttons">

            <button class="show-front" id="opt1" onclick="changeCountry('Canada')">Canada</button>
            <button class="show-back" id="opt2" onclick="changeCountry('USA')">USA</button> </p>

    </section>
        <form id="f1" method="POST" action="<?php echo base_url()?>index.php/Home/countryProcess">
            <input type="hidden" id="c" name="country" value="0">
            <input type="hidden" id="mode" name="mode" value="1">
        <input type="submit"  value="Continue...." onclick="document.getElementById("f1").submit" href="#" class="button">

        </form>
</div>
    </div>
<script src="<?php echo base_url()?>utils.js"></script>
<script src="<?php echo base_url()?>rotate-box.js"></script>
<div style="height:1100px;">
</div>
</body>
</html>
