<div class="container-fluid" >
  <div class="row">
<!--Sidebar nav port start-->
  <div class="col-md-3 col-lg-3" style="border:1px solid #e7e7e7;margin-left:1%;">
  <div class="row" style="padding-top:0px;padding-left:1.5%;padding-right:1%;padding-bottom:1%;">
  <h3 style="margin-top:2px;font-size:18px;padding:3%;background-color:#e7e7e7;color:#777;">Search </h3>
 <div class="input-group">
     <input type="text" class="form-control" placeholder="Search for phone....." autocomplete="off" onkeyup="generateList(this)" list="searchItems" type="text" name="search" id="search" tabindex="1">
     <datalist id="searchItems">

     </datalist>
      <span class="input-group-btn">
        <button class="btn btn-default" type="button" onclick="search();">Go!</button>
      </span>
    </div><!-- /input-group -->

	<br>
  </div>
   <div class="row" style="padding-left:1.5%;padding-right:1%;padding-bottom:1%;">
  <h3 style="font-size:18px;padding:3%;background-color:#e7e7e7;color:#777;">Featured Brands </h3>
  <ul class="list-group">
  <?php if(isset($fbrands)){
    foreach($fbrands as $brand){
    ?>
    <a href="<?php echo base_url();?>index.php/Home/allBrandPhones/<?php echo $brand->id;?>/" class="list-group-item "><?php echo $brand->name; ?><span class="badge"><?php if((strcmp($countryCurrency,"CAD $")==0 && $brand->price2 > 0) || (strcmp($countryCurrency,"US $")==0 && $brand->price > 0)) {
                echo $brand->number_of_phones;
            }
            else{
                echo "0";
            }?></span></a>
    <?php }}?>
  </ul>
  </div>
  
    <div class="row" style="padding-left:1.5%;padding-right:1%;padding-bottom:1%;">
  <h3 style="font-size:18px;padding:3%;background-color:#e7e7e7;color:#777;">Popular Phones </h3>
  <ul class="list-group">
    <?php if(isset($popularPhones)){
    foreach($popularPhones as $popular){
    ?>
    <a href="<?php echo base_url();?>index.php/Home/phoneSpecification/<?php echo $popular->id; ?>" class="list-group-item "><?php echo $popular->name; ?><span style="background-color:white;color:black;"class="badge">Views: <?php 
    if($popular->visits > 10000){

    echo "10k + views";
    }
      else{
    echo $popular->visits;
        }
    ?></span></a>
      <?php }?>
  </ul>
  <p style="text-align: center;"><a href="<?php echo base_url();?>index.php/Home/allPhones"></a></p>
    <?php }?>
  </div>
  
  <div class="row" style="padding-left:1.5%;padding-right:1%;padding-bottom:1%;">
  <h3 style="font-size:18px;padding:3%;background-color:#e7e7e7;color:#777;">Search By Price </h3>
    <ul class="list-group">
  <a href="<?php echo base_url();?>index.php/Home/searchByPrice/800/0" class="list-group-item " >Prices > $800 </a>
    <a href="<?php echo base_url();?>index.php/Home/searchByPrice/500/800" class="list-group-item">$500 - $800</a>
    <a href="<?php echo base_url();?>index.php/Home/searchByPrice/300/500" class="list-group-item">$300 - $500</a>
  <a href="<?php echo base_url();?>index.php/Home/searchByPrice/100/300" class="list-group-item"> $100 - $300</a>
  <a href="<?php echo base_url();?>index.php/Home/searchByPrice/0/200" class="list-group-item">Prices < $200</a>
  </ul>
  </div>
  </div><!--Sidebar nav port end-->
  
  <!--Content port start-->
  <div id="cont" style="border:1px solid #e7e7e7;display:inline-block;">
       <!--Latest Items Starts-->
	   <div class="row" style="padding-left:1.5%;padding-right:1%;padding-bottom:1%;">
  <h3 id="latest" style="margin-top:2px;font-size:18px;background-color:#e7e7e7;color:#777;">Latest Phones</h3>
  <div class="row" style="padding:3%;">
<?php if(isset($latestPhones)){
    foreach($latestPhones as $latest){
      if($latest->active==1){
          ?>

  <div class="col-sm-6 col-md-4 col-lg-4">
    <div class="thumbnail">
      <img src="<?php echo base_url()."img/phones/".$latest->name."/thumb/".$latest->image;?>" alt="...">
      <div class="caption">
        <h3 style="text-align: center;font-size: 16px;"><?php echo $latest->brand;?> <?php echo $latest->name;?></h3>
        <p>

        <?php
       $con=strip_tags($latest->description);
        $con=substr($con,0,100);
         echo $con ;?>......
          </p>
<p style="text-align:center;">Price: <span style="color:red;"><?php

        if(strcmp($countryCurrency,"CAD $")==0){
            echo $countryCurrency . $latest->price2;
        }
        else {
            echo $countryCurrency . $latest->price;
        }

    ?></span></p>
          <div class="row">
              <div class="col-lg-6 col-md-6"  style="text-align:center;padding-top:8px;">

                <b>Rating:</b> <?php
                  $total=0;
                  $total=($latest->rate_design + $latest->rate_feature + $latest->rate_perfomance)/3;
                  echo round($total,1); ?>

              </div>
       <div class="col-lg-6 col-md-6"  style="text-align:center;"><a href="<?php echo base_url();?>index.php/Home/phoneSpecification/<?php echo $latest->id;?>" class="btn btn-default" role="button">Learn more</a></div>
              </div>
      </div>
    </div>
  </div>
 <?php }}}?>
  
<p style="text-align:right;padding-right:3%;"><a href="<?php echo base_url();?>index.php/Home/allPhones" >View More..</a></p>
</div>
  </div><!--Latest Items End-->
	
	
	<!--Latest News Start-->
	 <div class="row" style="padding-left:1.5%;padding-right:1%;padding-bottom:1%;">
  <h3 id="latest" style="margin-top:2px;font-size:18px;background-color:#e7e7e7;color:#777;">Latest News</h3>
  <div class="row" style="padding:3%;">

  <?php if(isset($latestNews)){
    foreach($latestNews as $news){
      if($news->is_active==1){
    ?>

  <div class="col-sm-6 col-md-4 col-lg-4">
    <div class="thumbnail" style="height:300px;">
      <img style="height:160px;z-index:0;position:absolute;width:87%;" src="<?php echo base_url();?>/img/news/thumb/<?php echo $news->banner;?>" alt="...">
      <div class="caption">
        <h3 style="padding-left:12px;padding-bottom:10px;padding-top:10px;width:84%;color:white;background: rgba(0,0,0,0.4) !important;position:absolute;margin-top:20px;font-size: 16px;"><?php echo $news->title;?></h3>
        <p style="margin-top:180px;">

        <?php
        $con=null;
       $con=strip_tags($news->content);
        $con=mb_substr($con,0,150);
         echo $con ;?>......
          
          </p>
        <p style="text-align:right;"><a href="<?php echo base_url();?>index.php/Home/news/<?php echo $news->id; ?>" class="btn btn-default" role="button">Read More</a></p>
      </div>
    </div>
  </div>
 <?php }}}?>

<p style="text-align:right;padding-right:3%;"><a href="<?php echo base_url();?>index.php/Home/allNews" >View More..</a></p>
</div>
  </div><!--Latest News End-->
  
  
  
   <!--Latest Reviews Start-->
   <div class="row" style="padding-left:1.5%;padding-right:1%;padding-bottom:1%;">
  
  <h3 id="latest" style="margin-top:2px;font-size:18px;background-color:#e7e7e7;color:#777;">Latest Reviews</h3>
  <div class="row" style="padding:3%;">


  <?php if(isset($latestReviews)){
    foreach($latestReviews as $review){
      if($review->is_active==1){
    ?>

  <div class="col-sm-6 col-md-4 col-lg-4">
    <div class="thumbnail">
      <img style="width:90%;"  src="<?php echo base_url()."img/reviews/thumb/".$review->image;?>" alt="...">
      <div class="caption">
        <h3 style="text-align: center;font-size: 16px;"><?php echo $review->title;?></h3>
        <p>

        <?php
       $con=strip_tags($review->description);
        $con=substr($con,0,100);
         echo $con ;?>......
          </p>
        <p style="text-align:right;"><a href="<?php echo base_url();?>index.php/Home/review/<?php echo $review->id;?>/1" class="btn btn-default" role="button">Read More</a></p>
      </div>
    </div>
  </div>
 <?php }}}?>
<p style="text-align:right;padding-right:3%;"><a href="<?php echo base_url();?>index.php/Home/allReviews/<?php echo $sectiontype;?>" >View More..</a></p>
</div>
  </div> <!--Latest Reviews Ends-->
  
  </div><!--Content port end-->
</div>
  
</div><!--Container End-->

