<div class="container">
<h2>Comapre the providers</h2>
<div style="text-align:center;" clas="row">
<label>Provider 1</label>
<input type="text" name="provider1" id="provider1" autocomplete="off" onkeyup="generateListCompare(this)" list="sp1">
<datalist id="sp1">

     </datalist>
&nbsp;&nbsp;&nbsp;&nbsp;
<label>Provider 2</label>
<input type="text" name="provider2" id="provider2"  autocomplete="off" onkeyup="generateListCompare(this)" list="sp2">
<datalist id="sp2">

     </datalist>
<br>
<br>
<button onclick="compare();">Compare Providers</button>
<br>
<br>
</div>

<?php if(isset($provider1) && isset($provider2)){?>
<?php foreach ($provider1 as $new) {?>
<div class="col-lg-6 col-md-6 col-sm-6" style="padding-right:2%;">
<div class="row" style="min-height:680px;">
    <div class="thumbnail">
      <img  style="height:100px; " src="<?php echo $new->logo;?>" alt="...">
      <div class="caption">
        <h3 style="text-align: center;font-size: 16px;"><?php echo $new->name;?>
       

            
 
        
      
    </div>
  </div>
<?php
$providerPlans1=$this->Provider->allPlans($new->id);
        if(isset($providerPlans1)){
        foreach ($providerPlans1 as $key) {?>
         <div class="row"  style="text-align:center;color:white;background-color:black;padding-left:2%;padding-top:8px;border-bottom:1px solid #e7e7e7;font-size: 20px;">
        
       <?php echo $key->name;
     
        ?>
        </div>
         <div class"row" style="font-size: 18px;padding-top:20px;padding-bottom: 20px;"> 
         <table border=1 style="width:100%;">

         <tr>
         <th style="text-align:center;">Province/State</th>
         <th style="text-align:center;">Talk</th>
         <th style="text-align:center;">Text</th>
         <th style="text-align:center;">Data</th>
         <th style="text-align:center;">Price</th>
         </tr>
         <?php
         $feature=null;
         $feature=$this->Provider->allFeatures($key->id,$country);
         if(isset($feature)){
          foreach($feature as $f){
          ?>
          <tr>
          <td style="text-align:center;">
            <?php echo $f->province_name;?>
            </td>
            <td style="text-align:center;">
            <?php echo $f->talk;?>
            </td>
            <td style="text-align:center;">
            <?php echo $f->text;?>
            </td>
            <td style="text-align:center;">
            <?php echo $f->data;?>
            </td>
            <td style="text-align:center;">
            <?php echo $f->price;?> $
            </td>
          </tr>

         <?php }}?>
         </table>
         <br>
         <br>
        

         </div>
        
         <?php    }
      }
?>
 </div>
         </div>
<?php }}?>


<?php if(isset($provider1) && isset($provider2)){?>
<?php foreach ($provider2 as $new) {?>
<div class="col-lg-6 col-md-6 col-sm-6" style="padding-left: 4%;">
<div class="row" style="min-height:680px;">
    <div class="thumbnail">
      <img src="<?php echo $new->logo;?>"  style="height:100px; "alt="...">
      <div class="caption">
        <h3 style="text-align: center;font-size: 16px;"><?php echo $new->name;?>
       

            
 
        
      
    </div>
  </div>
<?php
$providerPlans1=$this->Provider->allPlans($new->id);
        if(isset($providerPlans1)){
        foreach ($providerPlans1 as $key) {?>
         <div class="row"  style="text-align:center;color:white;background-color:black;padding-left:2%;padding-top:8px;border-bottom:1px solid #e7e7e7;font-size: 20px;">
        
       <?php echo $key->name;
     
        ?>
        </div>
         <div class"row" style="font-size: 18px;padding-top:20px;padding-bottom: 20px;"> 
         <table border=1 style="width:100%;">

         <tr>
         <th style="text-align:center;">Province/State</th>
         <th style="text-align:center;">Talk</th>
         <th style="text-align:center;">Text</th>
         <th style="text-align:center;">Data</th>
         <th style="text-align:center;">Price</th>
         </tr>
         <?php
         $feature=null;
         $feature=$this->Provider->allFeatures($key->id,$country);
         if(isset($feature)){
          foreach($feature as $f){
          ?>
          <tr>
          <td style="text-align:center;">
            <?php echo $f->province_name;?>
            </td>
            <td style="text-align:center;">
            <?php echo $f->talk;?>
            </td>
            <td style="text-align:center;">
            <?php echo $f->text;?>
            </td>
            <td style="text-align:center;">
            <?php echo $f->data;?>
            </td>
            <td style="text-align:center;">
            <?php echo $f->price;?> $
            </td>
          </tr>

         <?php }}?>
         </table>
         <br>
         <br>
        

         </div>
        
         <?php    }
      }
?>
 </div>
         </div>
<?php }}?>

</div>
</div>
</div>