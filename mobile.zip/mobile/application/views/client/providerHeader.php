<!DOCTYPE html>
<html lang="en">
<head>
  <title>MyCarier.com - MyCarier Home</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo base_url(); ?>bootstrap/css/bootstrap.min.css">
   <link href="<?php echo base_url(); ?>css/dataTables.bootstrap.css" rel="stylesheet">
  <script src="<?php echo base_url(); ?>jquery.js"></script> 
  <script src="<?php echo base_url(); ?>bootstrap/js/bootstrap.min.js"></script>
  <script src="<?php echo base_url(); ?>js/showhide.js"></script>
    <script src="<?php echo base_url(); ?>js/jeditable.js"></script>
    <script src="<?php echo base_url(); ?>js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>js/dataTables.bootstrap.js"></script>
    <script>
        function generateList(obj){
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    document.getElementById("searchItems").innerHTML = xhttp.responseText;
                }
            };
            xhttp.open("GET", "<?php echo base_url();?>index.php/Plans/searchList", true);
            xhttp.send();
        }
        function search(){
             phone = document.getElementById("search").value;
            if(phone.length > 0){
                location.href="<?php echo base_url();?>index.php/Plans/providerSpecification/"+phone;
            }
            else{
                alert("Please type to search");
            }
        }
         function generateListCompare(obj){
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    document.getElementById("sp2").innerHTML = xhttp.responseText;
                     document.getElementById("sp1").innerHTML = xhttp.responseText;
                }
            };
            xhttp.open("GET", "<?php echo base_url();?>index.php/Plans/searchList", true);
            xhttp.send();
        }
         function compare(){
             phone1 = document.getElementById("provider1").value;
             phone2 = document.getElementById("provider2").value;
            if(phone1.length > 0 && phone2.length > 0){
                location.href="<?php echo base_url();?>index.php/Plans/compareProviders/"+phone1+"/"+phone2;
            }
            else{
                alert("Please type both providers to compare");
            }
        }
    </script>
 <style>
 
 #cont{
 width:73%;
 margin-left:1px;
 padding-left:2px;
 padding-right:3px;
 }
 #latest{
 width:99.5%;
 padding:1%;
 }
 @media only screen and (max-width: 990px) {
    #cont {
        width:99%;
		padding-left:3%;
		padding-right:3%;
		margin-left:1%;
    }
	#latest{
	padding: 3%;
	width:100%;
	
	}
}
#foot-p1{
margin:0px;
}
#foot-p1 a{
background-color:black;
color:white;
border-left:none;
border-right:none;
border-top:none;
border-bottom:none;

}
#foot-p1 a:hover{
background-color:#337ab7;
color:white;

}
 .jumbotron h1{
 background-color:#E8E8E8 !important;
 }
 
 .jumbotron p{
 background-color:black !important;
 color:white;
 }


 </style>
</head>
<body>
<!-- Error and alert messages-->
<?php if(isset($alert)) {?>
    <div class="alert alert-danger" role="alert"> <?php echo $alert; ?></div>
<?php }?>
<?php if(isset($notice)) {?>
    <div class="alert alert-success" role="alert"><?php echo $notice; ?> </div>
<?php } ?>
<!--Menu nav start-->
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="<?php echo base_url();?>index.php/Home/selectCountry"><img src="<?php echo base_url();?>img/logo/logo.png" height="30"></a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="<?php echo base_url();?>index.php/Plans">Home</a></li>
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="http://www.google.com">Provider <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo base_url();?>index.php/Home/allBrands">All Providers</a></li>
            <li><a href="<?php echo base_url();?>index.php/Home/allPhones">Latest Providers</a></li>
          </ul>
        </li>
       
         <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Compare <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo base_url();?>index.php/Home/comparePhones">Phones</a></li>
            <li><a href="<?php echo base_url();?>index.php/Plans/compareProviders">Providers</a></li>
          
          </ul>
        </li>
		<li><a href="<?php echo base_url();?>index.php/Plans/allNews">News</a></li>
		 <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Reviews <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo base_url();?>index.php/Home/allReviews">Phones</a></li>
            <li><a href="<?php echo base_url();?>index.php/Plans/allReviews">Plans</a></li>
          </ul>
        </li>
        <?php

        if(isset($pages)){

          foreach($pages as $page){

            if($page->is_active==1){?>

              <li><a href="<?php echo base_url();?>index.php/Home/showpage/<?php echo $page->id;?>"><?php echo $page->title;?></a></li>
            <?php }


          }
        }
        ?>
      </ul>
      <ul class="nav navbar-nav navbar-right">
          <?php if(isset($user_id)){ ?>
              <li class="dropdown">
                  <a class="dropdown-toggle" data-toggle="dropdown" href="#"><strong>Welcome <?php echo $name;?></strong> <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                      <li style="text-align: center;">
                          <a href="#">

                          <?php
                       $img="default.png";
                          $path="img/";
                          if($pic !=null){
                              $img=$pic;
                              $path="img/user/";
                          }
                          ?>
                              <p><img style="border:solid #efefef 10px;" src="<?php echo base_url();?><?php echo $path.$img;?>" class="img-circle" height="80" width="90"></p>
                          </a>

                      </li>
                      <li><a href="#"><?php echo $email;?><br><br></a></li>
                      <li><a href="<?php echo base_url();?>index.php/Home/edit/<?php echo $user_id;?>">Edit Profile<br><br></a></li>
                      <li><a href="<?php echo base_url();?>index.php/Home/signOut">Sign Out<br><br></a></li>
                  </ul>
              </li>

          <?php } else{?>
              <li><a href="#" data-toggle="modal" data-target="#myModal"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
        <?php } ?>
      </ul>
    </div>
  </div>
</nav><!--Menu nav end-->
  