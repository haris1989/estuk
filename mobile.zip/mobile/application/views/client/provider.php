
 <?php
  if(isset($provider)){
  foreach($provider as $new){
   
      ?>
 <script>
  function editComment(){
    var a=<?php 
    if(isset($user_id)){
      echo "1";
    } else{
      echo "0";
    }
    ?>;
    if(a == 0){
      document.getElementById("edit_error").style.display="block";
    }
    else if(document.getElementById("edit_comment").value.length <= 0){
        document.getElementById("edit_error2").style.display="block";
    }
    else{
    my_form=document.createElement('FORM');
    my_form.name='myForm';
    my_form.method='POST';
    my_form.action='<?php echo base_url()?>index.php/admin/Comments/update';

    my_tb=document.createElement('INPUT');
    my_tb.type='TEXT';
    my_tb.name='comment';
    my_tb.value=document.getElementById("edit_comment").value;
    my_form.appendChild(my_tb);

    my_tb=document.createElement('INPUT');
    my_tb.type='HIDDEN';
    my_tb.name='provider_id';
    my_tb.value='<?php echo $new->id; ?>';
    my_form.appendChild(my_tb);

    my_tb=document.createElement('INPUT');
    my_tb.type='HIDDEN';
    my_tb.name='id';
    my_tb.value=document.getElementById("comment_id").value;
    my_form.appendChild(my_tb);



    document.body.appendChild(my_form);
    my_form.submit();
    }

  }
   function postComment(){
    var a=<?php 
    if(isset($user_id)){
      echo "1";
    } else{
      echo "0";
    }
    ?>;
    if(a == 0){
      document.getElementById("error").style.display="block";
    }
    else if(document.getElementById("comment").value.length <= 0){
        document.getElementById("error2").style.display="block";
    }
    else{
    my_form=document.createElement('FORM');
    my_form.name='myForm';
    my_form.method='POST';
    my_form.action='<?php echo base_url()?>index.php/admin/Comments/create';

    my_tb=document.createElement('INPUT');
    my_tb.type='TEXT';
    my_tb.name='comment';
    my_tb.value=document.getElementById("comment").value;
    my_form.appendChild(my_tb);

    my_tb=document.createElement('INPUT');
    my_tb.type='HIDDEN';
    my_tb.name='provider_id';
    my_tb.value='<?php echo $new->id; ?>';
    my_form.appendChild(my_tb);

    my_tb=document.createElement('INPUT');
    my_tb.type='HIDDEN';
    my_tb.name='user_id';
    my_tb.value='<?php 
    if(isset($user_id)){
      echo $user_id;
    }else{
      echo "0";
    } ?>';
    my_form.appendChild(my_tb);



    document.body.appendChild(my_form);
    my_form.submit();
    }
   }

 </script>
 <style>

.panel {
  position:relative;
}
.panel>.panel-heading:after,.panel>.panel-heading:before{
  position:absolute;
  top:11px;left:-16px;
  right:100%;
  width:0;
  height:0;
  display:block;
  content:" ";
  border-color:transparent;
  border-style:solid solid outset;
  pointer-events:none;
}
.panel>.panel-heading:after{
  border-width:7px;
  border-right-color:#f7f7f7;
  margin-top:1px;
  margin-left:2px;
}
.panel>.panel-heading:before{
  border-right-color:#ddd;
  border-width:8px;
}
 </style>
<div class="container-fluid" >
  <div class="row">
<!--Sidebar nav port start-->
  <div class="col-md-3 col-lg-3" style="border:1px solid #e7e7e7;margin-left:1%;">
  <div class="row" style="padding-top:0px;padding-left:1.5%;padding-right:1%;padding-bottom:1%;">
  <h3 style="margin-top:2px;font-size:18px;padding:3%;background-color:#e7e7e7;color:#777;">Search </h3>
 <div class="input-group">
     <input type="text" class="form-control" placeholder="Search for phone....." autocomplete="off" onkeyup="generateList(this)" list="searchItems" type="text" name="search" id="search" tabindex="1">
     <datalist id="searchItems">

     </datalist>
      <span class="input-group-btn">
        <button class="btn btn-default" type="button" onclick="search();">Go!</button>
      </span>
    </div><!-- /input-group -->

  <br>
  </div>
   <div class="row" style="padding-left:1.5%;padding-right:1%;padding-bottom:1%;">
  <h3 style="font-size:18px;padding:3%;background-color:#e7e7e7;color:#777;">Featured Providers </h3>
  <ul class="list-group">
  <?php if(isset($fbrands)){
    foreach($fbrands as $brand){
    ?>
    <a href="<?php echo base_url();?>index.php/Plans/providerSpecification/<?php echo $brand->id; ?>" class="list-group-item "><?php echo $brand->name; ?><span class="badge"><?php 
    if($country == $brand->country) {
                echo $brand->number_of_plans;
            }
            else{
                echo "0";
            }?></span></a>
    <?php }}?>
  </ul>
  </div>
  
    <div class="row" style="padding-left:1.5%;padding-right:1%;padding-bottom:1%;">
  <h3 style="font-size:18px;padding:3%;background-color:#e7e7e7;color:#777;">Popular Providers </h3>
  <ul class="list-group">
    <?php if(isset($popularProviders)){
    foreach($popularProviders as $popular){
    ?>
    <a href="<?php echo base_url();?>index.php/Plans/phoneSpecification/<?php echo $popular->id; ?>" class="list-group-item "><?php echo $popular->name; ?><span style="background-color:white;color:black;"class="badge">Views: <?php 
    if($popular->visits > 10000){

    echo "10k + views";
    }
      else{
    echo $popular->visits;
        }
    ?></span></a>
      <?php }?>
  </ul>
  <p style="text-align: center;"><a href="<?php echo base_url();?>index.php/Home/allProviders"></a></p>
    <?php }?>
  </div>


  <div class="row" style="padding-left:1.5%;padding-right:1%;padding-bottom:1%;">
  <h3 style="font-size:18px;padding:3%;background-color:#e7e7e7;color:#777;">Search By Price </h3>
    <ul class="list-group">
  <a href="<?php echo base_url();?>index.php/Plans/searchByPrice/100/0" class="list-group-item " >Prices > $100 </a>
    <a href="<?php echo base_url();?>index.php/Plans/searchByPrice/70/90" class="list-group-item">$70 - $90</a>
    <a href="<?php echo base_url();?>index.php/Plans/searchByPrice/40/60" class="list-group-item">$40 - $60</a>
  <a href="<?php echo base_url();?>index.php/Plans/searchByPrice/30/50" class="list-group-item"> $30 - $50</a>
  <a href="<?php echo base_url();?>index.php/Plans/searchByPrice/0/20" class="list-group-item">Prices < $20</a>
  </ul>
  </div>


  <div class="row" style="padding-left:1.5%;padding-right:1%;padding-bottom:1%;">
  <h3 style="font-size:18px;padding:3%;background-color:#e7e7e7;color:#777;">Find Plans By province </h3>
  <ul class="list-group">
    <?php if(isset($provinceList)){
    foreach($provinceList as $pl){
    ?>
    <a href="<?php echo base_url();?>index.php/Plans/plansByProvince/<?php echo $pl->id;?>" class="list-group-item "><?php echo $pl->name; ?></a>
      <?php }?>
  </ul>
  <p style="text-align: center;"><a href="<?php echo base_url();?>index.php/Home/allProviders"></a></p>
    <?php }?>
  </div>
  
  </div><!--Sidebar nav port end-->
  
  <!--Content port start-->
 <div id="cont" style="display:inline-block;">
  <!--Phone Start-->
   <div class="row" style="padding-left:1.5%;padding-right:1%;padding-bottom:1%;">
  <h3 id="latest" style="margin-top:2px;font-size:18px;background-color:#e7e7e7;color:#777;"><?php echo $new->name;?></h3>
  <div class="row" style="padding:3%;">
 
  <div class="col-lg-3" >
    <div class="thumbnail">
      <img src="<?php echo $new->logo;?>" alt="...">
      <div class="caption">
        <h3 style="text-align: center;font-size: 16px;"><?php echo $new->name;?>
       

            
 
        
      
    </div>
  </div>
    </div>
  <div class="col-lg-9" style="border:1px solid #e7e7e7;">
   
         
         <?php
        if(isset($providerPlans)){
        foreach ($providerPlans as $key) {?>
         <div class="row"  style="text-align:center;color:white;background-color:black;padding-left:2%;padding-top:8px;border-bottom:1px solid #e7e7e7;font-size: 20px;">
        
       <?php echo $key->name;
     
        ?>
        </div>
         <div class"row" style="font-size: 18px;padding-top:20px;padding-bottom: 20px;"> 
         <table border=1 style="width:100%;">

         <tr>
         <th style="text-align:center;">Province/State</th>
         <th style="text-align:center;">Talk</th>
         <th style="text-align:center;">Text</th>
         <th style="text-align:center;">Data</th>
         <th style="text-align:center;">Price</th>
         </tr>
         <?php
         $feature=null;
         $feature=$this->Provider->allFeatures($key->id,$country);
         if(isset($feature)){
          foreach($feature as $f){
          ?>
          <tr>
          <td style="text-align:center;">
            <?php echo $f->province_name;?>
            </td>
            <td style="text-align:center;">
            <?php echo $f->talk;?>
            </td>
            <td style="text-align:center;">
            <?php echo $f->text;?>
            </td>
            <td style="text-align:center;">
            <?php echo $f->data;?>
            </td>
            <td style="text-align:center;">
            <?php echo $f->price;?> $
            </td>
          </tr>

         <?php }}?>
         </table>
         <br>
         <br>
        

         </div>
         <?php    }
      }
?>
          
         
          
         
       
  </div>
  
  
  </div>
  </div><!--Phone End-->
  <div class="row">
<div class="col-sm-12">
<h3 style="margin-left:1%;">User Comments (<?php if(isset($comments)){ echo sizeof($comments);
}
else{
  echo "0";
}
  ?>)</h3>

</div><!-- /col-sm-12 -->
</div><!-- /row -->
<div class="row">
<?php 
if(isset($comments)){

foreach($comments as $row){
  ?>
<div class="col-sm-1">
<div class="thumbnail">
<?php if($row->picture != null){?>
<img class="img-responsive user-photo" src="<?php echo base_url();?>/img/user/<?php echo $row->picture;?>">
<?php }else{?>
<img class="img-responsive user-photo" src="https://ssl.gstatic.com/accounts/ui/avatar_2x.png">
<?php }?>
</div><!-- /thumbnail -->
</div><!-- /col-sm-1 -->

<div class="col-sm-11">
<div class="panel panel-default">
<div class="panel-heading">
<strong><?php echo $row->name;?></strong> <span class="text-muted"><?php
echo $this->Utility->time_elapsed_string($row->updated_at,true);
?></span>
</div>
<div class="panel-body">
<?php echo $row->comment;?>
</div><!-- /panel-body -->
<?php if(isset($user_id)){if($user_id == $row->user_id){?>
<div style="text-align: right;padding-right: 20px;padding-bottom: 10px;"><!--Edit link-->
<a href="javascript::void(0)" onclick="document.getElementById('edit_comment').value='<?php
 $remove[] = "'";
$remove[] = '"';
$remove[] = "-"; // just as another example

$string = str_replace( $remove, "", $row->comment );
echo $string

 ?>',document.getElementById('comment_id').value='<?php echo $row->id;?>'" data-toggle="modal" data-target="#editComment_dialog">Edit</a>
</div>
<?php }} ?>
</div><!-- /panel panel-default -->
</div><!-- /col-sm-5 -->
<?php 
}}
?>

</div><!-- /row -->
<br>
 <div class="row" ><a style="margin-left: 10%;" href="#" data-toggle="modal" data-target="#myComment"><strong>Post a comment</strong></a></div>
<br>
  </div><!--Content port end-->
<?php }}else{echo "<h2 style='margin-left:12%;'>Sorry No Provider Found</h2>";}?>
  <!--Content port end-->
</div>
  
</div><!--Container End-->