<div class="row" style="text-align: center;color: rgb(119, 119, 119);">
    <h3 style="font-size: 40px;">Sign Up</h3><br>
<form action="<?php echo base_url();?>index.php/admin/Accounts/create" method="POST" enctype="multipart/form-data">
    <div class="form-group">
    <label><strong>Enter your name</strong></label>
    <br>
<input type="text" name="name" style="width:18%;" required>
        <br><br>
        </div>
    <div class="form-group">
    <label><strong>Enter your email</strong></label>
    <br>
    <input type="email" name="email" style="width:18%;" required>
        <br><br>
        </div>

    <div class="form-group">
    <label><strong>Enter your password</strong></label>
    <br>
    <input type="password" name="password" style="width:18%;" required>
        <br><br>
        </div>

    <div class="form-group">
    <label><strong>Enter your website</strong></label>
    <br>
    <input type="url" name="website" style="width:18%;">
        </div>
    <br>
<style>
    input[type=file] {
        display: inline-block;
        margin-left: 9%;
    }
    </style>
    <div class="form-group" >
    <label><strong>Choose your picture</strong></label>
    <br>
        <br>
    <input name="userfile" type="file">
        </div>
    <br>
    <button type="submit" class="btn btn-default">Click To Proceed</button>
    </form>
    </div>