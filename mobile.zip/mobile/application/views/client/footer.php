<br>
<footer style="background-color:black;color:white;">


    <?php if(!isset($user_id)){ ?>
    <!-- Modal Sign In-->
  <div class="modal fade" id="myModal" role="dialog" style="background-color:black;color:#777;">
    <div class="modal-dialog"  style="margin-top:100px;">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header" style="border:none;">
          <button type="button" class="close" data-dismiss="modal">&times;</button>

        </div>
		<form action="<?php echo base_url();?>index.php/Home/doLogin" method="POST">
        <div class="modal-body" style="text-align: center;">
          <div class="row" style="text-align:center;padding-top:0px;">
              <h1>Sign-in</h1>
              <br>
            <img style="border:solid #efefef 10px;" src="<?php echo base_url();?>img/default.png" class="img-circle" height="250">
              </div>
		<br><br>
		  <input required type="email" name="email" placeholder="Email" style="width:80%;height:30px;"/>
		  <br>
            <br>

		  <input required  type="password" name="password" placeholder="Password" style="width:80%;height:30px;"/>
            <br><br>
           <p style="text-align:left;margin-left: 10%; ">
               <span style="padding-top:4px;">
                   <input style="width: 15px; height: 15px;" type="checkbox" name="remember_me">
               </span>
               <span style="vertical-align:top;font-size:16px;">
                  Keep me signed in
               </span>
           </p>
        </div>
        <div class="row" style="text-align: center;height:140px;">
          <button type="submit" class="btn btn-primary" style="padding-left:10%;padding-right: 10%;padding-top: 2%;padding-bottom: 2%; ">Sign in</button>
            <br>
            <br>
            <span>No Account? <a href="<?php echo base_url();?>index.php/Home/signUp">Create One!</a></span>
            <br><br>
            <span><a href="#">Forgot my password</a></span>
            <br><br>
        </div>
		 </form>
      </div>

    </div>
  </div><!--Modal End-->
    <?php }?>
      <!-- Modal Comment -->
  <div class="modal fade" id="myComment" role="dialog" style="background-color:black;color:#777;">
    <div class="modal-dialog"  style="margin-top:100px;">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header" style="border:none;">
          <button type="button" class="close" data-dismiss="modal">&times;</button>

        </div>
    
        <div class="modal-body" style="text-align: center;">
          <div class="row" style="text-align:center;padding-top:0px;">
              <h1>Post Your Comment</h1>
              <br>
              </div>
    <br><br>
      <textarea id="comment" style="width:80%;height:230px;"></textarea> 
      <br>
            <br>

      
          
        </div>
        <div class="row" style="text-align: center;height:140px;">
          <button  onclick="postComment()" class="btn btn-primary" style="padding-left:10%;padding-right: 10%;padding-top: 2%;padding-bottom: 2%; ">Comment</button>

            <br><br>
         <p id="error" style="color:red;display:none;">Please sign in to post</p>
         <p id="error2" style="color:red;display:none;">Please write a comment to post</p>
        </div>
    
      </div>

    </div>
  </div><!--Modal End-->

    <!-- Modal Comment -->
  <div class="modal fade" id="editComment_dialog" role="dialog" style="background-color:black;color:#777;">
    <div class="modal-dialog"  style="margin-top:100px;">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header" style="border:none;">
          <button type="button" class="close" data-dismiss="modal">&times;</button>

        </div>
    
        <div class="modal-body" style="text-align: center;">
          <div class="row" style="text-align:center;padding-top:0px;">
              <h1>Post Your Comment</h1>
              <br>
              </div>
    <br><br>
      <textarea id="edit_comment" style="width:80%;height:230px;"></textarea> 
      <input type="hidden" id="comment_id" value="0">
      <br>
            <br>

      
          
        </div>
        <div class="row" style="text-align: center;height:140px;">
          <button  onclick="editComment()" class="btn btn-primary" style="padding-left:10%;padding-right: 10%;padding-top: 2%;padding-bottom: 2%; ">Edit Comment</button>

            <br><br>
         <p id="edit_error" style="color:red;display:none;">Please sign in to post</p>
         <p id="edit_error2" style="color:red;display:none;">Please write a comment to post</p>
        </div>
    
      </div>

    </div>
  </div><!--Modal End-->


<br>
<p style="text-align:center;">MyCarrier.com CopyRight @2016 </p>
<br>
</footer>
</body>
</html>
