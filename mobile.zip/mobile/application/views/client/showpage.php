 
<style>
    .btn a{
        color:white;
        padding:0px;
    }
    .btn-primary{
        color:white;
        margin-left:10px;
    }
</style>
<div class="container-fluid" >
  <div class="row">

  
  
  <!--Content port start-->
  <div  style="border:1px solid #e7e7e7;min-height: 800px;">
       <!--Latest Items Starts-->
	   <div class="row" style="padding-left:1.5%;padding-right:1%;padding-bottom:1%;">
     <?php  if(isset($pages)){

          foreach($currentPage as $page){
?>
  <h3 id="latest" style="margin-top:2px;font-size:18px;background-color:#e7e7e7;color:#777;"><?php echo $page->title; ?></h3>
  <div class="row" style="padding:3%;">
  
  <?php if($page->is_active==1){echo $page->content;} ?>
</div>

<?php } }?>
  </div><!--Latest Items End-->
	
	
  
  </div><!--Content port end-->
</div>
</div>