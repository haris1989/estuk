 
<style>
    .btn a{
        color:white;
        padding:0px;
    }
    .btn-primary{
        color:white;
        margin-left:10px;
    }
</style>
<div class="container-fluid" >
  <div class="row">
<!--Sidebar nav port start-->
  <div class="col-md-3 col-lg-3" style="border:1px solid #e7e7e7;margin-left:1%;">
  <div class="row" style="padding-top:0px;padding-left:1.5%;padding-right:1%;padding-bottom:1%;">
  <h3 style="margin-top:2px;font-size:18px;padding:3%;background-color:#e7e7e7;color:#777;">Search </h3>
 <div class="input-group">
     <input type="text" class="form-control" placeholder="Search for providers....." autocomplete="off" onkeyup="generateList(this)" list="searchItems" type="text" name="search" id="search" tabindex="1">
     <datalist id="searchItems">

     </datalist>
      <span class="input-group-btn">
        <button class="btn btn-default" type="button" onclick="search();">Go!</button>
      </span>
    </div><!-- /input-group -->

  <br>
  </div>
   <div class="row" style="padding-left:1.5%;padding-right:1%;padding-bottom:1%;">
  <h3 style="font-size:18px;padding:3%;background-color:#e7e7e7;color:#777;">Featured Providers </h3>
  <ul class="list-group">
  <?php if(isset($fbrands)){
    foreach($fbrands as $brand){
    ?>
    <a href="<?php echo base_url();?>index.php/Plans/providerSpecification/<?php echo $brand->id; ?>" class="list-group-item "><?php echo $brand->name; ?><span class="badge"><?php 
    if($country == $brand->country) {
                echo $brand->number_of_plans;
            }
            else{
                echo "0";
            }?></span></a>
    <?php }}?>
  </ul>
  </div>
  
    <div class="row" style="padding-left:1.5%;padding-right:1%;padding-bottom:1%;">
  <h3 style="font-size:18px;padding:3%;background-color:#e7e7e7;color:#777;">Popular Providers </h3>
  <ul class="list-group">
    <?php if(isset($popularProviders)){
    foreach($popularProviders as $popular){
    ?>
    <a href="<?php echo base_url();?>index.php/Plans/phoneSpecification/<?php echo $popular->id; ?>" class="list-group-item "><?php echo $popular->name; ?><span style="background-color:white;color:black;"class="badge">Views: <?php 
    if($popular->visits > 10000){

    echo "10k + views";
    }
      else{
    echo $popular->visits;
        }
    ?></span></a>
      <?php }?>
  </ul>
  <p style="text-align: center;"><a href="<?php echo base_url();?>index.php/Home/allProviders"></a></p>
    <?php }?>
  </div>


  <div class="row" style="padding-left:1.5%;padding-right:1%;padding-bottom:1%;">
  <h3 style="font-size:18px;padding:3%;background-color:#e7e7e7;color:#777;">Search By Price </h3>
    <ul class="list-group">
  <a href="<?php echo base_url();?>index.php/Plans/searchByPrice/100/0" class="list-group-item " >Prices > $100 </a>
    <a href="<?php echo base_url();?>index.php/Plans/searchByPrice/70/90" class="list-group-item">$70 - $90</a>
    <a href="<?php echo base_url();?>index.php/Plans/searchByPrice/40/60" class="list-group-item">$40 - $60</a>
  <a href="<?php echo base_url();?>index.php/Plans/searchByPrice/30/50" class="list-group-item"> $30 - $50</a>
  <a href="<?php echo base_url();?>index.php/Plans/searchByPrice/0/20" class="list-group-item">Prices < $20</a>
  </ul>
  </div>
  
  <div class="row" style="padding-left:1.5%;padding-right:1%;padding-bottom:1%;">
  <h3 style="font-size:18px;padding:3%;background-color:#e7e7e7;color:#777;">Find Plans By province </h3>
  <ul class="list-group">
    <?php if(isset($provinceList)){
    foreach($provinceList as $pl){
    ?>
    <a href="<?php echo base_url();?>index.php/Plans/plansByProvince/<?php echo $pl->id;?>" class="list-group-item "><?php echo $pl->name; ?></a>
      <?php }?>
  </ul>
  <p style="text-align: center;"><a href="<?php echo base_url();?>index.php/Home/allProviders"></a></p>
    <?php }?>
  </div>
  
  </div><!--Sidebar nav port end-->
  
  <!--Content port start-->
  <div id="cont" style="border:1px solid #e7e7e7;display:inline-block;">
       <!--Latest Items Starts-->
	   <div class="row" style="padding-left:1.5%;padding-right:1%;padding-bottom:1%;">
  <h3 id="latest" style="margin-top:2px;font-size:18px;background-color:#e7e7e7;color:#777;">All News Result</h3>
  <div class="row" style="padding:3%;">
   <?php if(isset($listPaginate)){

    foreach($listPaginate as $list){
      if($list->is_active==1){
    ?>
 <div class="col-sm-6 col-md-4 col-lg-4">
    <div class="thumbnail" style="height:300px;">
      <img style="height:160px;z-index:0;position:absolute;width:87%;" src="<?php echo base_url();?>/img/news/thumb/<?php echo $list->banner;?>" alt="...">
      <div class="caption">
        <h3 style="padding-left:12px;padding-bottom:10px;padding-top:10px;width:84%;color:white;background: rgba(0,0,0,0.4) !important;position:absolute;margin-top:20px;font-size: 16px;"><?php echo $list->title;?></h3>
        <p style="margin-top:180px;">

        <?php 
       $con=strip_tags($list->content);
        $con=substr($con,0,150);
         echo $con ;?>......
          </p>

       <p style="text-align:right;"><a href="<?php echo base_url();?>index.php/Home/news/<?php echo $list->id; ?>" class="btn btn-default" role="button">View</a></p>
      </div>
    </div>
  </div>
<?php }}}?>
<p style="text-align: center;">
<?php  echo $this->pagination->create_links(); ?>
</p>
</div>
  </div><!--Latest Items End-->
	
	
  
  </div><!--Content port end-->
</div>
</div>