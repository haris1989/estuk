<div class="container">
<h2>Comapre the phones</h2>
<div style="text-align:center;" clas="row">
<label>Phone 1</label>
<input type="text" name="phone1" id="phone1" autocomplete="off" onkeyup="generateListCompare(this)" list="searchPhone1">
<datalist id="searchPhone1">

     </datalist>
&nbsp;&nbsp;&nbsp;&nbsp;
<label>Phone 2</label>
<input type="text" name="phone2" id="phone2"  autocomplete="off" onkeyup="generateListCompare(this)" list="searchPhone2">
<datalist id="searchPhone2">

     </datalist>
<br>
<br>
<button onclick="compare();">Compare Phones</button>
<br>
<br>
</div>
<div class="row" style="min-height:680px;">
<?php if(isset($phone1) && isset($phone2)){?>
<?php foreach ($phone1 as $new) {?>
<div class="col-lg-6 col-md-6 col-sm-6" style="">
<div class="row">
<div class="thumbnail">
      <img src="<?php echo base_url()."img/phones/".$new->name."/thumb/".$new->image;?>" alt="...">
      <div class="caption">
        <h3 style="text-align: center;font-size: 16px;"><?php echo $new->brand_name;?>
          <div class="row" style="font-size: 14px;text-align:center;padding-top:8px;">Price: <span style="color:red;"><?php

      if(strcmp($countryCurrency,"CAD $")==0){
            echo $countryCurrency . $new->price2;
        }
        else {
            echo $countryCurrency . $new->price;
        }

    ?></span></div>

            <div style="text-align:center;padding-top:8px;font-size: 14px;">

                 Perfomance Rating:  <?php
                  $total=0;
                  echo $new->rate_perfomance;
                  ?>

              </div>
              <div class="row"  style="font-size: 14px;text-align:center;padding-top:8px;">

                 Design Rating: <?php
                  $total=0;
                  echo $new->rate_design;
                  ?>

              </div>
              <div class="row"  style="font-size: 14px;text-align:center;padding-top:8px;">

                 Perfomance Feature:  <?php
                  $total=0;
                  echo $new->rate_feature;
                  ?>

              </div>

              <div style="text-align:center;padding-top:8px;">

                <b>Total Rating:</b> <?php
                  $total=0;
                  $total=($new->rate_design + $new->rate_feature + $new->rate_perfomance)/3;
                  echo round($total,1); ?>

              </div>
</div>
</div>
<div style="text-align:center;color:white;background-color:black;padding-left:2%;padding-top:8px;border-bottom:1px solid #e7e7e7;font-size: 20px;">
        OS<!--<span style="padding-left: 40%;"><?php echo $new->feature_os;?></span>-->
        </div>
        <div  style="font-size: 18px;padding-top:20px;padding-bottom: 20px;">OS Name: <?php echo $new->feature_os;?></div>
         <div style="text-align:center;color:white;background-color:black;padding-left:2%;padding-top:8px;border-bottom:1px solid #e7e7e7;font-size: 20px;">
        Display
        </div>
         <div class"row" style="font-size: 18px;padding-top:20px;padding-bottom: 20px;">Type: <?php if(sizeof($new->dis_type)>0&&$new->dis_type!=""){echo $new->dis_type;}else{ echo "N/A";}?>
         <br>
         <br>
         Size: <?php if(sizeof($new->dis_size)>0&&$new->dis_size!=""){echo $new->dis_size;}else{ echo "N/A";}?>
         <br>
         <br>
         Resolution: <?php if(sizeof($new->resolution)>0&&$new->resolution!=""){echo $new->resolution;}else{ echo "N/A";}?>
         <br>
         <br>
         MultiTouch: <?php if(sizeof($new->multitouch)>0&&$new->multitouch!=""){echo $new->multitouch;}else{ echo "N/A";}?>
         <br>
         <br>
         Protection: <?php if(sizeof($new->protection)>0&&$new->protection!=""){echo $new->protection;}else{ echo "N/A";}?>
         <br>
         <br>
         Other: <?php if(sizeof($new->dis_others)>0&&$new->dis_others!=""){echo $new->dis_others;}else{ echo "N/A";}?>
         <br>
         <br>

         </div>
         <div style="text-align:center;color:white;background-color:black;padding-left:2%;padding-top:8px;border-bottom:1px solid #e7e7e7;font-size: 20px;">
        Camera
        </div>
         <div class"row" style="font-size: 18px;padding-top:20px;padding-bottom: 20px;">Primary Camera: <?php if(sizeof($new->cam_primary)>0&&$new->cam_primary!=""){echo $new->cam_primary;}else{ echo "N/A";}?>
         <br>
         <br>
         Secondary Camera: <?php if(sizeof($new->cam_secondary)>0&&$new->cam_secondary!=""){echo $new->cam_secondary;}else{ echo "N/A";}?>
         <br>
         <br>
         Video: <?php if(sizeof($new->cam_video)>0&&$new->cam_video!=""){echo $new->cam_video;}else{ echo "N/A";}?>
         <br>
         <br>
           Other: <?php if(sizeof($new->cam_others)>0&&$new->cam_others!=""){echo $new->cam_others;}else{ echo "N/A";}?>
         <br>
         <br>
         
         </div>
         <div style="text-align:center;color:white;background-color:black;padding-left:2%;padding-top:8px;border-bottom:1px solid #e7e7e7;font-size: 20px;">
        Memory
        </div>
        <div class"row" style="font-size: 18px;padding-top:20px;padding-bottom: 20px;">Card Slot: <?php if(sizeof($new->card_slot)>0&&$new->card_slot!=""){echo $new->card_slot;}else{ echo "N/A";}?>
         <br>
         <br>
         Internal: <?php if(sizeof($new->Internal)>0&&$new->Internal!=""){echo $new->Internal;}else{ echo "N/A";}?>
         <br>
         <br>
         Call records: <?php if(sizeof($new->call_records)>0&&$new->call_records!=""){echo $new->call_records;}else{ echo "N/A";}?>
         <br>
         <br>
         Phonebook: <?php if(sizeof($new->phonebook)>0&&$new->phonebook!=""){echo $new->phonebook;}else{ echo "N/A";}?>
         <br>
         <br>
          Others: <?php if(sizeof($new->mem_others)>0&&$new->mem_others!=""){echo $new->mem_others;}else{ echo "N/A";}?>
         <br>
         <br>
         
         </div>
         <div style="text-align:center;color:white;background-color:black;padding-left:2%;padding-top:8px;border-bottom:1px solid #e7e7e7;font-size: 20px;">
        Network
        </div>
        <div class"row" style="font-size: 18px;padding-top:20px;padding-bottom: 20px;">2G Network: <?php if(sizeof($new->twog_network)>0&&$new->twog_network!=""){echo $new->twog_network;}else{ echo "N/A";}?>
         <br>
         <br>
         3G Network: <?php if(sizeof($new->threeg_network)>0&&$new->threeg_network!=""){echo $new->threeg_network;}else{ echo "N/A";}?>
         <br>
         <br>
         4G Network: <?php if(sizeof($new->fourg_network)>0&&$new->fourg_network!=""){echo $new->fourg_network;}else{ echo "N/A";}?>
         <br>
         <br>
          Others: <?php if(sizeof($new->gen_others)>0&&$new->gen_others!=""){echo $new->gen_others;}else{ echo "N/A";}?>
         <br>
         <br>
         
         </div>
</div>
</div>
<?php }?>

<?php foreach ($phone2 as $new2) {?>
<div class="col-lg-6 col-md-6 col-sm-6" style="border:1px solid white;">
<div class="row">
<div class="thumbnail">
      <img src="<?php echo base_url()."img/phones/".$new2->name."/thumb/".$new2->image;?>" alt="...">
      <div class="caption">
        <h3 style="text-align: center;font-size: 16px;"><?php echo $new2->brand_name;?>
          <div class="row" style="font-size: 14px;text-align:center;padding-top:8px;">Price: <span style="color:red;"><?php

      if(strcmp($countryCurrency,"CAD $")==0){
            echo $countryCurrency . $new2->price2;
        }
        else {
            echo $countryCurrency . $new2->price;
        }

    ?></span></div>

            <div style="text-align:center;padding-top:8px;font-size: 14px;">

                 Perfomance Rating:  <?php
                  $total=0;
                  echo $new2->rate_perfomance;
                  ?>

              </div>
              <div class="row"  style="font-size: 14px;text-align:center;padding-top:8px;">

                 Design Rating: <?php
                  $total=0;
                  echo $new2->rate_design;
                  ?>

              </div>
              <div class="row"  style="font-size: 14px;text-align:center;padding-top:8px;">

                 Perfomance Feature:  <?php
                  $total=0;
                  echo $new2->rate_feature;
                  ?>

              </div>

              <div style="text-align:center;padding-top:8px;">

                <b>Total Rating:</b> <?php
                  $total=0;
                  $total=($new2->rate_design + $new2->rate_feature + $new2->rate_perfomance)/3;
                  echo round($total,1); ?>

              </div>
</div>
</div>


<div  style="text-align:center;color:white;background-color:black;padding-top:8px; font-size: 20px;">
        OS
        </div>
        <div class"row" style="font-size: 18px;padding-top:20px;padding-bottom: 20px;">OS Name: <?php echo $new2->feature_os;?></div>
         <div style="text-align:center;color:white;background-color:black;padding-left:2%;padding-top:8px;border-bottom:1px solid #e7e7e7;font-size: 20px;">
        Display
        </div>
         <div class"row" style="font-size: 18px;padding-top:20px;padding-bottom: 20px;">Type: <?php if(sizeof($new2->dis_type)>0&&$new2->dis_type!=""){echo $new2->dis_type;}else{ echo "N/A";}?>
         <br>
         <br>
         Size: <?php if(sizeof($new2->dis_size)>0&&$new2->dis_size!=""){echo $new2->dis_size;}else{ echo "N/A";}?>
         <br>
         <br>
         Resolution: <?php if(sizeof($new2->resolution)>0&&$new2->resolution!=""){echo $new2->resolution;}else{ echo "N/A";}?>
         <br>
         <br>
         MultiTouch: <?php if(sizeof($new2->multitouch)>0&&$new->multitouch!=""){echo $new->multitouch;}else{ echo "N/A";}?>
         <br>
         <br>
         Protection: <?php if(sizeof($new2->protection)>0&&$new2->protection!=""){echo $new2->protection;}else{ echo "N/A";}?>
         <br>
         <br>
         Other: <?php if(sizeof($new2->dis_others)>0&&$new->dis_others!=""){echo $new2->dis_others;}else{ echo "N/A";}?>
         <br>
         <br>

         </div>
         <div style="text-align:center;color:white;background-color:black;padding-left:2%;padding-top:8px;border-bottom:1px solid #e7e7e7;font-size: 20px;">
        Camera
        </div>
         <div class"row" style="font-size: 18px;padding-top:20px;padding-bottom: 20px;">Primary Camera: <?php if(sizeof($new2->cam_primary)>0&&$new2->cam_primary!=""){echo $new2->cam_primary;}else{ echo "N/A";}?>
         <br>
         <br>
         Secondary Camera: <?php if(sizeof($new2->cam_secondary)>0&&$new2->cam_secondary!=""){echo $new2->cam_secondary;}else{ echo "N/A";}?>
         <br>
         <br>
         Video: <?php if(sizeof($new2->cam_video)>0&&$new2->cam_video!=""){echo $new2->cam_video;}else{ echo "N/A";}?>
         <br>
         <br>
           Other: <?php if(sizeof($new2->cam_others)>0&&$new2->cam_others!=""){echo $new2->cam_others;}else{ echo "N/A";}?>
         <br>
         <br>
         
         </div>
         <div style="text-align:center;color:white;background-color:black;padding-left:2%;padding-top:8px;border-bottom:1px solid #e7e7e7;font-size: 20px;">
        Memory
        </div>
        <div class"row" style="font-size: 18px;padding-top:20px;padding-bottom: 20px;">Card Slot: <?php if(sizeof($new2->card_slot)>0&&$new2->card_slot!=""){echo $new2->card_slot;}else{ echo "N/A";}?>
         <br>
         <br>
         Internal: <?php if(sizeof($new2->Internal)>0&&$new2->Internal!=""){echo $new2->Internal;}else{ echo "N/A";}?>
         <br>
         <br>
         Call records: <?php if(sizeof($new2->call_records)>0&&$new2->call_records!=""){echo $new2->call_records;}else{ echo "N/A";}?>
         <br>
         <br>
         Phonebook: <?php if(sizeof($new2->phonebook)>0&&$new2->phonebook!=""){echo $new2->phonebook;}else{ echo "N/A";}?>
         <br>
         <br>
          Others: <?php if(sizeof($new2->mem_others)>0&&$new2->mem_others!=""){echo $new2->mem_others;}else{ echo "N/A";}?>
         <br>
         <br>
         
         </div>
         <div style="text-align:center;color:white;background-color:black;padding-left:2%;padding-top:8px;border-bottom:1px solid #e7e7e7;font-size: 20px;">
        Network
        </div>
        <div class"row" style="font-size: 18px;padding-top:20px;padding-bottom: 20px;">2G Network: <?php if(sizeof($new2->twog_network)>0&&$new2->twog_network!=""){echo $new2->twog_network;}else{ echo "N/A";}?>
         <br>
         <br>
         3G Network: <?php if(sizeof($new2->threeg_network)>0&&$new2->threeg_network!=""){echo $new2->threeg_network;}else{ echo "N/A";}?>
         <br>
         <br>
         4G Network: <?php if(sizeof($new2->fourg_network)>0&&$new2->fourg_network!=""){echo $new2->fourg_network;}else{ echo "N/A";}?>
         <br>
         <br>
          Others: <?php if(sizeof($new2->gen_others)>0&&$new2->gen_others!=""){echo $new2->gen_others;}else{ echo "N/A";}?>
         <br>
         <br>
         
         </div>


<?php } ?>
</div>
<?php }?>
</div>
</div>
</div>