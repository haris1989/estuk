<?php if(isset($phonedetail)){
foreach($phonedetail as $ph){
?>
<div class="row">
        <div class="col-lg-12">
            <h1 class="page-header"><?php echo $ph->brand_name;?> <?php echo $ph->name;?> - edit phone</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->




    <div class="col-lg-12">
        <form action="<?php echo base_url();?>index.php/admin/Cellphones/update" method="post" enctype="multipart/form-data" name="PhonesEdit" onSubmit="return ValidatePhonesEdit()">

            <div class="row">
                <div class="col-lg-8">
                    <div class="form-group">
                        <label>Device model (WITHOUT brand name)</label>
                        <input class="form-control" name="name" type="text" value="<?php echo $ph->name;?>" />
                        <input type="hidden" name="old_name" value="<?php echo $ph->name;?>">
                    </div>

                          <div class="form-group">
                        <label>Description(Short summary about phone)</label><br />
                        <textarea id="textarea" name="description" cols="6" rows="10" class="form-control"><?php echo $ph->description;?></textarea>
                        <script type="text/javascript">
                            $('#textarea').summernote({
                                height: 250
                            });
                        </script>
                    </div>
                    <div class="form-group">
                        <label>Select brand</label>
                        <select name="brand_id" class="form-control">
                             <?php
                   if(isset($brands)){
                       $bool=true;
                   foreach($brands as $brand){
                   ?>
                    <?php if($brand->id==$ph->brand_id){?>
                       <option selected="selected"  value="<?php echo $brand->id;?>"><?php echo $brand->name;?></option>
                       <?php
                       $bool=false;
                       }
                       else{?>
                       <option  value="<?php echo $brand->id;?>"><?php echo $brand->name;?></option>

                    <?php
                       }
                       }
                   }?>

                        </select>
                    </div>


                    <div class="form-group">
                        <label>Upload Device image</label>
                        <p class="help-block">.png, .jpg, .jpeg, .gif only! The script will create 2 images (big image and thumb image). We recomend to upload a big image (min. 640px width <b>For best result upload 640 x480 image</b>)</p>
                        <input name="userfile" type="file">
                    </div>

                    <div class="form-group">
                        <label>Device official page (link)</label>
                        <input class="form-control" name="official_link" type="url" value="<?php echo $ph->official_link;?>" />
                    </div>

                    <div class="form-group">
                        <label>Meta title</label>
                        <input class="form-control" name="meta_title" type="text" value="<?php echo $ph->meta_title;?>" />
                    </div>

                    <div class="form-group">
                        <label>Meta description</label>
                        <input class="form-control" name="meta_description" type="text" value="<?php echo $ph->meta_description;?>" />
                    </div>

                    <div class="form-group">
                        <label>Meta keywords</label>
                        <input class="form-control" name="meta_keywords" type="text" value="<?php echo $ph->meta_keywords;?>" />
                    </div>


                </div>

                <div class="col-lg-4" >
                <div style="padding:0% 25% 0% 25%;">
                    <img class="img-responsive" style="max-width:160px; height:auto; border: none;" src="<?php echo base_url();?>img/phones/<?php echo $ph->name;?>/<?php echo $ph->image;?>" />
                    </div>
                    <input type="hidden" value="<?php echo $ph->image;?>" name="old_image">

                    <div class="clear"></div>

                    <div class="form-group">
                        <label>Popular device</label>
                        <select name="is_popular" class="form-control">
                                <?php
                 if($ph->is_popular == 1){?>

                    <option selected="selected" value="1" selected="selected">Yes</option>
                    <option  value="0">No</option>

                <?php }
                else{
                ?>

                    <option  value="1">Yes</option>
                    <option selected="selected"  value="0">No</option>

            <?php }?>
                        </select>

                    </div>

                    <div class="clear"></div>
                    <div class="form-group">
                        <label>Device Year</label>
                        <input class="form-control" name="year" type="date" value="<?php echo $ph->year?>" />
                    </div>

                    <div class="clear"></div>

                    <div class="form-group">
                        <label>Active device (show on site)</label>
                        <select name="active" class="form-control">
                             <?php
                 if($ph->active == 1){?>

                    <option selected="selected" value="1" selected="selected">Yes</option>
                    <option  value="0">No</option>

                <?php }
                else{
                ?>

                    <option  value="1">Yes</option>
                    <option selected="selected"  value="0">No</option>

            <?php }?>
                        </select>
                    </div>

                </div>

                <div class="clear"></div>

                <div class="form-group">
                    <input type="hidden" name="id" value="<?php echo $ph->id;?>" />
                    <button type="submit" class="btn btn-primary">Edit device summary</button>
                </div>


            </div> <!-- /.row -->
            </form>

            <div class="line"></div>

  <form action="<?php echo base_url();?>index.php/admin/Cellphones/updateDetail" method="post" enctype="multipart/form-data" name="PhonesEdit" onSubmit="return ValidatePhonesEdit()">
            <h3>General</h3>
            <div class="form-group">
                <label>Announced</label>
                <input name="announced" type="text" class="form-control" value="<?php echo $ph->announced;?>" />
            </div>
            <div class="form-group">
                <label>Status</label>
                <input name="status" type="text" class="form-control" value="<?php echo $ph->status;?>" />
            </div>
                <div class="form-group">
                <label>Technology</label>
                <input name="technology" type="text" class="form-control" value="<?php echo $ph->technology;?>" />
            </div>
            <div class="form-group">
                <label>2G Network</label>
                <input name="twog_network" type="text" class="form-control" value="<?php echo $ph->twog_network;?>" />
            </div>
            <div class="form-group">
                <label>3G Network</label>
                <input name="threeg_network" type="text" class="form-control" value="<?php echo $ph->threeg_network;?>" />
            </div>
            <div class="form-group">
                <label>4G Network</label>
                <input name="fourg_network" type="text" class="form-control" value="<?php echo $ph->fourg_network;?>" />
            </div>
            <div class="form-group">
                <label>Others</label>
                <textarea name="gen_others" class="form-control"><?php echo $ph->gen_others;?></textarea>

            </div>
            <div class='line'></div>
            <h3>Body</h3>
            <div class="form-group">
                <label>Dimensions</label>
                <input name="dimensions" type="text" class="form-control" value="<?php echo $ph->dimensions;?>" />
            </div>
            <div class="form-group">
                <label>Weight</label>
                <input name="weight" type="text" class="form-control" value="<?php echo $ph->weight;?>" />
            </div>
             <div class="form-group">
                <label>Build</label>
                <textarea name="build" class="form-control"><?php echo $ph->build;?></textarea>

            </div>
             <div class="form-group">
                <label>Sim</label>
                <textarea name="sim" class="form-control"><?php echo $ph->sim;?></textarea>

            </div>
            <div class="form-group">
                <label>Others</label>
                <textarea name="body_other" class="form-control"><?php echo $ph->body_other;?></textarea>

            </div>
            <div class='line'></div>
            <h3>Display</h3>
            <div class="form-group">
                <label>Type</label>
                <input name="dis_type" type="text" class="form-control" value="<?php echo $ph->dis_type;?>" />
            </div>
            <div class="form-group">
                <label>Size</label>
                <input name="dis_size" type="text" class="form-control" value="<?php echo $ph->dis_size;?>" />
            </div>
            <div class="form-group">
                <label>Resolution</label>
                <input name="resolution" type="text" class="form-control" value="<?php echo $ph->resolution;?>" />
            </div>
              <div class="form-group">
                <label>MultiTouch</label>
                <input name="multitouch" type="text" class="form-control" value="<?php echo $ph->multitouch;?>" />
            </div>
               <div class="form-group">
                <label>Protection</label>
                <input name="protection" type="text" class="form-control" value="<?php echo $ph->protection;?>" />
            </div>
            <div class="form-group">
                <label>Others</label>
                <textarea name="dis_others" class="form-control"><?php echo $ph->dis_others;?></textarea>

            </div>
            <div class='line'></div>
            <h3>Memory</h3>
            <div class="form-group">
                <label>Card slot</label>
                <input name="card_slot" type="text" class="form-control" value="<?php echo $ph->card_slot;?>" />
            </div>
            <div class="form-group">
                <label>Internal</label>
                <input name="Internal" type="text" class="form-control" value="<?php echo $ph->Internal;?>" />
            </div>
            <div class="form-group">
                <label>Call records</label>
                <input name="call_records" type="text" class="form-control" value="<?php echo $ph->call_records;?>" />
            </div>
            <div class="form-group">
                <label>Phonebook</label>
                <input name="phonebook" type="text" class="form-control" value="<?php echo $ph->phonebook;?>" />
            </div>
            <div class="form-group">
                <label>Others</label>
                <textarea name="mem_others" class="form-control"><?php echo $ph->mem_others;?></textarea>

            </div>
            <div class='line'></div>
            <h3>Sound</h3>
            <div class="form-group">
                <label>Alert types</label>
                <input name="alert_types" type="text" class="form-control" value="<?php echo $ph->alert_types;?>" />
            </div>
            <div class="form-group">
                <label>Speakerphone </label>
                <input name="speaker_phone" type="text" class="form-control" value="<?php echo $ph->speaker_phone;?>" />
            </div>
             <div class="form-group">
                <label>3.5mm jack </label>
                <input name="speaker_jack" type="text" class="form-control" value="<?php echo $ph->speaker_jack;?>" />
            </div>
            <div class="form-group">
                <label>Others</label>
                <textarea name="sound_others" class="form-control"><?php echo $ph->sound_others;?></textarea>

            </div>
            <div class='line'></div>
            <h3>Data</h3>
            <div class="form-group">
                <label>GPS</label>
                <input name="feature_gps" type="text" class="form-control" value="<?php echo $ph->feature_gps;?>" />
            </div>
            <div class="form-group">
                <label>EDGE</label>
                <input name="edge" type="text" class="form-control" value="<?php echo $ph->edge;?>" />
            </div>
            <div class="form-group">
                <label>Speed</label>
                <input name="speed" type="text" class="form-control" value="<?php echo $ph->speed;?>" />
            </div>
            <div class="form-group">
                <label>WLAN</label>
                <input name="wlan" type="text" class="form-control" value="<?php echo $ph->wlan;?>" />
            </div>
            <div class="form-group">
                <label>Bluetooth</label>
                <input name="bluetooth" type="text" class="form-control" value="<?php echo $ph->bluetooth;?>" />
            </div>
            <div class="form-group">
                <label>USB</label>
                <input name="usb" type="text" class="form-control" value="<?php echo $ph->usb;?>" />
            </div>


            <div class='line'></div>
            <h3>Camera</h3>
            <div class="form-group">
                <label>Primary</label>
                <input name="cam_primary" type="text" class="form-control" value="<?php echo $ph->cam_primary;?>" />
            </div>
            <div class="form-group">
                <label>Secondary</label>
                <input name="cam_secondary" type="text" class="form-control" value="<?php echo $ph->cam_secondary;?>" />
            </div>
            <div class="form-group">
                <label>Video</label>
                <input name="cam_video" type="text" class="form-control" value="<?php echo $ph->cam_video;?>" />
            </div>

            <div class="form-group">
                <label>Others</label>
                <textarea name="cam_others" class="form-control"><?php echo $ph->cam_others;?></textarea>

            </div>
            <div class='line'></div>
            <h3>Features</h3>
            <div class="form-group">
                <label>OS</label>
                <input name="feature_os" type="text" class="form-control" value="<?php echo $ph->feature_os;?>" />
            </div>
            <div class="form-group">
                <label>Chipset</label>
                <input name="feature_chipset" type="text" class="form-control" value="<?php echo $ph->feature_chipset;?>" />
            </div>
            <div class="form-group">
                <label>CPU</label>
                <input name="feature_cpu" type="text" class="form-control" value="<?php echo $ph->feature_cpu;?>" />
            </div>
               <div class="form-group">
                <label>GPU</label>
                <input name="feature_gpu" type="text" class="form-control" value="<?php echo $ph->feature_gpu;?>" />
            </div>
            <div class="form-group">
                <label>Ram</label>
                <input name="feature_ram" type="text" class="form-control" value="<?php echo $ph->feature_ram;?>" />
            </div>
            <div class="form-group">
                <label>Rom</label>
                <input name="feature_rom" type="text" class="form-control" value="<?php echo $ph->feature_rom;?>" />
            </div>
            <div class="form-group">
                <label>Sensors</label>
                <input name="feature_sensors" type="text" class="form-control" value="<?php echo $ph->feature_sensors;?>" />
            </div>
            <div class="form-group">
                <label>Messaging</label>
                <input name="feature_messaging" type="text" class="form-control" value="<?php echo $ph->feature_messaging;?>" />
            </div>
            <div class="form-group">
                <label>Browser</label>
                <input name="feature_browser" type="text" class="form-control" value="<?php echo $ph->feature_browser;?>" />
            </div>
            <div class="form-group">
                <label>Radio</label>
                <input name="feature_radio" type="text" class="form-control" value="<?php echo $ph->feature_radio;?>" />
            </div>

            <div class="form-group">
                <label>Java</label>
                <input name="feature_java" type="text" class="form-control" value="<?php echo $ph->feature_java;?>" />
            </div>


            <div class="form-group">
                <label>Others</label>
          <textarea name="feature_others" class="form-control"><?php echo $ph->feature_others;?></textarea>

            </div>
            <div class='line'></div>
            <h3>Battery</h3>
            <div class="form-group">
                <label>Battery Type</label>
                <input name="batt_type" type="text" class="form-control" value="<?php echo $ph->batt_type;?>" />
            </div>
            <div class="form-group">
                <label>Stand-by</label>
                <input name="batt_stand_by" type="text" class="form-control" value="<?php echo $ph->batt_stand_by;?>" />
            </div>
            <div class="form-group">
                <label>Talk time</label>
                <input name="batt_talk_time" type="text" class="form-control" value="<?php echo $ph->batt_talk_time;?>" />
            </div>
            <div class="form-group">
                <label>Music play</label>
                <input name="batt_music_play" type="text" class="form-control" value="<?php echo $ph->batt_music_play;?>" />
            </div>
            <div class="form-group">
                <label>Others</label>
                <textarea name="batt_others" class="form-control"><?php echo $ph->batt_others;?></textarea>

            </div>
            <div class='line'></div>
            <h3>Misc</h3>
              <div class="form-group">
                <label>Colors</label>
                <input name="feature_colors" type="text" class="form-control" value="<?php echo $ph->feature_colors;?>" />
            </div>
            <div class="form-group">
                <label>SAR US</label>
                <input name="misc_sar_us" type="text" class="form-control" value="<?php echo $ph->misc_sar_us;?>" />
            </div>
            <div class="form-group">
                <label>SAR EU</label>
                <input name="misc_sar_eu" type="text" class="form-control" value="<?php echo $ph->misc_sar_eu;?>" />
            </div>
            <div class='line'></div>
            <h3>overview</h3>
            <div class="form-group">
                <label>About device</label>
                <textarea name="misc_overview" class="form-control">

                <?php echo $ph->misc_overview;?>
                </textarea>

            </div>
            <div class='line'></div>
            <h3>Tests</h3>
              <div class="form-group">
                <label>Tests</label>
                <textarea name="tests" class="form-control">
                <?php echo $ph->tests;?>
                </textarea>

            </div>
            <div class='line'></div>

            <div class="form-group">
                <input type="hidden" name="phone_id" value="<?php echo $ph->id;?>" />
                <button type="submit" class="btn btn-primary">Edit device details</button>
            </div>
        </form>
    </div>



    <div class="clear"></div>






</div><!-- /.col-lg-12 -->
</div><!-- /.row -->

</div> <!-- /.page-wraper -->

</div>
<!-- /#wrapper -->
<?php }}?>
</body>

</html>