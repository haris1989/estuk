<script type="text/javascript" charset="utf-8">
    $(document).ready(function()
    {
        var dontSort = [];
        $('#filterTable thead th').each( function () {
            if ( $(this).hasClass( 'no_sort' )) {
                dontSort.push( { "bSortable": false } );
            } else {
                dontSort.push( null );
            }
        } );

        $('#filterTable').dataTable({"aoColumns": dontSort, "order": [[ 1, "asc" ]]});

    });
</script>
    
<style>
    .btn a{
        color:white;
        padding:0px;
    }
    .btn-primary{
        color:white;
        margin-left:10px;
    }
</style>

    <div class="row">
        <div class="col-lg-12">
            <h1 class="new-header">All News </h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->



    <div class="row">
        <div class="col-lg-12">

            <div class="panel-body nopadding">

                <a style="cursor:pointer; color:#296BBC; text-decoration:none; font-size:11px;" onclick="showhide('form_News_News');"><strong>CREATE NEWS</strong></a>

                <div id="form_News_News" style="display: none;">
                    <div class="clear"></div>

                    <form action="<?php echo base_url(); ?>index.php/admin/News/create" method="post" enctype="multipart/form-data">

                        <div class="form-group">
                            <label>News title</label>
                            <input class="form-control" name="title" type="text" required/>
                        </div>

                        <div class="form-group">
                            <label>News content</label>
                            <textarea id="textarea" name="content" cols="6" rows="10" class="form-control"></textarea>
                            <script type="text/javascript">
                                $('#textarea').summernote({
                                    height: 250
                                });
                            </script>
                        </div>

                         
            <div class="form-group">
                <label>Upload cell phone image</label>
                <p class="help-block">.png, .jpg, .jpeg, .gif only! The script will create 2 images (big image and thumb image). We recomend to upload a big image (min. 600px width)</p>
                <input name="userfile" type="file">
            </div>

                        <div class="form-group">
                            <label>News Keywords</label>
                            <input class="form-control" name="keywords" type="text" required/>
                        </div>

                        <div class="form-group">
                            <label>News active?</label>
                            <select name="is_active" class="form-control">
                                <option value="1" selected="selected">Active</option>
                                <option value="0">Inactive</option>
                            </select>
                        </div>

                        <button type="submit" class="btn btn-primary">Submit News</button>
                    </form>
   <div class="clear"></div>
                </div>


                <table id="filterTable" class="table table-bordered">
                    <thead>
                    <tr>
                        <th class="sort" align="left">Num</th>
                        <th align="left">Title</th>
                        <th class="no_sort" align="left">Actions</th>
                    </tr>
                    </thead>

                    <tbody>

    <?php if(isset($news)){
                        $count=1;

                        foreach($news as $new){
                    ?>
                    <tr>
                        <td align="left" valign="top"><strong><?php echo $count; ?></strong></td>
                        <td align="left" valign="top">
                            <strong><?php echo $new->title;  ?></strong>
                            <br/>
                            
                            <?php if($new->is_active==1){?>
                            <font color='#339966'>news active</font> </td>
                        <?php }
                        else{
                            ?>

                        <font color='red'>news inactive</font>      </td>
                        <?php } ?>
                        </td>
                        <td align="left" valign="top">
                            <a href="<?php echo base_url();?>index.php/admin/news/edit/<?php echo $new->id; ?>"><i class="fa fa-pencil fa-fw"></i> Edit News</a>
                            <div class="clear"></div>
                            <a onclick="return confirm('Are you sure?')" href="<?php echo base_url();?>index.php/admin/news/destroy/<?php echo $new->id; ?>"><i class="fa fa-trash-o fa-fw"></i> Delete News</a>
                        </td>
                    </tr>
                    <?php
                    $count++;
                        }
                    }
                    ?>


                    </tbody>
                </table>

             
                

             


                <div class="clear"></div>


            </div><!-- /.panel-body -->
        </div><!-- /.col-lg-12 -->
    </div><!-- /.row -->

</div> <!-- /.new-wraper -->

</div>
<!-- /#wrapper -->

</body>

</html>