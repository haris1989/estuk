
<script language=JavaScript>
    function reload(form)
    {
        var val=form.brand_id.options[form.brand_id.options.selectedIndex].value;
        self.location='http://mobile.mxscripts.com/admin/account.php?page=reviews_add&brand_id=' + val ;
    }

    function reload2(form)
    {
        var val2=form.phone_id.options[form.phone_id.options.selectedIndex].value;
        self.location='http://mobile.mxscripts.com/admin/account.php?page=reviews_add&phone_id=' + val2 + '&brand_id=0';
    }
</script>

    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Add Review</h1>
            <p class="text-info">INFO: You must add a review for an existing mobile phone. If the phone model does not exists, you must add the mobile phone first!</p>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->



    <div class="row">
        <div class="col-lg-12">

            <div class="panel-body nopadding">

                <form action="reviews_add_submit.php" method="post" class="form" enctype="multipart/form-data">

                    <div class="form-group">
                        <label>Select brand</label>
                        <select name="brand_id" class="form-control" onchange="reload(this.form)">
                            <option disabled="disabled" selected="selected" value="">- select brand -</option>

                            <option  value="2">Alcatel</option>

                            <option  value="3">Amoi</option>

                            <option  value="4">Apple</option>

                            <option  value="5">Asus</option>

                            <option  value="6">AT&T</option>

                            <option  value="7">Benefon</option>

                            <option  value="8">BenQ</option>

                            <option  value="9">BenQ-Siemens</option>

                            <option  value="10">Bird</option>

                            <option  value="11">BlackBerry</option>

                            <option  value="12">Bosch</option>

                            <option  value="13">Chea</option>

                            <option  value="68">Deleted</option>

                            <option  value="14">Dell</option>

                            <option  value="15">Ericsson</option>

                            <option  value="16">Eten</option>

                            <option  value="17">Fujitsu Siemens</option>

                            <option  value="18">Garmin-Asus</option>

                            <option  value="19">Gigabyte</option>

                            <option  value="20">Haier</option>

                            <option  value="21">HP</option>

                            <option  value="22">HTC</option>

                            <option  value="23">Huawei</option>

                            <option  value="24">i-mate</option>

                            <option  value="25">i-mobile</option>

                            <option  value="26">Innostream</option>

                            <option  value="27">iNQ</option>

                            <option  value="28">Kyocera</option>

                            <option  value="29">LG</option>

                            <option  value="30">Maxon</option>

                            <option  value="31">Micromax</option>

                            <option  value="32">Microsoft</option>

                            <option  value="33">Mitac</option>

                            <option  value="34">Mitsubishi</option>

                            <option  value="35">Modu</option>

                            <option  value="36">Motorola</option>

                            <option  value="37">MWg</option>

                            <option  value="38">NEC</option>

                            <option  value="39">Neonode</option>

                            <option  value="40">Nokia</option>

                            <option  value="41">O2</option>

                            <option  value="42">Palm</option>

                            <option  value="43">Panasonic</option>

                            <option  value="44">Pantech</option>

                            <option  value="45">Philips</option>

                            <option  value="46">Qtek</option>

                            <option  value="47">Sagem</option>

                            <option  value="48">Samsung</option>

                            <option  value="49">Sendo</option>

                            <option  value="50">Sewon</option>

                            <option  value="51">Sharp</option>

                            <option  value="52">Siemens</option>

                            <option  value="53">Sonim</option>

                            <option  value="54">Sony</option>

                            <option  value="55">Sony Ericsson</option>

                            <option  value="56">T-Mobile</option>

                            <option  value="57">Tel.Me.</option>

                            <option  value="58">Telit</option>

                            <option  value="59">Thuraya</option>

                            <option  value="60">Toshiba</option>

                            <option  value="61">Vertu</option>

                            <option  value="62">VK Mobile</option>

                            <option  value="63">Vodafone</option>

                            <option  value="64">WND</option>

                            <option  value="65">XCute</option>

                            <option  value="66">ZTE</option>

                        </select>
                    </div>

                    <div class="form-group">
                        <label>Select phone</label>
                        <select name="phone_id" class="form-control">
                            <option disabled="disabled" selected="selected" value="">- select phone -</option>

                        </select>
                    </div>

                    <div class="form-group">
                        <label>Review Title</label>
                        <input type="text" name="title" class="form-control" id="newsTitle" placeholder="Enter title">
                    </div>

                    <div class="form-group">
                        <strong>Review content</strong><br />
                        <textarea id="textarea" name="content" cols="6" rows="10" class="form-control"></textarea>
                        <script type="text/javascript">
                            $('#textarea').summernote({
                                height: 250
                            });
                        </script>
                    </div>

                    <div class="form-group">
                        <label>Review image</label>
                        <p class="help-block">.png, .jpg, .jpeg, .gif only! Recomended size: max 160px width, max 200px height</p>
                        <input type="file" name="image">
                    </div>

                    <div class="form-group">
                        <label>Keywords (tags)</label>
                        <input type="text" name="keywords" class="form-control" id="newsKeywords" placeholder="keywords">
                    </div>

                    <div class="form-group">
                        <label>Page Title</label>
                        <p class="help-block">Leave blank if you review have one page. If review have more pages, you can choose a page title (For example: "introduction")</p>
                        <input type="text" name="page_title" class="form-control" id="newsTitle" placeholder="Enter page title">
                    </div>


                    <button type="submit" name="action_publish" value="publish" class="btn btn-success">Publish</button>
                    <button type="submit" name="action_draft" value="draft" class="btn btn-danger">Save draft</button>
                </form>


                <div class="clear"></div>


            </div><!-- /.panel-body -->
        </div><!-- /.col-lg-12 -->
    </div><!-- /.row -->

</div> <!-- /.page-wraper -->

</div>
<!-- /#wrapper -->

</body>

</html>