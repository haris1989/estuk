

    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Edit ads</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->




    <form action="<?php echo base_url();?>index.php/admin/Adds/update" method="post">
<?php
    if(isset($adds)) {
        foreach ($adds as $add) {
            ?>
            <div class="form-group">
                <label>Zone description</label>
                <input class="form-control" name="zone_name" type="text" value="<?php echo $add->zone_name; ?>" required/>
            </div>

            <div class="form-group">
                <input type="hidden" name="id" value="<?php echo $add->id; ?>">
                <label>HTML Code</label>
                <textarea id="textarea" name="add_html_code" cols="6" rows="10" class="form-control"
                          required><?php echo $add->add_html_code; ?></textarea>
            </div>

            <div class="form-group">
                <label>Ad active?</label>

                <select name="status" class="form-control">

                    <?php
                    $activeStatus="";
                    $inactiveStatus="";
                    if ($add->status == 1){
                        $activeStatus= 'selected="selected"';
                    }
                    else{
                        $inactiveStatus= 'selected="selected"';
                    }
                    ?>

                    <option value="1" <?php echo $activeStatus ?> >Active</option>
                    <option value="0" <?php echo $inactiveStatus ?>>Inactive</option>

                </select>
            </div>
            <?php
        }
    }
        ?>

        <button type="submit" class="btn btn-primary">Update</button>
    </form>


    <div class="clear"></div>

    <div class="clear"></div>

</div><!-- /.panel-body -->
</div><!-- /.col-lg-12 -->
</div><!-- /.row -->

</div> <!-- /.page-wraper -->

</div>
<!-- /#wrapper -->

}