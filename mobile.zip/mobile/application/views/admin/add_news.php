

    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Add News</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->



    <div class="row">
        <div class="col-lg-12">

            <div class="panel-body nopadding">

                <form action="news_add_submit.php" method="post" class="form" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Title</label>
                        <input type="text" name="title" class="form-control" id="newsTitle" placeholder="Enter title">
                    </div>

                    <div class="form-group">
                        <strong>News content</strong><br />
                        <textarea id="textarea" name="content" cols="6" rows="10" class="form-control"></textarea>
                        <script type="text/javascript">
                            $('#textarea').summernote({
                                height: 250
                            });
                        </script>
                    </div>

              

                    <div class="form-group">
                        <label for="exampleInputEmail1">Keywords</label>
                        <input type="text" name="keywords" class="form-control" id="keywords" placeholder="News keywords">
                    </div>

                    <label>News active</label>
                            <select name="is_active" class="form-control">
                                <option value="1" selected="selected">Publish</option>
                                <option value="0">Save Draft</option>
                            </select>
                </form>


                <div class="clear"></div>


            </div><!-- /.panel-body -->
        </div><!-- /.col-lg-12 -->
    </div><!-- /.row -->

</div> <!-- /.page-wraper -->

</div>
<!-- /#wrapper -->

</body>

</html>