<script type="text/javascript" charset="utf-8">
    $(document).ready(function()
    {
        var dontSort = [];
        $('#filterTable thead th').each( function () {
            if ( $(this).hasClass( 'no_sort' )) {
                dontSort.push( { "bSortable": false } );
            } else {
                dontSort.push( null );
            }
        } );

        $('#filterTable').dataTable({"aoColumns": dontSort, "order": [[ 1, "asc" ]]});

    });
</script>
    <div class="row">
        <div class="col-lg-12">
            <h1 class="new-header">All Reviews</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->



    <div class="row">
        <div class="col-lg-12">

            <div class="panel-body nopadding">

                <a style="cursor:pointer; color:#296BBC; text-decoration:none; font-size:11px;" href="<?php echo base_url();?>index.php/admin/Reviews/add"><strong>Create New Review</strong></a>

            


<br>
<br><br><br>
<table id="filterTable" class="table table-bordered">
                    <thead>
                  
                    <tr>
                        <th align="left" >Num</th>
                        <th align="left">Thumb</th>
                        <th align="left">Title</th>
                        <th align="left">Total Pages</th>
                        
                        <th class="no_sort" align="left">Actions</th>
                    </tr>
                    </thead>

                    <tbody>

                     <?php if(isset($reviews)){
                        $count=1;

                        
                        foreach($reviews as $new){
                    ?>
                    <tr>
                        <td align="center" valign="top"><strong><?php echo $count; ?></strong></td>
                            
                             <td align="left" valign="top">
                           <img src="<?php echo base_url();?>img/reviews/thumb/<?php echo $new->image; ?>">
                            </td>
                            
                            
                        <td align="left" valign="top">
                            <strong><?php echo $new->title; ?></strong>
                            <br/>
                            
                            <?php if($new->is_active==1){?>
                            <font color='#339966'>Review active</font>      
                        <?php }
                        else{
                            ?>

                        <font color='red'>Review inactive</font>      
                        <?php } ?>
                        </td>
                       
                        <td align="center" valign="top"><strong><?php echo $new->pages; ?></strong>

                        </td>
                        <td align="left" valign="top">
                            <a href="<?php echo base_url();?>index.php/admin/Reviews/edit/<?php echo $new->id; ?>"><i class="fa fa-pencil fa-fw"></i> Edit Review</a>
                            <div class="clear"></div>
                                <i class="fa fa-trash-o fa-fw"></i> <a class="confirm_<?php echo $new->id;?>" href="<?php echo base_url();?>index.php/admin/Reviews/destroy/<?php echo $new->id;?>">Delete Review</a>
                                <div class="clear"></div>
                                 
                              <?php if($new->pages > 0){?>
                                <i class="fa fa-eye fa-fw"></i> <a class="confirm_<?php echo $new->id;?>" href="<?php echo base_url();?>index.php/admin/Reviews/pages/<?php echo $new->id;?>">Show all pages</a>
                                <?php }
                                else{?>
                                <i class="fa fa-plus fa-fw"></i> <a class="confirm_<?php echo $new->id;?>" href="<?php echo base_url();?>index.php/admin/Reviews/pages/<?php echo $new->id;?>">Add Page</a>
                                 <div class="clear"></div>
                                 <?php } ?>

                        </td>
                    </tr>
                    <?php
                    $count++;
                        }
                    }
                    ?>



                    </tbody>
                    </table>


                <div class="clear"></div>


            </div><!-- /.panel-body -->
        </div><!-- /.col-lg-12 -->
    </div><!-- /.row -->

</div> <!-- /.new-wraper -->

</div>
<!-- /#wrapper -->

</body>

</html>