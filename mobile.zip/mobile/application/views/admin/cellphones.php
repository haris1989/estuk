<script type="text/javascript" charset="utf-8">
    $(document).ready(function()
    {
        var dontSort = [];
        $('#filterTable thead th').each( function () {
            if ( $(this).hasClass( 'no_sort' )) {
                dontSort.push( { "bSortable": false } );
            } else {
                dontSort.push( null );
            }
        } );

        $('#filterTable').dataTable({"aoColumns": dontSort, "order": [[ 1, "asc" ]]});

    });
</script>
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">All Phones (<?php
                if($cellphones){

                    echo count($cellphones);
                }
                ?>)
                <a class="btn btn-primary btn-default" href="<?php echo base_url();?>index.php/admin/Cellphones/add"><i class="fa fa-edit"></i> Add new Phone</a>
                <a class="btn btn-primary btn-default confirm_all" href="#">Delete Selected Phone</a>

                <script>
                    $(".confirm_all").confirm({
                        text: "Do you really want to delete selected phones? <br>Phone page will be <strong>permanently deleted</strong>. Also, selected phone data and images will be deleted from database",
                        title: "Confirm delete",
                        confirm: function(button) {
                            // do something

                            var flag=0;
                            json_obj=[];
                            $('input:checkbox:checked').each(function() {
                                flag=1;

                            });
                            var obj=JSON.stringify(json_obj);
                            console.log(obj);
                            if(flag==0){
                                alert("Please select at least one phone");
                            }
                            else {
                          $('#del').submit();
                            }
                        },
                        cancel: function(button) {
                            // do something
                        },
                        confirmButton: "DELETE",
                        cancelButton: "CANCEL",
                        post: false
                    });
                </script>
            </h1>


            <div class="clear"></div>

        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->



    <div class="row">
        <div class="col-lg-12">

            <div class="panel-body nopadding">

<form method="GET" id="del" action="<?php echo base_url();?>index.php/admin/Cellphones/destroySelected">
                <table id="filterTable" class="table table-bordered">
                    <thead>
                    <tr>
                        <th align="left" width="60" >Select</th>
                        <th align="left">Thumb</th>
                        <th align="left">Details</th>
                        <th align="left">Price</th>
                        <th align="left">Visits</th>
                        <th align="left">Rate</th>
                        <th class="no_sort" align="left">Actions</th>
                    </tr>
                    </thead>

                    <tbody>

                    <?php
                    if(isset($cellphones)){
                        foreach($cellphones as $cellphone){?>
                            <tr>
                                <td style="padding-left:1.7%;" align="left" valign="top">
                                    <input name="multiselect[]" type="checkbox" value="<?php echo $cellphone->id;?>" />
                                </td>
                                <td align="left" valign="top">
                                    <img src="<?php echo base_url();?>img/phones/<?php echo $cellphone->name; ?>/thumb/<?php echo $cellphone->image;?>" />
                                </td>

                                <td align="left" valign="top">
                                    <strong> <?php echo $cellphone->name; ?> </strong>
                                    <div class="clear"></div>
                                    <small>
                                       Added: <?php echo $cellphone->created_at;?>
                                        <br>
                                        Device type: Phones

                                    </small>

                                </td>

                                <td align="left" valign="top">
                                    <?php if($cellphone->price == 0){ ?>
                                        <em>US price not set</em>
                                    <?php }
                                    else{?>
                                    <em>US$ <?php echo number_format($cellphone->price);?>.00</em>
                                        <?php
                                    }
                                    ?>
                                    <div class="clear"></div>
                                     <?php if($cellphone->price2 == 0){ ?>
                                        <em>CA price not set</em>
                                    <?php }
                                    else{?>
                                    <em>CA$ <?php echo number_format($cellphone->price2);?>.00</em>
                                        <?php
                                    }
                                    ?>
                                    <div class="clear"></div>
                                    <i class="fa fa-money fa-fw"></i>
                                    <a href="<?php echo base_url();?>index.php/admin/Cellphones/managecellphonePrice/<?php echo $cellphone->id; ?>">Manage prices</a>
                                </td>

                                <td align="left" valign="top">
                                    <?php echo $cellphone->visits;?>
                                </td>
                                <td>
                                    <?php
                                    $total=0;
                                    $total=($cellphone->rate_design + $cellphone->rate_feature + $cellphone->rate_perfomance)/3;
                                    ?>
                                    <strong>RATE: <?php echo round($total,1);?></strong> <small>(<?php echo round($total,1);?> votes)</small>
                                    <div class="clear"></div>
                                    Design: <?php echo $cellphone->rate_design; ?><br />
                                    Features: <?php echo $cellphone->rate_feature; ?><br />
                                    Performance: <?php echo $cellphone->rate_perfomance; ?>
                                </td>

                                <td align="left" valign="top">
                                    <i class="fa fa-pencil-square-o fa-fw"></i> <a href="<?php echo base_url();?>index.php/admin/Cellphones/edit/<?php echo $cellphone->id;?>">Edit Phone</a>
                                    <div class="clear"></div>
                                    <i class="fa fa-picture-o fa-fw"></i> <a href="<?php echo base_url();?>index.php/admin/Cellphones/moreImages/3332">Images (0)</a>
                                    <div class="clear"></div>

                                    <i class="fa fa-trash-o fa-fw"></i> <a class="confirm_<?php echo $cellphone->id;?>" href="#">Delete Phone</a>

                                    <script>
                                        $(".confirm_<?php echo $cellphone->id;?>").confirm({
                                            text: "Do you really want to delete this phone? <br>Phone page will be <strong>permanently deleted</strong>. Also, phone images will be deleted from database",
                                            title: "Confirm delete",
                                            confirm: function(button) {
                                                // do something
                                                // alert(<?php echo $cellphone->id;?>);
                                                location.href = "<?php echo base_url();?>index.php/admin/Cellphones/destroy/<?php echo $cellphone->id;?>"
                                            },
                                            cancel: function(button) {
                                                // do something
                                            },
                                            confirmButton: "DELETE",
                                            cancelButton: "CANCEL",
                                            post: false
                                        });
                                    </script>

                                </td>
                            </tr>
                            <?php

                        }
                    }
                    ?>


                    </tbody>
                </table>
    </form>

                <div class="clear"></div>
            </div><!-- /.panel-body -->
        </div><!-- /.col-lg-12 -->
    </div><!-- /.row -->

</div> <!-- /.page-wraper -->

</div>
<!-- /#wrapper -->

</body>

</html>