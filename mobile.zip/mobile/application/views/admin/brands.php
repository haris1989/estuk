
<script type="text/javascript" charset="utf-8">
    $(document).ready(function()
    {
        var dontSort = [];
        $('#filterTable thead th').each( function () {
            if ( $(this).hasClass( 'no_sort' )) {
                dontSort.push( { "bSortable": false } );
            } else {
                dontSort.push( null );
            }
        } );

        $('#filterTable').dataTable({"aoColumns": dontSort, "order": [[ 1, "asc" ]]});

    });
</script>
<div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">All Brands <a class="btn btn-primary btn-default" href="<?php echo base_url();?>index.php/admin/Brands/add"><i class="fa fa-edit"></i> Add Brand</a></h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->



    <div class="row">
        <div class="col-lg-12">

            <div class="panel-body nopadding">




                <table id="filterTable" class="table table-bordered">
                    <thead>
                    <tr>
                        <th class="no_sort" align="left">Logo</th>
                        <th align="left">Brand details</th>
                        <th align="left">Phones</th>
                        
                        <th class="no_sort" align="left">Actions</th>
                    </tr>
                    </thead>

                    <tbody>

   <?php
   if(isset($brands)){
   foreach($brands as $brand){?>
                    <tr>
                        <td align="left" valign="top">
                            <img src="<?php echo $brand->image_url;?>" />
                        </td>

                        <td align="left" valign="top">
                            <strong> <?php echo $brand->name; ?> </strong>
                            <div class="clear"></div>

                            <?php if($brand->is_featured==1){?>
                            <i class="fa fa-thumbs-o-up fa-fw"></i> Featured brand
                            <?php }?>
                        </td>

                        <td align="left" valign="top">
                            <?php echo $brand->number_of_phones;?> <i class="fa fa-mobile fa-fw"></i>
                        </td>

                      

                        <td align="left" valign="top">
                            <i class="fa fa-pencil-square-o fa-fw"></i> <a href="<?php echo base_url();?>index.php/admin/Brands/edit/<?php echo $brand->id;?>">Edit brand</a>
                            <div class="clear"></div>

                            <i class="fa fa-trash-o fa-fw"></i> <a class="confirm_<?php echo $brand->id;?>" href="#">Delete brand</a>

                            <script>
                                $(".confirm_<?php echo $brand->id;?>").confirm({
                                    text: "This will delete brand and erase brand name for all this brand phones (you can asign anytime a new brand to all this phones)",
                                    title: "Confirm delete",
                                    confirm: function(button) {
                                        // do something
                                       // alert(<?php echo $brand->id;?>);
                                        location.href = "<?php echo base_url();?>index.php/admin/Brands/destroy/<?php echo $brand->id;?>"
                                    },
                                    cancel: function(button) {
                                        // do something
                                    },
                                    confirmButton: "DELETE",
                                    cancelButton: "CANCEL",
                                    post: false
                                });
                            </script>

                        </td>
                    </tr>
        <?php

   }
   }
   ?>


                    </tbody>
                </table>



                <div class="clear"></div>


            </div><!-- /.panel-body -->
        </div><!-- /.col-lg-12 -->
    </div><!-- /.row -->

</div> <!-- /.page-wraper -->

</div>
<!-- /#wrapper -->

</body>

</html>