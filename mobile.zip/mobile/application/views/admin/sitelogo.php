  <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Website Logo</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->



<?php if($logo){
  foreach($logo as $l){
?>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-bar-chart-o fa-fw"></i> Current logo is:
                </div><!-- /.panel-heading -->

                <div class="panel-body">

                    <div class="col-md-12 nopadding">
                        <a target="_blank" href="<?php echo base_url();?>/img/logo/<?php echo $l->name; ?>"><img style="max-width: 500px; max-height:300px;" src="<?php echo base_url();?>/img/logo/<?php echo $l->name; ?>" border="0" /></a>
                    </div>

                </div><!-- /.panel-body -->
            </div><!-- /.panel -->
        </div><!-- /.col-lg-12 -->
    </div><!-- /.row -->



    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-bar-chart-o fa-fw"></i> Upload a new logo image
                </div><!-- /.panel-heading -->

                <div class="panel-body">

                    <div class="col-md-12 nopadding">
                        <form action="<?php echo base_url();?>index.php/admin/Sitelogos/update" method="post" enctype="multipart/form-data">
                            <label><small>Choose the image to be used as a logo</small></label>
                            <input name="userfile" type="file">
                            <input name="name" type="hidden" value="<?php echo $l->name; ?>">
                            <p class="help-block">Tip: if you have a coloured background, then it is a good ideea to make a transparent logo image!</p>
                            <button type="submit" class="btn btn-primary">Upload image</button>
                        </form>

                    </div>

                </div><!-- /.panel-body -->
            </div><!-- /.panel -->
        </div><!-- /.col-lg-12 -->
    </div><!-- /.row -->
  <?php }}?>

</div><!-- /#page-wrapper -->
</div>
<!-- /#wrapper -->

</body>

</html>