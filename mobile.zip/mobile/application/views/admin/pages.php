
<style>
    .btn a{
        color:white;
        padding:0px;
    }
    .btn-primary{
        color:white;
        margin-left:10px;
    }
</style>



    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Pages</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->




    <div class="row">
        <div class="col-lg-12">

            <div class="panel-body noppageing">


                <a style="cursor:pointer; color:#296BBC; text-decoration:none; font-size:11px;" onclick="showhide('form_page_page');"><strong>CREATE NEW PAGE</strong></a>

                <div id="form_page_page" style="display: none;">
                    <div class="clear"></div>

                    <form action="<?php echo base_url(); ?>index.php/admin/Pages/create" method="post">

                        <div class="form-group">
                            <label>Page title</label>
                            <input class="form-control" name="title" type="text" required/>
                        </div>

                        <div class="form-group">
                            <label>Page content</label>
                            <textarea id="textarea" name="content" cols="6" rows="10" class="form-control"></textarea>
                            <script type="text/javascript">
                                $('#textarea').summernote({
                                    height: 250
                                });
                            </script>
                        </div>

                        <div class="form-group">
                            <label>Page order (only numbers)</label>
                            <input class="form-control" name="page_order" type="number" required/>
                        </div>

                        <div class="form-group">
                            <label>Page active?</label>
                            <select name="is_active" class="form-control">
                                <option value="1" selected="selected">Active</option>
                                <option value="0">Inactive</option>
                            </select>
                        </div>
                       
                        <button type="submit" class="btn btn-primary">Submit Page</button>
                    </form>
                    <div class="clear"></div>
                </div>


                <div class="clear"></div>

                <h3>All pages:</h3>
                <div class="clear"></div>

                 <table class="table table-bordered" id="listings">
                    <tr>
                        <th width="50" align="left" valign="middle">Order</th>
                        <th align="left" valign="middle">Page</th>
                        <th width="160" align="left" valign="middle">Actions</th>
                    </tr>


                    <?php if(isset($pages)){
                        $count=1;

                        if($pageNum){
                            $count=$count+$pageNum;
                        }
                        foreach($pages as $page){
                    ?>
                    <tr>
                        <td align="left" valign="top"><strong><?php echo $page->page_order; ?></strong></td>
                        <td align="left" valign="top">
                            <strong><?php echo $page->title;  ?></strong>
                            <br/>
                            
                            <?php if($page->is_active==1){?>
                            <font color='#339966'>Page active</font>      </td>
                        <?php }
                        else{
                            ?>

                        <font color='red'>Page inactive</font>  </td>
                        <?php } ?>
                        </td>
                        <td align="left" valign="top">
                            <a href="<?php echo base_url();?>index.php/admin/pages/edit/<?php echo $page->id; ?>"><i class="fa fa-pencil fa-fw"></i> Edit page</a>
                            <div class="clear"></div>
                            <a onclick="return confirm('Are you sure?')" href="<?php echo base_url();?>index.php/admin/pages/destroy/<?php echo $page->id; ?>"><i class="fa fa-trash-o fa-fw"></i> Delete Page</a>
                        </td>
                    </tr>
                    <?php
                    $count++;
                        }
                    }
                    ?>

                </table>
              <?php  echo $this->pagination->create_links(); ?>

             



                <div class="clear"></div>

            </div><!-- /.panel-body -->
        </div><!-- /.col-lg-12 -->
    </div><!-- /.row -->


</div> <!-- /.page-wraper -->


</div>
<!-- /#wrapper -->

</body>

</html>