<script>
    $(function() {

        Morris.Bar({
            element: 'morris-bar-chart',
            data: [
                {
                    y: "2016-04-09",
                    a: "0"
                },
                {
                    y: "2016-04-08",
                    a: "0"
                },
                {
                    y: "2016-04-07",
                    a: "0"
                },
                {
                    y: "2016-04-06",
                    a: "0"
                },
                {
                    y: "2016-04-05",
                    a: "0"
                },
                {
                    y: "2016-04-04",
                    a: "0"
                },
                {
                    y: "2016-04-03",
                    a: "0"
                },
                {
                    y: "2016-04-02",
                    a: "0"
                },
                {
                    y: "2016-04-01",
                    a: "0"
                },
                {
                    y: "2016-03-31",
                    a: "0"
                },
                {
                    y: "2016-03-30",
                    a: "0"
                },
                {
                    y: "2016-03-29",
                    a: "0"
                },
                {
                    y: "2016-03-28",
                    a: "0"
                },
                {
                    y: "2016-03-27",
                    a: "0"
                },
            ],
            xkey: 'y',
            ykeys: ['a'],
            labels: ['Phones added'],
            hideHover: 'auto',
            resize: true
        });
    });
</script>

    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Dashboard</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-bar-chart-o fa-fw"></i> Number of phones added (last 14 days)
                </div>
                <!-- /.panel-heading -->
                <div class="panel-body">
                    <div id="morris-bar-chart"></div>
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div>
        <!-- /.col-lg-12 -->

        <div class="col-lg-7">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-bell fa-fw"></i> Notifications
                </div>
                <!-- /.panel-heading -->
                <div class="panel-body">
                    <div class="list-group">
                        <a href="<?php echo base_url();?>index.php/admin/Cellphones" class="list-group-item">
                            <i class="fa fa-unlink fa-fw"></i> Total phones: <?php echo $phones;?>
                        </a>
                        <a href="<?php echo base_url();?>index.php/admin/News" class="list-group-item">
                            <i class="fa fa-unlink fa-fw"></i> Total news: <?php echo $news;?>                                </a>
                        <a href="<?php echo base_url();?>index.php/admin/Reviews" class="list-group-item">
                            <i class="fa fa-unlink fa-fw"></i> Total reviews: <?php echo $reviews;?>
                            </a>
                        <a href="<?php echo base_url();?>index.php/admin/Brands" class="list-group-item">
                            <i class="fa fa-unlink fa-fw"></i> Total brands: <?php echo $brands;?>                                </a>
                         <a href="<?php echo base_url();?>index.php/admin/Plans" class="list-group-item">
                            <i class="fa fa-unlink fa-fw"></i> Total providers: <?php echo $providers;?>
                        </a>

                    </div>
                    <!-- /.list-group -->
                    <a href="<?php echo base_url();?>index.php/admin/Websettings" class="btn btn-default btn-block">Change Website Settings</a>
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div> <!-- /.col-lg-7 -->

        <div class="col-lg-5">

        </div>
        <!-- /.col-lg-5 -->

    </div>
    <!-- /.row -->
</div>
<!-- /#page-wrapper -->



</div>
<!-- /#wrapper -->

</body>

</html>