<div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Add new brand</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->




    <div class="col-lg-6">
        <form action="<?php echo base_url(); ?>index.php/admin/Brands/create " method="post" enctype="multipart/form-data">

            <div class="form-group">
                <label>Brand name</label>
                <input class="form-control" name="name" type="text" value="" />
            </div>


            <div class="form-group">
                <label>Is featured?</label>
                <p class="help-block">Featured brands (important brands) will appear first in brands list!</p>
                <select name="is_featured" class="form-control">
                    <option value="1">Yes</option>
                    <option value="0" selected="selected">No</option>
                </select>
            </div>

            <div class="form-group">
                <label>Upload Logo</label>
                <p class="help-block">Upload brand logo! (optional)</p>
                <input type="url" name="image_url" >
            </div>

            <div class="form-group">
                <button type="submit" class="btn btn-primary">Add brand</button>
            </div>
        </form>
    </div>

    <div class="clear"></div>

    <div class="clear"></div>

</div><!-- /.panel-body -->
</div><!-- /.col-lg-12 -->
</div><!-- /.row -->

</div> <!-- /.page-wraper -->

</div>
<!-- /#wrapper -->

</body>

</html>