
     <?php
    if(isset($pages)) {
        foreach ($pages as $page) {
            ?>
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header"><?php echo $page->title;?> - edit page</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->




    <form action="<?php echo base_url(); ?>index.php/admin/Pages/update" method="post">
       

        <div class="form-group">
            <label>Page title</label>
            <input class="form-control" name="title" type="text" value="<?php echo $page->title; ?>" />
        </div>

        <div class="form-group">
            <strong>Page content</strong><br />
            <textarea id="textarea" name="content" cols="6" rows="10" class="form-control">
                    <?php echo $page->content; ?>
            </textarea>
            <script type="text/javascript">
                $('#textarea').summernote({
                    height: 250
                });
            </script>
        </div>

        <div class="form-group">
            <label>Page order (only numbers)</label>
            <input class="form-control" name="page_order" type="text" value="<?php echo $page->page_order; ?>" />
        </div>

        <div class="form-group">
            <label>Page active</label>
         <select name="is_active" class="form-control">

                    <?php
                    $activeStatus="";
                    $inactiveStatus="";
                    if ($page->is_active == 1){
                        $activeStatus= 'selected="selected"';
                    }
                    else{
                        $inactiveStatus= 'selected="selected"';
                    }
                    ?>

                    <option value="1" <?php echo $activeStatus ?> >Active</option>
                    <option value="0" <?php echo $inactiveStatus ?>>Inactive</option>

                </select>
            </div>
            <?php
        }
    }
        ?>

        <div class="form-group">
            <input type="hidden" name="id" value="<?php echo $page->id;?>" />

        <button type="submit" class="btn btn-primary">Update</button>
        </div>
        </div>

    </form>


    <div class="clear"></div>

    <div class="clear"></div>

</div><!-- /.panel-body -->
</div><!-- /.col-lg-12 -->
</div><!-- /.row -->

</div> <!-- /.page-wraper -->

</div>
<!-- /#wrapper -->

</body>

</html>