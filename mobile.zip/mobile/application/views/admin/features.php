<script type="text/javascript" charset="utf-8">
    $(document).ready(function()
    {
        var dontSort = [];
        $('#filterTable thead th').each( function () {
            if ( $(this).hasClass( 'no_sort' )) {
                dontSort.push( { "bSortable": false } );
            } else {
                dontSort.push( null );
            }
        } );

        $('#filterTable').dataTable({"aoColumns": dontSort, "order": [[ 1, "asc" ]]});

    });
</script>
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Features For 
            <?php 
            foreach($d as $row){
            echo $row->name;

             }?>
            </h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->




    <div class="row">
        <div class="col-lg-12">

            <div class="panel-body noppageing">


                <a style="cursor:pointer; color:#296BBC; text-decoration:none; font-size:11px;" onclick="showhide('form_page_page');"><strong>CREATE NEW FEATURE</strong></a>

                <div id="form_page_page" style="display: none;">
                    <div class="clear"></div>

                    <form action="<?php echo base_url(); ?>index.php/admin/Plans/createPlanFeature" method="post">

                        
                         <div class="form-group">
                            <label>Plan talk</label>
                            <input class="form-control" name="talk" type="text" required/>
                        </div>
                        <div class="form-group">
                            <label>Plan text</label>
                            <input class="form-control" name="text" type="text" required/>
                        </div>
                        <div class="form-group">
                            <label>Plan data</label>
                            <input class="form-control" name="data" type="text" required/>
                        </div>
                        <div class="form-group">
                            <label>Plan price</label>
                            <input class="form-control" name="price" type="text" required/>
                        </div>

                          <div class="form-group">
                            <label>Plan province/state</label>
                            <select name="<?php 
                            if(isset($provider)){
                                $prov_id=null;
                            foreach($provider as $r){
                                $prov_id=$r->id;
                         if($r->country==0){

                            echo "cad_province_id";
                         }
                         else{
                          echo "usa_province_id";  
                         }

                        }

                            }


                            ?>" id="prov" class="form-control">
                            <?php 

                            if(isset($provinceList)){
                                $bool=true;
                                foreach ($provinceList as $province) {
                                    ?>
                                
                   
                    <?php if($bool){?>
                       <option selected="selected"  value="<?php echo $province->id;?>"><?php echo $province->name;?></option>
                       <?php
                       $bool=false;
                       }
                       else{
                        ?>
                       <option  value="<?php echo $province->id;?>"><?php echo $province->name;?></option>

                     

                            <?php }}}?>

                </select>
                        </div>

                        <input type="hidden" name="prov_id" value="<?php echo $prov_id; ?>" >

                        <input type="hidden" name="plan_id" value="<?php echo $id; ?>" >

                        <button type="submit" class="btn btn-primary">Submit Feature</button>
                    </form>
                    <div class="clear"></div>
                </div>


                <div class="clear"></div>

                <h3>All plans:</h3>
                <div class="clear"></div>

                     <table id="filterTable" class="table table-bordered">
                    <thead>
                    <tr>
                        <th class="no_sort" align="left">Num</th>
                        <th align="left">Talk</th>
                        <th align="left">Text</th>
                        <th align="left">Data</th>
                        <th align="left">Province</th>
                        <th align="left">Price</th>
                        
                        <th class="no_sort" align="left">Actions</th>
                    </tr>
                    </thead>

                    <tbody>

   <?php
   if(isset($features)){
       $count=1;
   foreach($features as $feature){?>
                    <tr>
                        <td align="left" valign="top">
                                    <?php echo $count; ?>
                            <div class="clear"></div>
                        </td>

                        <td align="left" valign="top">
                            <?php echo $feature->talk; ?>
                            <div class="clear"></div>
                        </td>

                        <td align="left" valign="top">
                              <?php echo $feature->text; ?>
                            <div class="clear"></div>
                        </td>

                        <td align="center" valign="top">
                             <?php echo $feature->data; ?>
                            <div class="clear"></div>
                        </td>

                        <td align="center" valign="top">
                             <?php
                             if($feature->cad_province_id){
                                echo $feature->cad_name; 
                             }
                             else{
                                echo $feature->usa_name; 
                             }
                              

                              ?>
                            <div class="clear"></div>
                        </td>

                        <td align="center" valign="top">
                             <?php echo $feature->price; ?>
                            <div class="clear"></div>
                        </td>

                      

                        <td align="left" valign="top">

                            <i class="fa fa-trash-o fa-fw"></i> <a class="confirm_<?php echo $feature->id;?>" href="#">Delete plan feature</a>

                            <script>
                                $(".confirm_<?php echo $feature->id;?>").confirm({
                                    text: "This will delete plan and erase feature",
                                    title: "Confirm delete",
                                    confirm: function(button) {
                                        // do something
                                       // alert(<?php echo $feature->id;?>);
                                        location.href = "<?php echo base_url();?>index.php/admin/Plans/destroyFeature/<?php echo $feature->id;?>/<?php echo $id;?>/<?php echo $provider_id;?>"
                                    },
                                    cancel: function(button) {
                                        // do something
                                    },
                                    confirmButton: "DELETE",
                                    cancelButton: "CANCEL",
                                    post: false
                                });
                            </script>
                             

                        </td>
                    </tr>
        <?php
$count++;
   }
   }
   ?>


                    </tbody>
                </table>


                <div class="clear"></div>

            </div><!-- /.panel-body -->
        </div><!-- /.col-lg-12 -->
    </div><!-- /.row -->


</div> <!-- /.page-wraper -->


</div>
<!-- /#wrapper -->

</body>

</html>