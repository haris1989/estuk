    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Add New Review</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->




    <div class="col-lg-6">
        <form action="<?php echo base_url(); ?>index.php/admin/Reviews/create" method="post" enctype="multipart/form-data">

                        <div class="form-group">
                            <label>Review title</label>
                            <input name="title" type="text" required/>
                        </div>
                         <div class="form-group">
                        <label>Description(Short summary about phone)</label><br />
                        <textarea id="textarea" name="description" cols="6" rows="10" class="form-control"></textarea>
                        <script type="text/javascript">
                            $('#textarea').summernote({
                                height: 250
                            });
                        </script>
                    </div>

                          <div class="form-group">
                            <label>Select review type</label>
                            <br/><br/>
                            <label>Phones</label>&nbsp;
                            <input  name="type" type="radio" onclick="

                               document.getElementById('phone').style.display='block'
                               document.getElementById('plan').style.display='none'
                                

                               " value="1" checked>   
                            &nbsp;&nbsp;or&nbsp;&nbsp;
                            <label>Plans</label>&nbsp;
                               <input   name="type" type="radio"  onclick="

                               document.getElementById('plan').style.display='block'
                               document.getElementById('phone').style.display='none'
                               

                               " value="0">  
                        </div>

                               <div class="form-group" id="plan" style="display:none;">
                <label>Select plan</label>
                <select name="provider_id" id="prov" class="form-control">
                   <?php
                   if(isset($providers)){
                       $bool=true;
                   foreach($providers as $provider){
                   ?>
                    <?php if($bool){?>
                       <option selected="selected"  value="<?php echo $provider->id;?>"><?php echo $provider->name;?></option>
                       <?php
                       $bool=false;
                       }
                       else{?>
                       <option  value="<?php echo $phone->id;?>"><?php echo $provider->name;?></option>

                    <?php
                       }
                       }
                   }?>

                </select>
            </div>

                           <div class="form-group" id="phone">
                <label>Select phone</label>
                <select name="phone_id" id="ph" class="form-control">
                   <?php
                   if(isset($phones)){
                       $bool=true;
                   foreach($phones as $phone){
                   ?>
                    <?php if($bool){?>
                       <option selected="selected"  value="<?php echo $phone->id;?>"><?php echo $phone->name;?></option>
                       <?php
                       $bool=false;
                       }
                       else{?>
                       <option  value="<?php echo $phone->id;?>"><?php echo $phone->name;?></option>

                    <?php
                       }
                       }
                   }?>

                </select>
            </div>

                           <div class="form-group">
                <label>Upload Review Banner Image</label>
                <p class="help-block">.png, .jpg, .jpeg, .gif only! The script will create 2 images (big image and thumb image). We recomend to upload a big image (min. 600px width)</p>
                <input name="userfile" type="file">
            </div>

                        <div class="form-group">
                            <label>Reviews Keywords</label>
                            <input class="form-control" name="keywords" type="text" />
                        </div>

                        <div class="form-group">
                            <label>Reviews active?</label>
                            <select name="is_active" class="form-control">
                                <option value="1" selected="selected">Active</option>
                                <option value="0">Inactive</option>
                            </select>
                        </div>

                        <button type="submit" class="btn btn-primary">Submit Review</button>
                    </form>
    </div>

    <div class="clear"></div>

    <div class="clear"></div>

</div><!-- /.panel-body -->
</div><!-- /.col-lg-12 -->
</div><!-- /.row -->

</div> <!-- /.page-wraper -->

</div>
<!-- /#wrapper -->

</body>

</html>