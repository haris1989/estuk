
<style>
    .btn a{
        color:white;
        padding:0px;
    }
    .btn-primary{
        color:white;
        margin-left:10px;
    }
</style>
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Ads</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->




    <div class="row">
        <div class="col-lg-12">

            <div class="panel-body nopadding">


                <a style="cursor:pointer; color:#296BBC; text-decoration:none; font-size:11px;" onclick="showhide('form_add_page');"><strong>CREATE NEW AD</strong></a>

                <div id="form_add_page" style="display: none;">
                    <div class="clear"></div>

                    <form action="<?php echo base_url();?>index.php/admin/Adds/create" method="post">

                        <div class="form-group">
                            <label>Zone description</label>
                            <input class="form-control" name="zone_name" type="text" required />
                        </div>

                        <div class="form-group">
                            <label>HTML Code</label>
                            <textarea id="textarea" name="add_html_code" cols="6" rows="10" class="form-control" required></textarea>
                        </div>

                        <div class="form-group">
                            <label>Ad active?</label>
                            <select name="status" class="form-control">
                                <option value="1" selected="selected">Active</option>
                                <option value="0">Inactive</option>
                            </select>
                        </div>

                        <button type="submit" class="btn btn-primary">Add</button>
                    </form>
                    <div class="clear"></div>
                </div>

                <div class="clear"></div>


                To add ads, input follow code in your template file (php file) in the place you want to show the ads:
                <br /><br />


				<pre>
                	<code>
                        &lt;?<br />                    $ads_zone_id = 1; // inpyt here the ID of the ad
                        $sql_ads = mysql_query("SELECT ad_content FROM ads WHERE zone_id = '$ads_zone_id' AND active = '1' LIMIT 1");
                        $row = mysql_fetch_row($sql_ads);
                        $ad_content = $row[0];
                        echo html_entity_decode($ad_content);?&gt;                    </code>

                </pre>


                <div class="clear"></div>

                <h3>All ads:</h3>
                <div class="clear"></div>

                <table class="table table-bordered" id="listings">
                    <tr>
                        <th width="50" align="left" valign="middle">ID</th>
                        <th align="left" valign="middle">Ad code</th>
                        <th width="160" align="left" valign="middle">Actions</th>
                    </tr>


                    <?php if($adds){
                        $count=1;

                        if($pageNum){
                            $count=$count+$pageNum;
                        }
                        foreach($adds as $add){
                    ?>
                    <tr>
                        <td align="left" valign="top"><strong><?php echo $count; ?></strong></td>
                        <td align="left" valign="top">
                            <strong><?php echo $add->zone_name;  ?></strong>
                            <br/>
                            <?php echo htmlspecialchars($add->add_html_code);  ?>
                            <br>
                            <?php if($add->status==1){?>
                            <font color='#339966'>Ad active</font>      </td>
                        <?php }
                        else{
                            ?>

                        <font color='red'>Ad inactive</font>      </td>
                        <?php } ?>
                        </td>
                        <td align="left" valign="top">
                            <a href="<?php echo base_url();?>index.php/admin/Adds/edit/<?php echo $add->id; ?>"><i class="fa fa-pencil fa-fw"></i> Edit ads</a>
                            <div class="clear"></div>
                            <a onclick="return confirm('Are you sure?')" href="<?php echo base_url();?>index.php/admin/Adds/destroy/<?php echo $add->id; ?>"><i class="fa fa-trash-o fa-fw"></i> Delete ads</a>
                        </td>
                    </tr>
                    <?php
                    $count++;
                        }
                    }
                    ?>

                </table>
              <?php  echo $this->pagination->create_links(); ?>
                <div class="clear"></div>

            </div><!-- /.panel-body -->
        </div><!-- /.col-lg-12 -->
    </div><!-- /.row -->


</div> <!-- /.page-wraper -->


</div>
<!-- /#wrapper -->

</body>

</html>