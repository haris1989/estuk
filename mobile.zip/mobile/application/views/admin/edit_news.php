
    <?php
    if(isset($news)) {
        foreach ($news as $new) {
            ?>
    <div class="row">
        <div class="col-lg-12">
            <h1 class="new-header"><?php echo $new->title; ?> - edit news</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->




    <form action="<?php echo base_url(); ?>index.php/admin/news/update" method="post" enctype="multipart/form-data">
       

        <div class="form-group">
            <label>new title</label>
            <input class="form-control" name="title" type="text" value="<?php echo $new->title; ?>" />
        </div>

        <div class="form-group">
            <strong>new content</strong><br />
            <textarea id="textarea" name="content" cols="6" rows="10" class="form-control">
                    <?php echo $new->content; ?>
            </textarea>
            <script type="text/javascript">
                $('#textarea').summernote({
                    height: 250
                });
            </script>
        </div>
         
         <div class="form-group">
          <label>News Banner Image Url</label>
            <br>
            <div class="row" style="text-align:center;">
            <img src="<?php echo base_url();?>/img/news/thumb/<?php echo $new->banner; ?>" class=".img-thumbnail" style="height:10%;width:10%;">
            </div>
            <br>
                <label>Upload cell phone image</label>
                <p class="help-block">.png, .jpg, .jpeg, .gif only! The script will create 2 images (big image and thumb image). We recomend to upload a big image (min. 600px width)</p>
                <input name="userfile" type="file">
            </div>

        <div class="form-group">
            <label>News Keywords</label>
            <input class="form-control" name="keywords" type="text" value="<?php echo $new->keywords; ?>" />
        </div>

        <div class="form-group">
            <label>new active</label>
         <select name="is_active" class="form-control">

                    <?php
                    $activeStatus="";
                    $inactiveStatus="";
                    if ($new->is_active == 1){
                        $activeStatus= 'selected="selected"';
                    }
                    else{
                        $inactiveStatus= 'selected="selected"';
                    }
                    ?>

                    <option value="1" <?php echo $activeStatus ?> >Active</option>
                    <option value="0" <?php echo $inactiveStatus ?>>Inactive</option>

                </select>
            </div>
            <?php
        }
    }
        ?>

        <div class="form-group">
            <input type="hidden" name="old_image" value="<?php echo $new->banner;?>" />
             <input type="hidden" name="id" value="<?php echo $new->id;?>" />

        <button type="submit" class="btn btn-primary">Update</button>
        </div>
        </div>

    </form>


    <div class="clear"></div>

    <div class="clear"></div>

</div><!-- /.panel-body -->
</div><!-- /.col-lg-12 -->
</div><!-- /.row -->

</div> <!-- /.new-wraper -->

</div>
<!-- /#wrapper -->

</body>

</html>