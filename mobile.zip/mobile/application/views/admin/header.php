<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="MXScripts.com" />

    <title>Admin zone - http://mobile.mxscripts.com</title>

    <!-- Core CSS -->
    <link href="<?php echo base_url(); ?>css/bootstrap.min.css" rel="stylesheet">
    <link href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>css/admin.css" rel="stylesheet">

    <!-- Page-Level Plugin CSS -->
    <link href="<?php echo base_url(); ?>css/plugins/morris/morris-0.4.3.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>css/plugins/timeline/timeline.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>css/dataTables.bootstrap.css" rel="stylesheet">

    <!-- Core Scripts - Include with every page -->
    <script src="<?php echo base_url(); ?>js/jquery-1.10.2.js"></script>
    <script src="<?php echo base_url(); ?>js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>js/plugins/metisMenu/jquery.metisMenu.js"></script>

    <!-- Page-Level Plugin Scripts - Dashboard -->
    <script src="<?php echo base_url(); ?>js/plugins/morris/raphael-2.1.0.min.js"></script>
    <script src="<?php echo base_url(); ?>js/plugins/morris/morris.js"></script>

    <!-- Admin Scripts - Include with every page -->
    <script src="<?php echo base_url(); ?>js/admin.js"></script>
    <script src="<?php echo base_url(); ?>js/showhide.js"></script>
    <script src="<?php echo base_url(); ?>js/jeditable.js"></script>
    <script src="<?php echo base_url(); ?>js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>js/dataTables.bootstrap.js"></script>
    <script src="<?php echo base_url(); ?>js/jquery.confirm.js"></script>
    <script src="<?php echo base_url(); ?>js/validation.js"></script>

    <!-- TEXT Editor -->
    <script src="<?php echo base_url(); ?>js/summernote.min.js"></script>
    <link href="<?php echo base_url(); ?>css/summernote.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>css/summernote-bs3.css" rel="stylesheet">



<body>

<div id="wrapper">

    <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="<?php echo base_url();?>/index.php/admin/Accounts">Welcome, admin.</a>
        </div>
        <!-- /.navbar-header -->

        <ul class="nav navbar-top-links navbar-right">

            <li class="dropdown"><a target="_blank" href="<?php echo base_url();?>index.php/Home/selectCountry"><i class="fa fa-laptop fa-fw"></i> My Website</a></li>
            <li class="dropdown"><a href="<?php echo base_url();?>index.php/admin/Accounts/logout"><i class="fa fa-sign-out fa-fw"></i> Logout</a></li>
        </ul>
        <!-- /.navbar-top-links -->

    </nav>
    <!-- /.navbar-static-top -->

    <nav class="navbar-default navbar-static-side" role="navigation">
        <div class="sidebar-collapse">
            <ul class="nav" id="side-menu">

                <li>
                    <a href="<?php echo base_url();?>index.php/admin/Accounts"><i class="fa fa-bars fa-fw"></i> Dashboard</a>
                </li>

                <li>
                    <a href="<?php echo base_url();?>index.php/admin/Websettings"><i class="fa fa-wrench fa-fw"></i> General Settings<span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li>
                            <a href="<?php echo base_url();?>index.php/admin/Websettings">Website Settings</a>
                        </li>
                        <li>
                            <a href="<?php echo base_url();?>index.php/admin/Adds">Ads Management</a>
                        </li>
                        <li>
                            <a href="<?php echo base_url();?>index.php/admin/Sitelogos">Site Logo</a>
                        </li>

                    </ul>
                    <!-- /.nav-second-level -->
                </li>


                <li>
                    <a href="#"><i class="fa fa-folder-o fa-fw"></i> Brands<span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li>
                            <a href="<?php echo base_url();?>index.php/admin/Brands">All brands</a>
                        </li>
                        <li>
                            <a href="<?php echo base_url();?>index.php/admin/Brands/add">Add brand</a>
                        </li>
                        <li>
                            <a href="<?php echo base_url();?>index.php/admin/Brands/featuredBrands">Featured brands</a>
                        </li>
                    </ul>
                    <!-- /.nav-second-level -->
                </li>

                <li>
                    <a href="#"><i class="fa fa-tablet fa-fw"></i> Cell Phones<span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li>
                            <a href="<?php echo base_url();?>index.php/admin/Cellphones">All Cell Phones</a>
                        </li>
                        <li>
                            <a href="<?php echo base_url();?>index.php/admin/Cellphones/add">Add Cell Phone</a>
                        </li>

                    </ul>
                    <!-- /.nav-second-level -->
                </li>

                <li>
                    <a href="<?php echo base_url();?>index.php/admin/Plans"><i class="fa fa-folder-o fa-fw"></i> Plans</a>
                </li>

                <li>
                    <a href="<?php echo base_url();?>index.php/admin/Comments"><i class="fa fa-comments-o fa-fw"></i> Comments</a>
                </li>

                <li>
                    <a href="<?php echo base_url();?>index.php/admin/News"><i class="fa fa-edit fa-fw"></i> News</a>
                </li>

                <li>
                    <a href="<?php echo base_url();?>index.php/admin/Reviews"><i class="fa fa-edit fa-fw"></i> Reviews</a>
                </li>

                             <li>
                    <a href="<?php echo base_url();?>index.php/admin/Pages"><i class="fa fa-files-o fa-fw"></i> Pages</a>
                </li>


            </ul>
            <!-- /#side-menu -->
        </div>
        <!-- /.sidebar-collapse -->
    </nav>
    <!-- /.navbar-static-side -->
    <div id="page-wrapper">
<?php if(isset($alert)) {?>
    <div class="alert alert-danger" role="alert"> <?php echo $alert; ?></div>
<?php }?>
<?php if(isset($notice)) {?>
    <div class="alert alert-success" role="alert"><?php echo $notice; ?> </div>
<?php } ?>
