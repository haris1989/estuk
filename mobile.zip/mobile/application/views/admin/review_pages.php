<script type="text/javascript" charset="utf-8">
    $(document).ready(function()
    {
        var dontSort = [];
        $('#filterTable thead th').each( function () {
            if ( $(this).hasClass( 'no_sort' )) {
                dontSort.push( { "bSortable": false } );
            } else {
                dontSort.push( null );
            }
        } );

        $('#filterTable').dataTable({"aoColumns": dontSort, "order": [[ 1, "asc" ]]});

    });
</script>

    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Pages For 
            <?php foreach($d as $row){
            echo $row->title;
             }?>
            </h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->




    <div class="row">
        <div class="col-lg-12">

            <div class="panel-body noppageing">


                <a style="cursor:pointer; color:#296BBC; text-decoration:none; font-size:11px;" onclick="showhide('form_page_page');"><strong>CREATE NEW PAGE</strong></a>

                <div id="form_page_page" style="display: none;">
                    <div class="clear"></div>

                    <form action="<?php echo base_url(); ?>index.php/admin/Reviews/createPage" method="post">

                        <div class="form-group">
                            <label>Page title</label>
                            <input class="form-control" name="title" type="text" required/>
                        </div>

                        <div class="form-group">
                            <label>Page content</label>
                            <textarea id="textarea" name="content" cols="6" rows="10" class="form-control"></textarea>
                            <script type="text/javascript">
                                $('#textarea').summernote({
                                    height: 250
                                });
                            </script>
                        </div>

                        <div class="form-group">
                            <label>Page order (only numbers)</label>
                            <input class="form-control" name="page_order" type="number" required/>
                        </div>

                        <div class="form-group">
                            <label>Page active?</label>
                            <select name="is_active" class="form-control">
                                <option value="1" selected="selected">Active</option>
                                <option value="0">Inactive</option>
                            </select>
                        </div>
                             <input type="hidden" name="review_id" value="<?php echo $id; ?>" >

                        <button type="submit" class="btn btn-primary">Submit Page</button>
                    </form>
                    <div class="clear"></div>
                </div>


                <div class="clear"></div>

                <h3>All pages:</h3>
                <div class="clear"></div>

                    <table id="filterTable" class="table table-bordered">
                    <thead>
                    <tr>
                        <th  width="50" align="left" valign="middle">Order</th>
                        <th class="no_sort" align="left" valign="middle">Page</th>
                        <th class="no_sort"  width="160" align="left" valign="middle">Actions</th>
                    </tr>
                    </thead>
                     <tbody>

                    <?php if(isset($pages)){
                        $count=1;

                        
                        foreach($pages as $page){
                    ?>
                    <tr>
                        <td align="left" valign="top"><strong><?php echo $page->page_order; ?></strong></td>
                        <td align="left" valign="top">
                            <strong><?php echo $page->title;  ?></strong>
                            <br/>
                            
                            <?php if($page->is_active==1){?>
                            <font color='#339966'>Page active</font>      </td>
                        <?php }
                        else{
                            ?>

                        <font color='red'>Page inactive</font>      </td>
                        <?php } ?>
                        </td>
                        <td align="left" valign="top">
                            <a href="<?php echo base_url();?>index.php/admin/Reviews/editPage/<?php echo $page->id; ?>"><i class="fa fa-pencil fa-fw"></i> Edit Page</a>
                            <div class="clear"></div>
                            <a onclick="return confirm('Are you sure?')" href="<?php echo base_url();?>index.php/admin/Reviews/destroyPage/<?php echo $page->id; ?>/<?php echo $page->review_id; ?>"><i class="fa fa-trash-o fa-fw"></i> Delete Page</a>
                        </td>
                    </tr>
                    <?php
                    $count++;
                        }
                    }
                    ?>
                  </tbody>
                </table>

                <div class="clear"></div>

            </div><!-- /.panel-body -->
        </div><!-- /.col-lg-12 -->
    </div><!-- /.row -->


</div> <!-- /.page-wraper -->


</div>
<!-- /#wrapper -->

</body>

</html>