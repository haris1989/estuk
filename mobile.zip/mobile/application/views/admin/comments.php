<script type="text/javascript" charset="utf-8">
    $(document).ready(function()
    {
        var dontSort = [];
        $('#filterTable thead th').each( function () {
            if ( $(this).hasClass( 'no_sort' )) {
                dontSort.push( { "bSortable": false } );
            } else {
                dontSort.push( null );
            }
        } );

        $('#filterTable').dataTable({"aoColumns": dontSort, "order": [[ 1, "asc" ]]});

    });
</script>
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Comments</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->


    <div class="row">
        <div class="col-lg-12">

            <div class="panel-body nopadding">

                <table id="filterTable" class="table table-bordered">
                    <thead>
                    <tr>
                        <th align="left">Comment #</th>
                        <th align="left" >About</th>
                        <th align="left" class="no_sort">User name</th>
                        <th align="left" class="no_sort">User website</th>
                        <th align="left" class="no_sort">User Comment</th>
                        <th class="no_sort" align="left">Actions</th>
                    </tr>
                    </thead>

                    <tbody>

   <?php
   if(isset($comments)){
    $counter=1;
   foreach($comments as $comment){
    ?>

                    <tr>
                        <td align="left" valign="top">
                            <?php echo $counter++;?>
                        </td>

                        <td align="left" valign="top">
                            <strong> <?php 
                                    if($comment->phone_id!=null){

                                        echo "Phone";
                                    }
                                    else if($comment->review_id!=null){
                                            echo "Review";
                                    }
                                    else if($comment->news_id!=null){
                                        echo "News";

                                    }
                                    else if($comment->provider_id!=null){
                                            echo "Plan";
                                    }


                             ?> </strong>
                            <div class="clear"></div>       
                        </td>

                        <td align="left" valign="top">
                         <strong> <?php echo $comment->name; ?> </strong>
                        </td>

                        <td align="left" valign="top">
                           <strong> <?php echo $comment->website; ?> </strong>
                        </td>
                         <td align="left" valign="top" style="width:35%;">
                           <strong> <?php echo $comment->comment; ?> </strong>
                        </td>

                        <td align="left" valign="top">
                        

                            <i class="fa fa-trash-o fa-fw"></i> <a class="confirm_<?php echo $comment->id;?>" href="#">Delete comment</a>

                            <script>
                                $(".confirm_<?php echo $comment->id;?>").confirm({
                                    text: "This will delete comment and erase comment name for all this comment phones (you can asign anytime a new comment to all this phones)",
                                    title: "Confirm delete",
                                    confirm: function(button) {
                                        // do something
                                       // alert(<?php echo $comment->id;?>);
                                        location.href = "<?php echo base_url();?>index.php/admin/comments/destroy/<?php echo $comment->id;?>"
                                    },
                                    cancel: function(button) {
                                        // do something
                                    },
                                    confirmButton: "DELETE",
                                    cancelButton: "CANCEL",
                                    post: false
                                });
                            </script>

                        </td>
                    </tr>
        <?php

   }
   }
   ?>


                    </tbody>
                </table>


                <div class="clear"></div>

            </div><!-- /.panel-body -->
        </div><!-- /.col-lg-12 -->
    </div><!-- /.row -->


</div> <!-- /.page-wraper -->

</div>
<!-- /#wrapper -->

</body>

</html>