<script type="text/javascript" charset="utf-8">
    $(document).ready(function()
    {
        var dontSort = [];
        $('#filterTable thead th').each( function () {
            if ( $(this).hasClass( 'no_sort' )) {
                dontSort.push( { "bSortable": false } );
            } else {
                dontSort.push( null );
            }
        } );

        $('#filterTable').dataTable({"aoColumns": dontSort, "order": [[ 1, "asc" ]]});

    });
</script>

    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Plans For 
            <?php foreach($d as $row){
            echo $row->name;
             }?>
            </h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->




    <div class="row">
        <div class="col-lg-12">

            <div class="panel-body noppageing">


                <a style="cursor:pointer; color:#296BBC; text-decoration:none; font-size:11px;" onclick="showhide('form_page_page');"><strong>CREATE NEW PLAN</strong></a>

                <div id="form_page_page" style="display: none;">
                    <div class="clear"></div>

                    <form action="<?php echo base_url(); ?>index.php/admin/Plans/createPlan" method="post">

                        <div class="form-group">
                            <label>Plan title</label>
                            <input class="form-control" name="name" type="text" required/>
                        </div>
                        <!-- <div class="form-group">
                            <label>Plan talk</label>
                            <input class="form-control" name="talk" type="text" required/>
                        </div>
                        <div class="form-group">
                            <label>Plan text</label>
                            <input class="form-control" name="text" type="text" required/>
                        </div>
                        <div class="form-group">
                            <label>Plan data</label>
                            <input class="form-control" name="data" type="text" required/>
                        </div>
                        <div class="form-group">
                            <label>Plan price</label>
                            <input class="form-control" name="price" type="text" required/>
                        </div>-->


                        <input type="hidden" name="provider_id" value="<?php echo $id; ?>" >

                        <button type="submit" class="btn btn-primary">Submit Plan</button>
                    </form>
                    <div class="clear"></div>
                </div>


                <div class="clear"></div>

                <h3>All plans:</h3>
                <div class="clear"></div>

                    <table id="filterTable" class="table table-bordered">
                    <thead>
                    <tr>
                        <th  width="50" align="left" valign="middle">Num</th>
                        <th class="no_sort" align="left" valign="middle">Plan Title</th>
                        <th class="no_sort" align="left" valign="middle">Number of plan features</th>
                        <th class="no_sort"  width="160" align="left" valign="middle">Actions</th>
                    </tr>
                    </thead>
                     <tbody>

                    <?php if(isset($plans)){
                        $count=1;

                        
                        foreach($plans as $plan){
                    ?>
                    <tr>
                        <td align="left" valign="top"><strong><?php echo $count; ?></strong></td>
                        <td align="left" valign="top">
                            <strong><?php echo $plan->name;  ?></strong>
                        </td>
                        <td align="center" valign="top">
                            <strong><?php echo $plan->number_of_features;  ?></strong>
                        </td>
                      <!--  <td align="left" valign="top">
                            <strong><?php echo $plan->talk;  ?></strong>
                        </td>
                        <td align="left" valign="top">
                            <strong><?php echo $plan->text;  ?></strong>
                        </td>
                        <td align="left" valign="top">
                            <strong><?php echo $plan->data;  ?></strong>
                        </td>
                        <td align="left" valign="top">
                            <strong><?php echo $plan->price;  ?></strong>
                        </td>-->
                        <td align="left" valign="top">
                                                    <div class="clear"></div>

                            <i class="fa fa-pencil-square-o fa-fw"></i> <a class="confirm_<?php echo $plan->id;?>" href="#">Edit plan</a>

                            <script>
                                $(".confirm_<?php echo $plan->id;?>").confirm({
                                    text: "<strong>Update plan title</strong><form id='form_up' action='<?php echo base_url();?>index.php/admin/Plans/updatePlan' method='POST'> <br><br><input type='hidden' name='provider_id' value='<?php echo $id; ?>' ><input type='hidden' name='id' value='<?php echo $plan->id;?>'><input style='width:100%;' type='text' name='name' value='<?php echo $plan->name;  ?>' required/></form>",
                                    title: "Update",
                                    confirm: function(button) {
                                        // do something
                                       // alert(<?php echo $plan->id;?>);
                                        //location.href = "<?php echo base_url();?>index.php/admin/Plans/updatePlan/<?php echo $plan->id;?>"
                                        
                                        $( "#form_up" ).submit();
                                    },
                                    cancel: function(button) {
                                        // do something
                                    },
                                    confirmButton: "UPDATE",
                                    cancelButton: "CANCEL",
                                    post: true
                                });
                            </script>
                            <div class="clear"></div>
                            <a onclick="return confirm('Are you sure?')" href="<?php echo base_url();?>index.php/admin/Plans/destroyPlan/<?php echo $plan->id; ?>/<?php echo $plan->provider_id; ?>"><i class="fa fa-trash-o fa-fw"></i> Delete Plan</a>
                            <div class="clear"></div>
                             <?php if($plan->number_of_features > 0){?>
                                <i class="fa fa-eye fa-fw"></i> <a class="confirm_<?php echo $plan->id;?>" href="<?php echo base_url();?>index.php/admin/Plans/planFeatures/<?php echo $plan->id;?>/<?php echo $row->id;?>">Show all features</a>
                                <?php }
                                else{?>
                                <i class="fa fa-plus fa-fw"></i> <a class="confirm_<?php echo $plan->id;?>" href="<?php echo base_url();?>index.php/admin/Plans/planFeatures/<?php echo $plan->id;?>">Add Feature</a>
                                 <div class="clear"></div>
                                 <?php } ?>
                        </td>
                    </tr>
                    <?php
                    $count++;
                        }
                    }
                    ?>
                  </tbody>
                </table>

                <div class="clear"></div>

            </div><!-- /.panel-body -->
        </div><!-- /.col-lg-12 -->
    </div><!-- /.row -->


</div> <!-- /.page-wraper -->


</div>
<!-- /#wrapper -->

</body>

</html>