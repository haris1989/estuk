<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="MXScripts.com" />

    <title>Admin zone</title>

    <!-- Core CSS -->
    <link href="<?php echo base_url(); ?>css/bootstrap.min.css" rel="stylesheet">
    <link href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>css/admin.css" rel="stylesheet">

    <!-- Page-Level Plugin CSS -->
    <link href="<?php echo base_url(); ?>css/plugins/morris/morris-0.4.3.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>css/plugins/timeline/timeline.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>css/dataTables.bootstrap.css" rel="stylesheet">

    <!-- Core Scripts - Include with every page -->
    <script src="<?php echo base_url(); ?>js/jquery-1.10.2.js"></script>
    <script src="<?php echo base_url(); ?>js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>js/plugins/metisMenu/jquery.metisMenu.js"></script>

    <!-- Page-Level Plugin Scripts - Dashboard -->
    <script src="<?php echo base_url(); ?>js/plugins/morris/raphael-2.1.0.min.js"></script>
    <script src="<?php echo base_url(); ?>js/plugins/morris/morris.js"></script>

    <!-- Admin Scripts - Include with every page -->
    <script src="<?php echo base_url(); ?>js/admin.js"></script>
    <script src="<?php echo base_url(); ?>js/showhide.js"></script>
    <script src="<?php echo base_url(); ?>js/jeditable.js"></script>
    <script src="<?php echo base_url(); ?>js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>js/dataTables.bootstrap.js"></script>
    <script src="<?php echo base_url(); ?>js/jquery.confirm.js"></script>
    <script src="<?php echo base_url(); ?>js/validation.js"></script>

    <!-- TEXT Editor -->
    <script src="<?php echo base_url(); ?>js/summernote.min.js"></script>
    <link href="<?php echo base_url(); ?>css/summernote.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>css/summernote-bs3.css" rel="stylesheet">



<body>

<div id="wrapper">

        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Hello, admin. Please Sign In</h3>
                    </div>
                    <div class="panel-body">
                    	                        <form role="form" action="<?php echo base_url(); ?>index.php/admin/Accounts/loginCheck" method="POST">
                            <fieldset>
                                <div class="input-group">
	                                <span class="input-group-addon">@</span>
                                    <input class="form-control" placeholder="E-mail" name="email" type="email" autofocus>
                                </div>
                                <div class="input-group">
	                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                    <input class="form-control" placeholder="Password" name="password" type="password" value="">
                                </div>
                                <div class="checkbox">
                                    <label>
                                        <input name="remember" type="checkbox" value="Remember Me">Remember Me
                                    </label>
                                </div>
                                <input type="submit" class="btn btn-primary btn-lg btn-block" value="Login" />
                            </fieldset>
                        </form>

                        <div align="center" style="margin-top:20px;">
                                                &copy; 2007 - 2016
                                                </div>   
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Core Scripts -->
    <script src="../js/jquery-1.10.2.js"></script>
    <script src="../js/bootstrap.min.js"></script>

</body>

</html>