<script>
  function rep(k){
        k.value = parseFloat(k.value.replace(/,/g, ""))
            .toFixed(2)
            .toString()
            .replace(/\B(?=(\d{3})+(?!\d))/g, ",");

        document.getElementById("display").value = k.value.replace(/,/g, "")

      chg.innerHTML="$ "+k.value.toString();

    }

     function rep2(r){
        r.value = parseFloat(r.value.replace(/,/g, ""))
            .toFixed(2)
            .toString()
            .replace(/\B(?=(\d{3})+(?!\d))/g, ",");

        document.getElementById("display2").value = r.value.replace(/,/g, "")

      chgn.innerHTML="$ "+r.value.toString();

    }

</script>
<?php if(isset($phonedetail)){
    foreach($phonedetail as $ph){
?>
<div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Prices for <?php echo $ph->brand_name;?> <?php echo $ph->name;?></h1>
            <div style="color:#669966; margin-bottom:20px;"><i class="fa fa-info-circle"></i> <strong>INFO:</strong> Main price is used to compare phones by price.</div>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->

    <div class="col-lg-5 nopadding">
        <form action="<?php echo base_url(); ?>index.php/admin/Cellphones/update" method="post">
            <div class="form-group">
            
                <label>Input US price (in Dollars)</label>
                <p class="help-block">WITHOUT currency or characters. ONY numbers and dots/comma.<br /> Example: 20,947 or 20947 or 14775.99</p>
                <?php if($ph->price > 0){?>
                <input class="form-control" type="text" id="number" onblur="rep(this)"  value="<?php echo number_format($ph->price);?>.00">
                <br>
                <input type="hidden" id="display" name="price" value="<?php echo $ph->price;?>">
                <?php }
                else{
                ?>
                <input class="form-control" type="text" name="price" id="number" value="NaN" onblur="rep(this)" >
                <br>


                <?php }?>
            </div>

            <div class="form-group">
                <input type="hidden" name="id" value="<?php echo $id?>" />
                <button type="submit" class="btn btn-primary">Edit US price</button>
            </div>
        </form>
    </div>

    <div class="col-lg-7">
        Price displayed: <br />
    <?php if($ph->price > 0){?>
        <h4><b><p id="chg">$ <?php echo number_format($ph->price);?>.00</p></b></h4>
        <?php }
                else{
                ?>
        <h4><b><p id="chg">$ 0</p></b></h4>
                <?php }?>

    </div>


    <div class="clear"></div>




    <div class="clear"></div>




<div class="row">
<div class="col-lg-5 ">
        <form action="<?php echo base_url(); ?>index.php/admin/Cellphones/update" method="post">
            <div class="form-group">
             
                <label>Input Canadian price (in Dollars)</label>
                <p class="help-block">WITHOUT currency or characters. ONY numbers and dots/comma.<br /> Example: 20,947 or 20947 or 14775.99</p>
                <?php if($ph->price2 > 0){?>

                <input class="form-control" type="text" id="number" onblur="rep2(this)"  value="<?php if($ph->price2!=0){echo number_format($ph->price2);}else{echo "NaN";}?>" >

                <br>
                <input type="hidden" id="display2" name="price2" value="<?php echo $ph->price2;?>">
                <?php }
                else{
                ?>
                <input class="form-control" type="text" name="price2" id="number2" value="<?php echo 'NaN';?>" onblur="rep2(this)" >
                <br>
                <?php }?>
            </div>

            <div class="form-group">
                <input type="hidden" name="id" value="<?php echo $id?>" />
                <button type="submit" class="btn btn-primary">Edit Canadian price</button>
            </div>
        </form>
    </div>

    <div class="col-lg-7">
        Price displayed: <br />
    <?php if($ph->price2 > 0){?>
        <h4><b><p id="chgn">$ <?php echo number_format($ph->price2);?>.00</p></b></h4>
        <?php }
                else{
                ?>
        <h4><b><p id="chgn">$ 0</p></b></h4>
                <?php }?>

    </div>

</div>

</div> <!-- /.page-wraper -->

</div>
<!-- /#wrapper -->
<?php }}?>
</body>

</html>
