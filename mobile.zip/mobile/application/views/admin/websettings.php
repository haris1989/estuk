
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Website Settings</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->

<?php
if($settings){
    foreach($settings as $set){

?>
    <form action="<?php echo base_url(); ?>index.php/admin/Websettings/update" method="post">
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <i class="fa fa-bar-chart-o fa-fw"></i> SEO Settings
                    </div><!-- /.panel-heading -->

                    <div class="panel-body">


                        <div class="col-md-12">

                            <div class="form-group">
                                <label>Site Title:</label>
                                <input type="text"  required name="site_title" class="form-control" placeholder="Enter website title" value="<?php echo $set->site_title; ?>">
                            </div>

                            <div class="form-group">
                                <label>Site Description:</label>
                                <input required type="text" name="site_des" class="form-control" placeholder="Enter website description" value="<?php echo $set->site_des; ?>">
                            </div>

                            <div class="form-group">
                                <label>Site Keywords:<br><p style="font-size:12px;">(Please use commas to seperate key words)</p></label>
                                <input required  type="text" name="site_keywords" class="form-control" placeholder="Enter website keywords" value="<?php echo $set->site_keywords; ?>">
                            </div>
                            <button style="float:right;" type="submit" class="btn btn-primary">Update</button>
                        </div>    <!-- /.col-md-12 -->
                    </div><!-- /.panel-body -->
                </div><!-- /.panel -->
            </div><!-- /.col-lg-12 -->
            <div class="clear"></div>
        </div><!-- /.row -->
    </form>
<?php }}?>
</div><!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->

</body>

</html>