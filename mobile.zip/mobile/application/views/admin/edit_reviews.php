    <?php if(isset($reviews)){
      foreach($reviews as $rw){?>
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Edit Review</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->




    <div class="col-lg-8">
        <form action="<?php echo base_url(); ?>index.php/admin/Reviews/update" method="post" enctype="multipart/form-data">

                        <div class="form-group">
                            <label>Review title</label>
                            <input class="form-control" name="title" type="text" value="<?php echo $rw->title; ?>" required/>
                        </div>
                         <div class="form-group">
                        <label>Description(Short summary about review)</label><br />
                        <textarea id="textarea" name="description" cols="6" rows="10" class="form-control"><?php echo $rw->description;?></textarea>
                        <script type="text/javascript">
                            $('#textarea').summernote({
                                height: 250
                            });
                        </script>
                    </div>
                          <div class="form-group">
                            <label>Select review type</label>
                            <br/><br/>
                            <label>Phones</label>&nbsp;
                            <input  name="type" type="radio" onclick="

                               document.getElementById('phone').style.display='block'
                               document.getElementById('plan').style.display='none'
                                

                               " value="1" <?php if($rw->phone_id){

                                echo "checked";
                               }

                               ?>>   
                            &nbsp;&nbsp;or&nbsp;&nbsp;
                            <label>Plans</label>&nbsp;
                               <input   name="type" type="radio"  onclick="

                               document.getElementById('plan').style.display='block'
                               document.getElementById('phone').style.display='none'
                               

                               " value="0" <?php if($rw->provider_id){

                                echo "checked";
                               }

                               ?>>  
                        </div>
                            <div class="form-group" id="phone" <?php if($rw->provider_id){

                              echo "style=display:none";

                              }?>
                            >
                        <label>Select a Phone</label>
                        <select name="phone_id" class="form-control">
                             <?php
                   if(isset($phones)){
                       $bool=true;
                   foreach($phones as $ph){
                   ?>
                    <?php if($rw->phone_id==$ph->id){?>
                       <option selected="selected"  value="<?php echo $ph->id;?>"><?php echo $ph->name;?></option>
                       <?php
                       $bool=false;
                       }
                       else{?>
                       <option  value="<?php echo $ph->id;?>"><?php echo $ph->name;?></option>

                    <?php
                       }
                       }
                   }?>

                        </select>
                    </div>

                          <div class="form-group" id="plan" <?php if($rw->provider_id){

                              echo "style=display:block";

                              }
                              else{

                                echo "style=display:none";

                              }
                              ?>>
                        <label>Select a Provider</label>
                        <select name="provider_id" class="form-control">
                             <?php
                   if(isset($plans)){
                       $bool=true;
                   foreach($plans as $ph){
                   ?>
                    <?php if($rw->phone_id==$ph->id){?>
                       <option selected="selected"  value="<?php echo $ph->id;?>"><?php echo $ph->name;?></option>
                       <?php
                       $bool=false;
                       }
                       else{?>
                       <option  value="<?php echo $ph->id;?>"><?php echo $ph->name;?></option>

                    <?php
                       }
                       }
                   }?>

                        </select>
                    </div>


                               <div class="form-group" id="plan" style="display:none;">
                <label>Select plan</label>
                <select name="provider_id" id="prov" class="form-control">
                   <?php
                   if(isset($providers)){
                       $bool=true;
                   foreach($providers as $provider){
                   ?>
                    <?php if($bool){?>
                       <option selected="selected"  value="<?php echo $provider->id;?>"><?php echo $provider->name;?></option>
                       <?php
                       $bool=false;
                       }
                       else{?>
                       <option  value="<?php echo $phone->id;?>"><?php echo $provider->name;?></option>

                    <?php
                       }
                       }
                   }?>

                </select>
            </div>

                             <div class="form-group">
                        <label>Upload Review banner image</label>
                        <p class="help-block">.png, .jpg, .jpeg, .gif only! The script will create 2 images (big image and thumb image). We recomend to upload a big image (min. 600px width)</p>
                        <input name="userfile" type="file">
                    </div>

                        <div class="form-group">
                            <label>Reviews Keywords</label>
                            <input class="form-control" name="keywords" type="text" value="<?php echo $rw->keywords; ?>" />
                        </div>

                       <div class="form-group">
                        <label>Review Active?</label>
                        <select name="is_active" class="form-control">
                             <?php
                 if($rw->is_active == 1){?>

                    <option selected="selected" value="1" selected="selected">Yes</option>
                    <option  value="0">No</option>

                <?php }
                else{
                ?>

                    <option  value="1">Yes</option>
                    <option selected="selected"  value="0">No</option>

            <?php }?>
                        </select>
                    </div>
                      <input type="hidden" value="<?php echo $rw->id;?>" name="id">
                        
                        <button type="submit" class="btn btn-primary">Submit Review</button>
                    </form>
    </div>
      <div class="col-lg-4" >
                      <div style="padding:0% 25% 0% 25%;">
                      <strong> Banner Image</strong>
<br><br>
                    <img class="img-responsive" style="max-width:160px; height:auto; border: none;" src="<?php echo base_url();?>img/reviews/thumb/<?php echo $rw->image;?>" />
                    </div>

                  
                    

                    <div class="clear"></div>

                    

                </div>

    <div class="clear"></div>

    <div class="clear"></div>

</div><!-- /.panel-body -->
</div><!-- /.col-lg-12 -->
</div><!-- /.row -->

</div> <!-- /.page-wraper -->

</div>
<!-- /#wrapper -->
<?php
}
}
?>
</body>

</html>