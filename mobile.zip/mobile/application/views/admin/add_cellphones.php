    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Add new cell phone</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->




    <div class="col-lg-6">
        <form action="<?php echo base_url();?>index.php/admin/Cellphones/create" method="post" enctype="multipart/form-data">

            <div class="form-group">
                <label>Input model (WITHOUT brand name)</label>
                <input class="form-control" name="name" type="text" value="" required/>
            </div>
            <div class="form-group">
                        <label>Description(Short summary about phone)</label><br />
                        <textarea id="textarea" name="description" cols="6" rows="10" class="form-control"></textarea>
                        <script type="text/javascript">
                            $('#textarea').summernote({
                                height: 250
                            });
                        </script>
                    </div>


            <div class="form-group">
                <label>Select brand</label>
                <select name="brand_id" class="form-control">
                   <?php
                   if(isset($brands)){
                       $bool=true;
                   foreach($brands as $brand){
                   ?>
                    <?php if($bool){?>
                       <option selected="selected"  value="<?php echo $brand->id;?>"><?php echo $brand->name;?></option>
                       <?php
                       $bool=false;
                       }
                       else{?>
                       <option  value="<?php echo $brand->id;?>"><?php echo $brand->name;?></option>

                    <?php
                       }
                       }
                   }?>

                </select>
            </div>



            <div class="form-group">
                <label>Popular cell phone</label>
                <p class="help-block">Popular cell phones have listings priority (in index page, cell phones page, popular cell phones page...)</p>
                <select name="is_popular" class="form-control">
                    <option  value="1">YES</option>
                    <option  value="0">NO</option>
                </select>
            </div>

            <div class="form-group">
                <label>Device Year (used for search / filters)</label>
                <input class="form-control" name="year" type="date" />
            </div>

            <div class="form-group">
                <label>Active cell phone (show on site)</label>
                <select name="active" class="form-control">
                    <option  value="1">YES</option>
                    <option  value="0">NO</option>
                </select>
            </div>

            <div class="form-group">
                <label>Upload cell phone image</label>
                <p class="help-block">.png, .jpg, .jpeg, .gif only! The script will create 2 images (big image and thumb image). We recomend to upload a big image (min. 600px width)</p>
                <input name="userfile" type="file">
            </div>


            <div class="form-group">
                <button type="submit" class="btn btn-primary">Add cell phone</button>
                <p class="help-block">After adding a new cell phone you can edit cell phone details and add more images.</em></p>
            </div>
        </form>
    </div>

    <div class="clear"></div>

    <div class="clear"></div>

</div><!-- /.panel-body -->
</div><!-- /.col-lg-12 -->
</div><!-- /.row -->

</div> <!-- /.page-wraper -->

</div>
<!-- /#wrapper -->

</body>

</html>