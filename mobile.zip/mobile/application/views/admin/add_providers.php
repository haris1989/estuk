<div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Add new plan provider</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->




    <div class="col-lg-6">
        <form action="<?php echo base_url(); ?>index.php/admin/Plans/create " method="post" enctype="multipart/form-data">

            <div class="form-group">
                <label>Plan provider name</label>
                <input class="form-control" name="name" type="text" value="" />
            </div>

               <div class="form-group">
                <label>Select country for plan provider</label>
                <p class="help-block">This will help in sorting plans by country!</p>
                <select name="country" class="form-control" required>
                    <option value="1">USA</option>
                    <option value="0" selected="selected">Canada</option>
                </select>
            </div>


            <div class="form-group">
                <label>Is featured?</label>
                <p class="help-block">Featured Plans (important plan) will appear first in Plan providers list!</p>
                <select name="is_featured" class="form-control">
                    <option value="1">Yes</option>
                    <option value="0" selected="selected">No</option>
                </select>
            </div>

            <div class="form-group">
                <label>Upload Logo</label>
                <p class="help-block">Upload Provider logo! (optional)</p>
                <input type="url" name="logo" >
            </div>

            <div class="form-group">
                <button type="submit" class="btn btn-primary">Add provider</button>
            </div>
        </form>
    </div>

    <div class="clear"></div>

    <div class="clear"></div>

</div><!-- /.panel-body -->
</div><!-- /.col-lg-12 -->
</div><!-- /.row -->

</div> <!-- /.page-wraper -->

</div>
<!-- /#wrapper -->

</body>

</html>