<?php foreach($brands as $brand){?>
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header"><?php echo $brand->name; ?> - edit brand</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->




    <div class="col-lg-6">
        <form action="<?php echo base_url(); ?>index.php/admin/Brands/update " method="post" >

            <div class="form-group">
                <label>Brand name</label>
                <input class="form-control" name="name" type="text" value="<?php echo $brand->name; ?>" />
            </div>


            <div class="form-group">
                <label>Is featured?</label>
                <p class="help-block">Featured brands (important brands) will appear first in brands list!</p>
                <select name="is_featured" class="form-control">
                <?php
                 if($brand->is_featured == 1){?>

                    <option selected="selected" value="1" selected="selected">Yes</option>
                    <option  value="0">No</option>

                <?php }
                else{
                ?>

                    <option  value="1">Yes</option>
                    <option selected="selected"  value="0">No</option>

            <?php }?>
                </select>
            </div>

            <div class="form-group">
                <label>Upload Logo</label>
                <p class="help-block">Upload a new logo if you want to replace the old logo!</p>
                <input type="url" name="image_url" value="<?php echo $brand->image_url;?>" >

            </div>

            <div class="form-group">
               <input type="hidden" name="id" value="<?php echo $brand->id;?>">
                <button type="submit" class="btn btn-primary">Edit brand</button>
            </div>
        </form>
    </div>

    <div class="clear"></div>

    <div class="clear"></div>

</div><!-- /.panel-body -->
</div><!-- /.col-lg-12 -->
</div><!-- /.row -->

</div> <!-- /.page-wraper -->
<?php }?>
</div>
<!-- /#wrapper -->

</body>

</html>