
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Images for P31</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->



    <div class="row">
        <div class="col-lg-12">

            <div class="panel-body nopadding">

                <form action="phones_images_submit.php" method="post" class="form" enctype="multipart/form-data">

                    <div class="form-group">
                        <label>Image Title</label>
                        <input type="text" name="image_title" class="form-control" value="" />
                    </div>

                    <div class="form-group">
                        <label>Upload image</label>
                        <p class="help-block">.png, .jpg, .jpeg, .gif only!</p>
                        <input type="file" name="image">
                    </div>

                    <input type="hidden" name="phone_id" value="284" />
                    <button type="submit" class="btn btn-success">Add image</button>
                </form>


                <div class="clear"></div>
                <h2>All images</h2>

                No image in database
                <div class="clear"></div>



            </div><!-- /.panel-body -->
        </div><!-- /.col-lg-12 -->
    </div><!-- /.row -->

</div> <!-- /.page-wraper -->

</div>
<!-- /#wrapper -->

</body>

</html>