
<style>
    #positions tr:hover {
        background-color: #E9E9E9;
        cursor: move;
    }

</style>

<script type="text/javascript" src="<?php echo base_url(); ?>js/jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/jquery.tablednd_0_5.js"></script>

<script type="text/javascript">
    $(document).ready(function() {
        $("#positions").tableDnD({
            onDrop: function(table, row) {
                var ordered_items = $.tableDnD.serialize('id');

                $.ajax({
                    type: "GET",
                    url: "<?php echo base_url();?>index.php/admin/Brands/changeFeaturedBrandsPos/",
                    data: ""+ordered_items,
                    success: function(json)
                    {
                        //$('#result').load("<?php echo base_url();?>index.php/admin/Brands/changeFeaturedBrandsPos/" + ordered_items);
                    }
                });
            }
        });
    });
</script>

    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Featured Brands Order</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->


    <p class="bg-info">To change order of this featured brands, you can DRAG AND DROP the rows below to positions you want to appear in front-end menus.</p>


    <div class="row">
        <div class="col-lg-12">

            <div class="panel-body nopadding">




                <table id="positions" class="table table-bordered">
                    <tbody>

                    <?php if($brands){
                        foreach($brands as $brand){
                    ?>
                    <tr id="<?php echo $brand->id; ?>">

                        <td align="left" valign="top" width="80%">
                            <strong><?php echo $brand->name; ?></strong>
                        </td>

                    </tr>

                <?php }}?>
                    </tbody>
                </table>



                <div class="clear"></div>


            </div><!-- /.panel-body -->
        </div><!-- /.col-lg-12 -->
    </div><!-- /.row -->

</div> <!-- /.page-wraper -->

</div>
<!-- /#wrapper -->

</body>

</html>