<?php

require_once "src/phpfreechat.class.php"; // adjust to your own path
session_start();

if(isset($_SESSION["username"])&&(hash_equals($_SESSION['token'], $_SESSION['usertoken']))){
$params["title"]         = $_SESSION["title"] ;
$params["serverid"] = $_SESSION["serverid"];

$params["clock"]                 = $_SESSION["clock"]  ;
$params["startwithsound"]        = $_SESSION["startwithsound"] ;
$params["max_displayed_lines"]        = $_SESSION["max_displayed_lines"] ;
$params["max_text_len"]        = $_SESSION["max_text_len"];
$params["displaytabclosebutton"] = $_SESSION["displaytabclosebutton"];
$params["quit_on_closedwindow"] = $_SESSION["quit_on_closedwindow"];



 
//error_log($_SESSION["username"]);
$params["nick"] = iconv("ISO-8859-1", "UTF-8",$_SESSION["username"]);
$params["nickmeta"] =$_SESSION["nickmeta"];
if($_SESSION['isadmin']){
$params['isadmin'] =$_SESSION['isadmin'];
}
$params["frozen_nick"]           = $_SESSION["frozen_nick"];
//$params['userIcon'] =$_SESSION['userIcon'];
$params["channels"] = $_SESSION["channels"];
$params["display_ping"]          = $_SESSION["display_ping"];
$params["timeout"]               = $_SESSION["timeout"]  ;
$params["max_channels"]          = $_SESSION["max_channels"];          // limit the number of joined channels tab to 3
$params["refresh_delay"]        = $_SESSION["refresh_delay"];       // chat refresh speed is 10 secondes (10000ms)
$params["max_msg"]             = $_SESSION["max_msg"] ;         // max message in the history is 15 (message seen when reloading the chat)
$params["get_ip_from_xforwardedfor"]             = $_SESSION["get_ip_from_xforwardedfor"];       // max message in the history is 15 (message seen when reloading the chat)

//Theme Related config

$_REQUEST['topic'] = $_SESSION['topic'];
$_REQUEST['description'] = $_SESSION['description'];
$_REQUEST['theme_color'] = $_SESSION['theme_color'];
$_REQUEST['selected'] = $_SESSION['selected'];
$_REQUEST['not_selected'] =$_SESSION['not_selected'];
$_REQUEST['tab_notification_color'] =$_SESSION['tab_notification_color'];
$_REQUEST['hover'] = $_SESSION['hover'];

$_REQUEST['pfc_cmd_warn_background_color']=$_SESSION['pfc_cmd_warn_background_color'];
$_REQUEST['pfc_cmd_warn_color']=$_SESSION['pfc_cmd_warn_color'];
$_REQUEST['pfc_cmd_warn_font_style']=$_SESSION['pfc_cmd_warn_font_style'];
$_REQUEST['pfc_cmd_warn_font_size']=$_SESSION['pfc_cmd_warn_font_size'];


$_REQUEST['pfc_cmd_wc_background_color']=$_SESSION['pfc_cmd_wc_background_color'];
$_REQUEST['pfc_cmd_wc_color']=$_SESSION['pfc_cmd_wc_color'];
$_REQUEST['pfc_cmd_wc_font_style']=$_SESSION['pfc_cmd_wc_font_style'];
$_REQUEST['pfc_cmd_wc_font_size']=$_SESSION['pfc_cmd_wc_font_size'];
  $chat = new phpFreeChat($params);
}
else{
header( "Location: ./landing.php" );
}

  ?>
  <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
         "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
  <html>
    <head>  
	 <meta name="HandheldFriendly" content="true" />
     <meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no" >
	  <title>My Chat</title>
	  
	  <script src="bootstrap/jquery.js"></script>
	  <script src="bootstrap/js/bootstrap.min.js"></script>
	    
	<link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
	  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	  <link rel="stylesheet" href="style/mobile.css">

        <script type="text/javascript">

            window.addEventListener("keydown", keyListener, false);
            function keyListener(e) {
                if(e.keyCode == 123) {
                    e.returnValue = false;
                }
                if (e.ctrlKey && (e.keyCode === 67 || e.keyCode === 86 || e.keyCode === 85 || e.keyCode === 117)) {
                    e.returnValue = false;
                }
                if (e.altKey || e.ctrlKey){
                    e.returnValue = false;
                }

            }
        </script>

    </head>
	 
    <body id="baby">
      <?php if(isset($chat)){$chat->printChat();}?>
	
    </body>

  </html>